/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.dbeaver.ui.preferences;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.e4.core.services.events.IEventBroker;
import org.eclipse.e4.ui.css.swt.theme.IThemeEngine;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.jface.layout.GridLayoutFactory;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.resource.FontRegistry;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.*;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;
import org.eclipse.ui.IWorkbenchPropertyPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.internal.themes.ColorsAndFontsPreferencePage;
import org.eclipse.ui.internal.themes.FontDefinition;
import org.eclipse.ui.internal.themes.ThemeElementCategory;
import org.eclipse.ui.internal.themes.WorkbenchThemeManager;
import org.eclipse.ui.internal.util.PrefUtil;
import org.eclipse.ui.preferences.IWorkbenchPreferenceContainer;
import org.eclipse.ui.themes.ITheme;
import org.eclipse.ui.themes.IThemeManager;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBeaverPreferences;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.core.CoreMessages;
import org.jkiss.dbeaver.core.DesktopPlatform;
import org.jkiss.dbeaver.model.preferences.DBPPreferenceStore;
import org.jkiss.dbeaver.registry.SWTBrowserRegistry;
import org.jkiss.dbeaver.runtime.DBWorkbench;
import org.jkiss.dbeaver.ui.UIFontPreferenceManager;
import org.jkiss.dbeaver.ui.UIFonts;
import org.jkiss.dbeaver.ui.UIIcon;
import org.jkiss.dbeaver.ui.UIUtils;
import org.jkiss.dbeaver.ui.controls.BreadcrumbTrim;
import org.jkiss.dbeaver.ui.editors.DatabaseEditorPreferences;
import org.jkiss.dbeaver.ui.editors.DatabaseEditorPreferences.BreadcrumbLocation;
import org.jkiss.dbeaver.ui.editors.EditorUtils;
import org.jkiss.dbeaver.ui.internal.UIMessages;
import org.jkiss.dbeaver.utils.GeneralUtils;
import org.jkiss.dbeaver.utils.PrefUtils;
import org.jkiss.dbeaver.utils.RuntimeUtils;
import org.osgi.service.event.EventHandler;

import java.util.*;
import java.util.List;

/**
 * PrefPageDatabaseUserInterface
 */
public class PrefPageDatabaseUserInterface extends AbstractPrefPage implements IWorkbenchPreferencePage, IWorkbenchPropertyPage {

    private static final Log log = Log.getLog(PrefPageDatabaseUserInterface.class);

    public static final String PAGE_ID = "org.jkiss.dbeaver.preferences.main"; //$NON-NLS-1$

    private static final Collection<String> QUICK_FONT_IDS = List.of(
        UIFonts.DBeaver.MAIN_FONT,
        UIFonts.DBeaver.MONOSPACE_FONT
    );


    private final boolean isStandalone = DesktopPlatform.isStandalone();
    @Nullable
    private IThemeEngine themeEngine;
    @Nullable
    private org.eclipse.e4.ui.css.swt.theme.ITheme originalTheme;
    @Nullable
    private org.eclipse.e4.ui.css.swt.theme.ITheme selectedTheme;
    private Combo browserCombo;
    private Button useEmbeddedBrowserAuth;

    private Button statusBarShowBreadcrumbsCheck;
    private Button statusBarShowStatusCheck;
    private Combo statusBarBreadcrumbPositionCombo;
    @Nullable
    private String appliedBreadcrumbLocation;
    private boolean appliedBreadcrumbLocationIsDefault;
    private boolean appliedStatusLineVisible;
    private boolean appliedStatusLineVisibleIsDefault;
    private boolean statusBarPreviewed;
    private Button zoomRestartPromptCheck;

    @Nullable
    private FontsController fontsController = null;

    public PrefPageDatabaseUserInterface()
    {
        super();
        setPreferenceStore(new PreferenceStoreDelegate(DBWorkbench.getPlatform().getPreferenceStore()));
    }

    @Override
    public void init(IWorkbench workbench)
    {

    }

    @NotNull
    @Override
    protected Control createPreferenceContent(@NotNull Composite parent) {
        Composite composite = UIUtils.createPlaceholder(parent, 1, 5);

        if (isStandalone) {
            themeEngine = PlatformUI.getWorkbench().getService(IThemeEngine.class);
            if (themeEngine != null) {
                originalTheme = themeEngine.getActiveTheme();
                selectedTheme = originalTheme;
                Composite themes = UIUtils.createTitledComposite(
                    composite, CoreMessages.pref_page_ui_general_group_theme, 1,
                    GridData.FILL_HORIZONTAL | GridData.VERTICAL_ALIGN_BEGINNING
                );
                for (org.eclipse.e4.ui.css.swt.theme.ITheme theme : themeEngine.getThemes()) {
                    Button button = UIUtils.createRadioButton(themes, theme.getLabel(), theme, SelectionListener.widgetSelectedAdapter(e -> {
                        if (((Button) e.widget).getSelection()) {
                            if (fontsController != null) {
                                fontsController.rollback();
                            }
                            selectedTheme = theme;
                            themeEngine.setTheme(theme, false);
                        }
                    }));
                    button.setSelection(theme.getId().equals(originalTheme.getId()));
                }
            }

            this.fontsController = this.prepareFontsController(composite, QUICK_FONT_IDS);
        }

        Composite breadcrumbs = UIUtils.createTitledComposite(
            composite,
            CoreMessages.pref_page_ui_status_bar,
            2,
            GridData.FILL_HORIZONTAL | GridData.VERTICAL_ALIGN_BEGINNING
        );
        statusBarShowBreadcrumbsCheck = UIUtils.createCheckbox(
            breadcrumbs,
            CoreMessages.pref_page_ui_status_bar_show_breadcrumbs_check_label,
            CoreMessages.pref_page_ui_status_bar_show_breadcrumbs_check_tip,
            true,
            1
        );
        statusBarShowBreadcrumbsCheck.addSelectionListener(SelectionListener.widgetSelectedAdapter(e -> {
            if (isStandalone) {
                statusBarBreadcrumbPositionCombo.setEnabled(statusBarShowBreadcrumbsCheck.getSelection());
            }
            previewStatusBar();
        }));

        statusBarBreadcrumbPositionCombo = new Combo(breadcrumbs, SWT.READ_ONLY | SWT.DROP_DOWN);
        statusBarBreadcrumbPositionCombo.add(CoreMessages.pref_page_ui_status_bar_show_breadcrumbs_status_bar_label);
        statusBarBreadcrumbPositionCombo.add(CoreMessages.pref_page_ui_status_bar_show_breadcrumbs_editors_label);
        if (isStandalone) {
            statusBarBreadcrumbPositionCombo.select(0);
            statusBarBreadcrumbPositionCombo.addSelectionListener(SelectionListener.widgetSelectedAdapter(e -> previewStatusBar()));
        } else {
            statusBarBreadcrumbPositionCombo.select(1);
            statusBarBreadcrumbPositionCombo.setEnabled(false);
        }

        statusBarShowStatusCheck = UIUtils.createCheckbox(
            breadcrumbs,
            CoreMessages.pref_page_ui_status_bar_show_status_line_check_label,
            CoreMessages.pref_page_ui_status_bar_show_status_line_check_tip,
            true,
            2
        );
        statusBarShowStatusCheck.addSelectionListener(SelectionListener.widgetSelectedAdapter(e -> previewStatusBar()));

        if (RuntimeUtils.isLinux()) {
            Composite displayGroup = UIUtils.createTitledComposite(
                composite,
                CoreMessages.pref_page_ui_general_group_display,
                2,
                GridData.FILL_HORIZONTAL | GridData.VERTICAL_ALIGN_BEGINNING
            );
            zoomRestartPromptCheck = UIUtils.createCheckbox(
                displayGroup,
                CoreMessages.pref_page_ui_general_check_zoom_restart_prompt_label,
                CoreMessages.pref_page_ui_general_check_zoom_restart_prompt_tip,
                true,
                2
            );
        }

        if (isStandalone) {
            Composite groupObjects = UIUtils.createTitledComposite(
                composite,
                CoreMessages.pref_page_ui_general_group_browser,
                2,
                GridData.FILL_HORIZONTAL | GridData.VERTICAL_ALIGN_BEGINNING
            );
            if (RuntimeUtils.isWindows()) {
                browserCombo = UIUtils.createLabelCombo(
                    groupObjects,
                    CoreMessages.pref_page_ui_general_combo_browser,
                    SWT.READ_ONLY
                );
                browserCombo.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING));
                for (SWTBrowserRegistry.BrowserSelection value : SWTBrowserRegistry.BrowserSelection.values()) {
                    browserCombo.add(value.getFullName(), value.ordinal());
                }
                Control tipLabel =
                    UIUtils.createInfoLabel(groupObjects, CoreMessages.pref_page_ui_general_combo_browser_tip);
                tipLabel.setLayoutData(new GridData(
                    GridData.HORIZONTAL_ALIGN_BEGINNING,
                    GridData.VERTICAL_ALIGN_BEGINNING,
                    false,
                    false,
                    2,
                    1
                ));
            }

            useEmbeddedBrowserAuth = UIUtils.createCheckbox(
                groupObjects,
                CoreMessages.pref_page_ui_general_check_browser_auth,
                CoreMessages.pref_page_ui_general_check_browser_auth_tip,
                false,
                2
            );
            useEmbeddedBrowserAuth.setLayoutData(new GridData(
                GridData.HORIZONTAL_ALIGN_BEGINNING,
                GridData.VERTICAL_ALIGN_BEGINNING,
                false,
                false,
                2,
                1
            ));
            if (browserCombo != null) {
                browserCombo.addSelectionListener(SelectionListener.widgetSelectedAdapter(e -> {
                    if (browserCombo.getSelectionIndex() == SWTBrowserRegistry.BrowserSelection.IE.ordinal()) {
                        useEmbeddedBrowserAuth.setEnabled(false);
                        useEmbeddedBrowserAuth.setSelection(false);
                    } else {
                        useEmbeddedBrowserAuth.setEnabled(true);
                    }
                }));
            }
        }

        setSettings();
        return composite;
    }

    @NotNull
    private FontsController prepareFontsController(@NotNull Composite parent, @NotNull Collection<String> fontIds) {
        FontsController controller = new FontsController(parent);

        Map<String, Composite> groups = new HashMap<>();
        Composite catContainer = null;

        for (String fontId : fontIds) {
            FontDefinition fontDef = controller.findFontDefinition(fontId);
            if (fontDef != null) {
                catContainer = groups.get(fontDef.getCategoryId());
                if (catContainer == null) {
                    ThemeElementCategory cat = controller.findCategory(fontDef.getCategoryId());
                    if (cat == null) {
                        log.debug(
                            "Failed to find related category '" + fontDef.getCategoryId() + "' " +
                            "for the font definition '" + fontDef.getId() + "'"
                        );
                    }
                    String catName = cat == null ? "Uncategorized font preferences" : cat.getName();
                    String catDescription = cat == null ? null : cat.getDescription();
                    catContainer = UIUtils.createTitledComposite(parent, catName, SWT.NONE);
                    catContainer.getParent().setToolTipText(catDescription);
                    catContainer.setLayoutData(new GridData(SWT.FILL, SWT.BEGINNING, true, false));
                    GridLayoutFactory.swtDefaults().margins(0, 3).numColumns(4).applyTo(catContainer);
                    groups.put(fontDef.getCategoryId(), catContainer);
                }

                controller.createEntry(catContainer, fontDef);
            } else {
                log.debug("Failed to find font definition '" + fontId + "' for quick settings of the 'User interface preference page.'");
            }
        }

        controller.refreshAllFontsInitial();

        if (this.getContainer() instanceof IWorkbenchPreferenceContainer wpc && catContainer != null) {
            Composite info = new Composite(catContainer, SWT.NONE);
            GridDataFactory.fillDefaults().span(4, 1).applyTo(info);
            GridLayoutFactory.fillDefaults().margins(0, 0).spacing(2, 2).numColumns(2).applyTo(info);

            UIUtils.createInfoLabel(info, ""); // info icon near the link
            UIUtils.createPreferenceLink(
                info,
                CoreMessages.pref_page_ui_general_link_more_color_and_font_settings,
                EditorUtils.COLORS_AND_FONTS_PAGE_ID,
                wpc, null
            );
        }

        parent.addDisposeListener(e -> controller.dispose());

        return controller;
    }

    private void setSettings() {
        DBPPreferenceStore store = DBWorkbench.getPlatform().getPreferenceStore();
        rememberAppliedStatusBar(store);
        if (isWindowsDesktopClient()) {
            browserCombo.select(SWTBrowserRegistry.getActiveBrowser().ordinal());
            useEmbeddedBrowserAuth.setEnabled(
                SWTBrowserRegistry.getActiveBrowser() != SWTBrowserRegistry.BrowserSelection.IE);
        }
        if (isStandalone) {
            useEmbeddedBrowserAuth.setSelection(store.getBoolean(UIPreferences.UI_USE_EMBEDDED_AUTH));
        }
        BreadcrumbLocation breadcrumbLocation = DatabaseEditorPreferences.BreadcrumbLocation.get(store);
        statusBarShowBreadcrumbsCheck.setSelection(breadcrumbLocation != DatabaseEditorPreferences.BreadcrumbLocation.HIDDEN);
        if (isStandalone) {
            statusBarBreadcrumbPositionCombo.select(breadcrumbLocation == DatabaseEditorPreferences.BreadcrumbLocation.IN_EDITORS ? 1 : 0);
            statusBarBreadcrumbPositionCombo.setEnabled(statusBarShowBreadcrumbsCheck.getSelection());
        }
        statusBarShowStatusCheck.setSelection(store.getBoolean(DBeaverPreferences.UI_STATUS_BAR_SHOW_STATUS_LINE));
        if (RuntimeUtils.isLinux()) {
            zoomRestartPromptCheck.setSelection(store.getBoolean(DBeaverPreferences.UI_SHOW_ZOOM_RESTART_PROMPT));
        }
    }

    @Override
    protected void performDefaults() {
        DBPPreferenceStore store = DBWorkbench.getPlatform().getPreferenceStore();
        if (isStandalone) {
            useEmbeddedBrowserAuth.setSelection(store.getDefaultBoolean(UIPreferences.UI_USE_EMBEDDED_AUTH));
        }
        if (isWindowsDesktopClient()) {
            browserCombo.select(SWTBrowserRegistry.getDefaultBrowser().ordinal());
        }
        BreadcrumbLocation location = BreadcrumbLocation.getDefault(store);
        statusBarShowBreadcrumbsCheck.setSelection(location != BreadcrumbLocation.HIDDEN);
        if (isStandalone) {
            statusBarBreadcrumbPositionCombo.select(location == BreadcrumbLocation.IN_STATUS_BAR ? 0 : 1);
        }
        statusBarShowStatusCheck.setSelection(store.getDefaultBoolean(DBeaverPreferences.UI_STATUS_BAR_SHOW_STATUS_LINE));
        if (isStandalone) {
            statusBarBreadcrumbPositionCombo.setEnabled(statusBarShowBreadcrumbsCheck.getSelection());
        }
        previewStatusBar();
        if (RuntimeUtils.isLinux()) {
            zoomRestartPromptCheck.setSelection(store.getDefaultBoolean(DBeaverPreferences.UI_SHOW_ZOOM_RESTART_PROMPT));
        }

        if (this.fontsController != null) {
            this.fontsController.resetToDefaults();
        }
    }

    @Override
    public boolean performCancel() {
        if (fontsController != null) {
            fontsController.rollback();
        }
        if (statusBarPreviewed) {
            DBPPreferenceStore store = DBWorkbench.getPlatform().getPreferenceStore();
            if (appliedBreadcrumbLocationIsDefault) {
                store.setToDefault(DBeaverPreferences.UI_STATUS_BAR_SHOW_BREADCRUMBS);
            } else {
                store.setValue(DBeaverPreferences.UI_STATUS_BAR_SHOW_BREADCRUMBS, appliedBreadcrumbLocation);
            }
            if (appliedStatusLineVisibleIsDefault) {
                store.setToDefault(DBeaverPreferences.UI_STATUS_BAR_SHOW_STATUS_LINE);
            } else {
                store.setValue(DBeaverPreferences.UI_STATUS_BAR_SHOW_STATUS_LINE, appliedStatusLineVisible);
            }
            if (isStandalone) {
                BreadcrumbTrim.refreshStatusBar();
            }
        }
        if (themeEngine != null && originalTheme != null && selectedTheme != null &&
            !originalTheme.getId().equals(selectedTheme.getId())) {
            themeEngine.setTheme(originalTheme, false);
        }
        return super.performCancel();
    }

    private boolean isWindowsDesktopClient() {
        return isStandalone && RuntimeUtils.isWindows();
    }

    private void rememberAppliedStatusBar(@NotNull DBPPreferenceStore store) {
        appliedBreadcrumbLocation = store.getString(DBeaverPreferences.UI_STATUS_BAR_SHOW_BREADCRUMBS);
        appliedBreadcrumbLocationIsDefault = store.isDefault(DBeaverPreferences.UI_STATUS_BAR_SHOW_BREADCRUMBS);
        appliedStatusLineVisible = store.getBoolean(DBeaverPreferences.UI_STATUS_BAR_SHOW_STATUS_LINE);
        appliedStatusLineVisibleIsDefault = store.isDefault(DBeaverPreferences.UI_STATUS_BAR_SHOW_STATUS_LINE);
        statusBarPreviewed = false;
    }

    private void previewStatusBar() {
        DBPPreferenceStore store = DBWorkbench.getPlatform().getPreferenceStore();
        store.setValue(DBeaverPreferences.UI_STATUS_BAR_SHOW_BREADCRUMBS, getSelectedBreadcrumbLocation().name());
        store.setValue(DBeaverPreferences.UI_STATUS_BAR_SHOW_STATUS_LINE, statusBarShowStatusCheck.getSelection());
        if (isStandalone) {
            BreadcrumbTrim.refreshStatusBar();
        }
        statusBarPreviewed = true;
    }

    @NotNull
    private BreadcrumbLocation getSelectedBreadcrumbLocation() {
        if (!statusBarShowBreadcrumbsCheck.getSelection()) {
            return BreadcrumbLocation.HIDDEN;
        }
        if (isStandalone && statusBarBreadcrumbPositionCombo.getSelectionIndex() == 0) {
            return BreadcrumbLocation.IN_STATUS_BAR;
        }
        return BreadcrumbLocation.IN_EDITORS;
    }

    @Override
    public boolean isValid() {
        return super.isValid();
    }

    @Override
    public boolean performOk()
    {
        DBPPreferenceStore store = DBWorkbench.getPlatform().getPreferenceStore();

        boolean themeChanged = themeEngine != null && originalTheme != null && selectedTheme != null &&
            !originalTheme.getId().equals(selectedTheme.getId());
        if (themeChanged) {
            themeEngine.setTheme(selectedTheme, true);
            originalTheme = selectedTheme;
        }

        if (isStandalone) {
            store.setValue(UIPreferences.UI_USE_EMBEDDED_AUTH, useEmbeddedBrowserAuth.getSelection());
            if (isWindowsDesktopClient()) {
                SWTBrowserRegistry.setActiveBrowser(
                    SWTBrowserRegistry.BrowserSelection.values()[browserCombo.getSelectionIndex()]);
            }
        }

        store.setValue(DBeaverPreferences.UI_STATUS_BAR_SHOW_BREADCRUMBS, getSelectedBreadcrumbLocation().name());
        store.setValue(DBeaverPreferences.UI_STATUS_BAR_SHOW_STATUS_LINE, statusBarShowStatusCheck.getSelection());
        if (RuntimeUtils.isLinux()) {
            store.setValue(DBeaverPreferences.UI_SHOW_ZOOM_RESTART_PROMPT, zoomRestartPromptCheck.getSelection());
        }

        if (this.fontsController != null) {
            this.fontsController.apply();
        }
        if (isStandalone) {
            PrefUtils.savePreferenceStore(store);
        }
        rememberAppliedStatusBar(store);

        if (themeChanged && UIUtils.confirmAction(
            getShell(),
            NLS.bind(CoreMessages.pref_page_ui_theme_restart_title, GeneralUtils.getProductName()),
            NLS.bind(CoreMessages.pref_page_ui_theme_restart_message, GeneralUtils.getProductName())
        )) {
            restartWorkbenchOnPrefChange();
        }

        return true;
    }

    @Nullable
    @Override
    public IAdaptable getElement() {
        return null;
    }

    @Override
    public void setElement(IAdaptable element) {
    }

    private static class FontsController extends UIFontPreferenceManager {

        private class FontEntry {
            private static final ResourceBundle SWT_RESOURCE_BUNDLE = ResourceBundle.getBundle(ColorsAndFontsPreferencePage.class.getName());

            private record DependentFont(FontData[] data, String preference, boolean isDefault) {
            }

            @NotNull
            private final FontDefinition definition;
            @NotNull
            private final Text example;

            @Nullable
            private FontRegistry previewRegistry;
            @Nullable
            private FontData[] originalFontData;
            @Nullable
            private FontData[] pendingFontData;
            @Nullable
            private Map<String, DependentFont> dependentFonts;

            public FontEntry(@NotNull Composite container, @NotNull FontDefinition fontDef) {
                this.definition = fontDef;

                Label title  = UIUtils.createLabel(container, fontDef.getName() + ": ");
                title.setToolTipText(fontDef.getDescription());

                this.example = new Text(container, SWT.BORDER | SWT.READ_ONLY);
                this.example.setToolTipText(fontDef.getDescription());
                this.example.setEditable(false);
                GridDataFactory.fillDefaults().applyTo(this.example);

                UIUtils.createPushButton(
                    container, null, CoreMessages.pref_page_user_interface_fonts_modify_tooltip, UIIcon.EDIT,
                    SelectionListener.widgetSelectedAdapter(e -> {
                        final FontDialog fontDialog = new FontDialog(container.getShell());
                        fontDialog.setEffectsVisible(false);
                        fontDialog.setFontList(this.example.getFont().getFontData());
                        final FontData data = fontDialog.open();
                        if (data != null) {
                            this.setFont(fontDialog.getFontList());
                        }
                    })
                );

                UIUtils.createPushButton(
                    container, null, UIMessages.button_reset_to_defaults, UIIcon.REVERT,
                    SelectionListener.widgetSelectedAdapter(e -> {
                        this.resetToDefault();
                    })
                );
            }

            private void setFont(@NotNull FontData[] fontData) {
                FontRegistry fonts = UIUtils.getCurrentTheme().getFontRegistry();
                if (this.previewRegistry != null && this.previewRegistry != fonts) {
                    this.rollback();
                }
                if (this.previewRegistry == null) {
                    this.previewRegistry = fonts;
                    this.originalFontData = fonts.getFontData(this.definition.getId());
                    this.dependentFonts = new HashMap<>();
                    IPreferenceStore store = PrefUtil.getInternalPreferenceStore();
                    // Preview/restyling can also update fonts that default to this one (such as the result grid).
                    for (FontDefinition font : themeRegistry.getFonts()) {
                        FontDefinition ancestor = font;
                        while (ancestor.getDefaultsTo() != null) {
                            if (this.definition.getId().equals(ancestor.getDefaultsTo())) {
                                String key = createPreferenceKey(font);
                                this.dependentFonts.put(font.getId(), new DependentFont(
                                    fonts.getFontData(font.getId()), store.getString(key), store.isDefault(key)));
                                break;
                            }
                            ancestor = findFontDefinition(ancestor.getDefaultsTo());
                            if (ancestor == null) {
                                break;
                            }
                        }
                    }
                }
                this.pendingFontData = fontData;
                fonts.put(this.definition.getId(), fontData);
                eventBroker.send(WorkbenchThemeManager.Events.THEME_REGISTRY_MODIFIED, null);
                this.restoreDependentFonts();
                updateLayout(this.example, null);
            }

            public void refresh(@NotNull FontRegistry fonts) {
                Font font = fonts.get(this.definition.getId());
                this.example.setFont(font);
                this.example.setText(this.prepareFontDescription(font));
            }

            public void resetToDefault() {
                this.setFont(getDefaultFontData(this.definition));
            }

            public boolean apply() {
                if (this.pendingFontData != null) {
                    FontData[] fontData = this.pendingFontData;
                    this.rollback();
                    setFontPreference(this.definition, fontData);
                    return true;
                } else {
                    return false;
                }
            }

            @NotNull
            private String prepareFontDescription(@NotNull Font currentFont) {
                FontData[] fontData = currentFont.getFontData();

                // recalculate sample text
                StringBuilder tmp = new StringBuilder();
                for (FontData currentFontData : fontData) {
                    tmp.append(currentFontData.getName());
                    tmp.append(' ');
                    tmp.append(currentFontData.getHeight());

                    int style = currentFontData.getStyle();
                    if ((style & SWT.BOLD) != 0) {
                        tmp.append(' ');
                        tmp.append(SWT_RESOURCE_BUNDLE.getString("boldFont")); //$NON-NLS-1$
                    }
                    if ((style & SWT.ITALIC) != 0) {
                        tmp.append(' ');
                        tmp.append(SWT_RESOURCE_BUNDLE.getString("italicFont")); //$NON-NLS-1$
                    }
                }
                return tmp.toString();
            }

            public boolean rollback() {
                if (this.previewRegistry != null && this.originalFontData != null) {
                    this.previewRegistry.put(this.definition.getId(), this.originalFontData);
                    this.restoreDependentFonts();
                    this.previewRegistry = null;
                    this.originalFontData = null;
                    this.pendingFontData = null;
                    this.dependentFonts = null;
                    return true;
                }
                return false;
            }

            private void restoreDependentFonts() {
                if (this.previewRegistry == null || this.dependentFonts == null) {
                    return;
                }
                IPreferenceStore store = PrefUtil.getInternalPreferenceStore();
                boolean preferencesRestored = false;
                for (Map.Entry<String, DependentFont> dependent : this.dependentFonts.entrySet()) {
                    FontDefinition font = findFontDefinition(dependent.getKey());
                    if (font != null) {
                        String key = createPreferenceKey(font);
                        DependentFont original = dependent.getValue();
                        if (original.isDefault()) {
                            if (!store.isDefault(key)) {
                                store.setToDefault(key);
                                preferencesRestored = true;
                            }
                        } else if (!original.preference().equals(store.getString(key))) {
                            store.setValue(key, original.preference());
                            preferencesRestored = true;
                        }
                        this.previewRegistry.put(font.getId(), original.data());
                    }
                }
                if (preferencesRestored) {
                    savePrefs();
                }
            }
        }

        @NotNull
        private final IPropertyChangeListener themeChangeListener = event -> {
            if (this.isThemeChanged() || event.getProperty().equals(IThemeManager.CHANGE_CURRENT_THEME)) {
                this.refreshAllFonts();
            }
        };

        @NotNull
        private final EventHandler themeRegistryRestyledHandler = e -> {
            if (this.isThemeChanged()) {
                this.refreshAllFonts();
            }
        };

        @NotNull
        private final IPropertyChangeListener currentThemeListener = event -> {
            if (event.getSource() instanceof FontRegistry) {
                this.refreshFont(event.getProperty());
            }
        };

        @NotNull
        private final Composite container;
        @NotNull
        private final Map<String, FontEntry> fontEntriesById = new HashMap<>();

        @NotNull
        private final IEventBroker eventBroker;

        public FontsController(@NotNull Composite container) {
            this.container = container;
            this.eventBroker = this.workbench.getService(IEventBroker.class);

            this.workbench.getThemeManager().addPropertyChangeListener(this.themeChangeListener);
            this.eventBroker.subscribe(WorkbenchThemeManager.Events.THEME_REGISTRY_RESTYLED, this.themeRegistryRestyledHandler);

            this.currentTheme.addPropertyChangeListener(this.currentThemeListener);
        }

        public void createEntry(@NotNull Composite catContainer, @NotNull FontDefinition fontDef) {
            this.fontEntriesById.put(fontDef.getId(), new FontEntry(catContainer, fontDef));
        }

        private void refreshFont(@NotNull String fontId) {
            FontEntry entry = this.fontEntriesById.get(fontId);
            if (entry != null) {
                FontRegistry fonts = UIUtils.getCurrentTheme().getFontRegistry();
                entry.refresh(fonts);
                this.updateLayout(entry.example, null);
            }
        }

        public void refreshAllFonts() {
            this.refreshAllFontsImpl(true);
        }

        public void refreshAllFontsInitial() {
            this.refreshAllFontsImpl(false);
        }

        private void refreshAllFontsImpl(boolean updateLayout) {
            FontRegistry fonts = UIUtils.getCurrentTheme().getFontRegistry();
            for (FontEntry entry : this.fontEntriesById.values()) {
                entry.refresh(fonts);
                if (updateLayout) {
                    this.updateLayout(entry.example, this.container);
                }
            }
            if (updateLayout) {
                this.updateLayout(this.container, null);
            }
        }

        public void resetToDefaults() {
            for (FontEntry entry : this.fontEntriesById.values()) {
                entry.resetToDefault();
            }

            this.updateLayout(this.container, null);
        }

        public void rollback() {
            boolean changesMade = false;
            for (FontEntry entry : this.fontEntriesById.values()) {
                changesMade |= entry.rollback();
            }
            if (changesMade) {
                eventBroker.send(WorkbenchThemeManager.Events.THEME_REGISTRY_MODIFIED, null);
            }
        }

        public void apply() {
            boolean changesMade = false;
            for (FontEntry entry : this.fontEntriesById.values()) {
                changesMade |= entry.apply();
            }
            if (changesMade) {
                this.savePrefs();
                eventBroker.send(WorkbenchThemeManager.Events.THEME_REGISTRY_MODIFIED, null);
            }
        }

        private void updateLayout(@NotNull Control start, @Nullable Control end) {
            for (Control cc = start, prev = null; cc != null && cc != end; cc = cc.getParent()) {
                if (cc instanceof ScrolledComposite sc) {
                    sc.layout(true, true);
                    if (prev != null) {
                        sc.setMinSize(prev.computeSize(SWT.DEFAULT, SWT.DEFAULT));
                    }
                    break;
                } else {
                    cc.pack(true);
                }
                prev = cc;
            }
        }

        private boolean isThemeChanged() {
            ITheme actualTheme = this.getCurrentTheme();
            org.eclipse.e4.ui.css.swt.theme.ITheme actualCssTheme = this.getCurrentCssTheme();
            boolean changed = this.currentTheme != actualTheme || this.currentCssTheme != actualCssTheme;
            if (changed) {
                this.rollback();
                this.currentTheme.removePropertyChangeListener(this.currentThemeListener);
                this.currentTheme = actualTheme;
                this.currentCssTheme = actualCssTheme;
                this.currentTheme.addPropertyChangeListener(this.currentThemeListener);
            }
            return changed;
        }

        public void dispose() {
            this.currentTheme.removePropertyChangeListener(this.currentThemeListener);
            this.eventBroker.unsubscribe(themeRegistryRestyledHandler);
            this.workbench.getThemeManager().removePropertyChangeListener(themeChangeListener);
            this.rollback();
            this.fontEntriesById.clear();
        }
    }
}
