/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.dbeaver.ui.e4;

import org.eclipse.e4.ui.internal.css.swt.ICTabRendering;
import org.eclipse.e4.ui.internal.workbench.PartStackUtil;
import org.eclipse.e4.ui.internal.workbench.swt.AbstractPartRenderer;
import org.eclipse.e4.ui.model.application.ui.MUIElement;
import org.eclipse.e4.ui.model.application.ui.basic.MPart;
import org.eclipse.e4.ui.workbench.renderers.swt.CTabRendering;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.DBPDataSourceContainer;
import org.jkiss.dbeaver.ui.UIColors;
import org.jkiss.dbeaver.ui.UIStyles;
import org.jkiss.dbeaver.ui.UIUtils;
import org.jkiss.dbeaver.ui.css.CSSUtils;
import org.jkiss.dbeaver.utils.RuntimeUtils;

import java.lang.reflect.Field;

public final class DBeaverCTabFolderRenderer extends CTabRendering implements ICTabRendering {
    private static final Log log = Log.getLog(DBeaverCTabFolderRenderer.class);

    private static final Rectangle EMPTY_CLOSE_RECT = new Rectangle(0, 0, 0, 0);

    private static final FieldReflection<CTabRendering, Color> tabOutlineColorField;
    private static final FieldReflection<CTabRendering, Color> selectedTabHighlightColorField;
    private static final FieldReflection<CTabRendering, Color[]> selectedTabFillColorsField;
    private static final FieldReflection<CTabRendering, Color> hotUnselectedTabsColorBackgroundField;
    private static final FieldReflection<CTabItem, Integer> closeImageStateField;
    private static final FieldReflection<CTabItem, Rectangle> closeRectField;
    private static final FieldReflection<CTabFolder, ToolBar> minMaxToolBarField;

    @Nullable
    private ToolBar minMaxToolBarWithOverriddenBackground;

    static {
        tabOutlineColorField = FieldReflection.of(CTabRendering.class, "tabOutlineColor");
        selectedTabHighlightColorField = FieldReflection.of(CTabRendering.class, "selectedTabHighlightColor");
        selectedTabFillColorsField = FieldReflection.of(CTabRendering.class, "selectedTabFillColors");
        hotUnselectedTabsColorBackgroundField = FieldReflection.of(CTabRendering.class, "hotUnselectedTabsColorBackground");
        closeImageStateField = FieldReflection.of(CTabItem.class, "closeImageState");
        closeRectField = FieldReflection.of(CTabItem.class, "closeRect");
        minMaxToolBarField = FieldReflection.of(CTabFolder.class, "minMaxTb");
    }

    public DBeaverCTabFolderRenderer(@NotNull CTabFolder parent) {
        super(parent);
    }

    @Override
    protected void draw(int part, int state, Rectangle bounds, GC gc) {
        updateMinMaxToolBarBackground();

        if (part >= 0 && part < parent.getItemCount()) {
            CTabItem item = parent.getItem(part);
            Color color = getConnectionColor(item);

            if (color != null) {
                var oldTabOutlineColor = tabOutlineColorField.get(this);
                var oldHotUnselectedTabsColorBackground = hotUnselectedTabsColorBackgroundField.get(this);
                var oldSelectedTabHighlightColor = selectedTabHighlightColorField.get(this);
                var oldSelectedTabFillColors = selectedTabFillColorsField.get(this);
                var oldCloseRect = closeRectField.get(item);
                var oldCloseImageState = closeImageStateField.get(item);
                Color highlightColor = null;
                Color unselectedColor = null;
                Color hotColor = null;

                try {
                    // Removes the background behind the close button
                    if (oldCloseImageState != null && oldCloseImageState == SWT.BACKGROUND) {
                        closeRectField.set(item, EMPTY_CLOSE_RECT);
                    }

                    // Replaces unselected and selected tab colors
                    boolean isHot = (state & SWT.HOT) != 0;
                    boolean isSelected = (state & SWT.SELECTED) != 0;
                    boolean isDarkTheme = UIStyles.isDarkTheme();

                    Color fillColor = oldSelectedTabFillColors != null && oldSelectedTabFillColors.length == 1
                        ? oldSelectedTabFillColors[0]
                        : parent.getSelectionBackground();
                    highlightColor = isDarkTheme ? UIStyles.lighten(color, 0.2f) : UIStyles.darken(color, 0.2f);
                    unselectedColor = UIStyles.mix(highlightColor, fillColor, isDarkTheme ? 0.3f : 0.2f);
                    hotColor = isDarkTheme
                        ? UIStyles.darken(unselectedColor, 0.05f)
                        : UIStyles.lighten(unselectedColor, 0.05f);

                    hotUnselectedTabsColorBackgroundField.set(this, isHot ? hotColor : unselectedColor);
                    selectedTabFillColorsField.set(this, new Color[]{color});
                    selectedTabHighlightColorField.set(this, highlightColor);

                    if (!isSelected) {
                        // The outline bleeds over the hover tab. Since we're relying on SWT.HOT painting
                        // logic, we need to override it to be the same color as the tab itself
                        tabOutlineColorField.set(this, isHot ? hotColor : unselectedColor);
                    }

                    super.draw(part, state | SWT.HOT, bounds, gc);
                    drawTabSeparator(state, bounds, gc);
                } finally {
                    // Restore whatever we have changed back to original values
                    closeRectField.set(item, oldCloseRect);
                    selectedTabHighlightColorField.set(this, oldSelectedTabHighlightColor);
                    selectedTabFillColorsField.set(this, oldSelectedTabFillColors);
                    hotUnselectedTabsColorBackgroundField.set(this, oldHotUnselectedTabsColorBackground);
                    tabOutlineColorField.set(this, oldTabOutlineColor);

                    if (hotColor != null) {
                        hotColor.dispose();
                    }
                    if (unselectedColor != null && unselectedColor != highlightColor) {
                        unselectedColor.dispose();
                    }
                    if (highlightColor != null) {
                        highlightColor.dispose();
                    }
                }

                return;
            }
        }

        super.draw(part, state, bounds, gc);
        if (part >= 0 && part < parent.getItemCount()) {
            drawTabSeparator(state, bounds, gc);
        }
    }

    private void drawTabSeparator(int state, @NotNull Rectangle bounds, @NotNull GC gc) {
        if ((!isEditorStack() && !CSSUtils.isDatabaseColored(parent)) ||
            (state & SWT.SELECTED) != 0 || bounds.width <= 0 || bounds.height <= 0) {
            return;
        }

        Color oldForeground = gc.getForeground();
        int oldLineWidth = gc.getLineWidth();
        Color separatorColor = UIUtils.getColorRegistry().get(UIColors.INACTIVE_TAB_OUTLINE_COLOR);
        gc.setForeground(separatorColor != null
            ? separatorColor
            : gc.getDevice().getSystemColor(SWT.COLOR_WIDGET_NORMAL_SHADOW));
        gc.setLineWidth(1);
        boolean onBottom = parent.getTabPosition() == SWT.BOTTOM;
        int x = bounds.x + bounds.width - 1;
        gc.drawLine(x, bounds.y - (onBottom ? 1 : 0), x, bounds.y + bounds.height - (onBottom ? 1 : 0));
        gc.setLineWidth(oldLineWidth);
        gc.setForeground(oldForeground);
    }

    private boolean isEditorStack() {
        return parent.getData(AbstractPartRenderer.OWNING_ME) instanceof MUIElement element &&
            PartStackUtil.isEditorStack(element);
    }

    private void updateMinMaxToolBarBackground() {
        if (!RuntimeUtils.isWindows()) {
            return;
        }

        ToolBar toolBar = minMaxToolBarField.get(parent);
        if (toolBar == null || toolBar.isDisposed()) {
            minMaxToolBarWithOverriddenBackground = null;
            return;
        }

        if (!UIStyles.isDarkTheme()) {
            // Restore SWT defaults when switching from dark to light theme.
            if (toolBar == minMaxToolBarWithOverriddenBackground) {
                toolBar.setBackground(null);
                for (ToolItem item : toolBar.getItems()) {
                    item.setBackground(null);
                }
            }
            minMaxToolBarWithOverriddenBackground = null;
            return;
        }

        // Fix the light hover background of CTabFolder minimize/maximize buttons in dark theme.
        Color background = parent.getBackground();
        if (!background.equals(toolBar.getBackground())) {
            toolBar.setBackground(background);
        }
        for (ToolItem item : toolBar.getItems()) {
            if (!background.equals(item.getBackground())) {
                item.setBackground(background);
            }
        }
        minMaxToolBarWithOverriddenBackground = toolBar;
    }

    @Override
    protected Rectangle computeTrim(int part, int state, int x, int y, int width, int height) {
        return super.computeTrim(part, state, x, y, width, height);
    }

    @Override
    protected Point computeSize(int part, int state, GC gc, int wHint, int hHint) {
        return super.computeSize(part, state, gc, wHint, hHint);
    }

    @Nullable
    private static Color getConnectionColor(@NotNull CTabItem item) {
        if (item.getData(AbstractPartRenderer.OWNING_ME) instanceof MPart part) {
            return getConnectionColor(item, part);
        }
        for (Control control = item.getParent(); control != null; control = control.getParent()) {
            if (control.getData(AbstractPartRenderer.OWNING_ME) instanceof MPart part) {
                return getConnectionColor(item, part);
            }
        }
        return null;
    }

    @Nullable
    private static Color getConnectionColor(@NotNull CTabItem item, @NotNull MPart part) {
        DBPDataSourceContainer container = DBeaverEditorPartUtils.getDataSourceContainer(
            part, () -> {
                if (!item.isDisposed()) {
                    item.getParent().redraw();
                }
            });
        if (container != null) {
            return UIUtils.getConnectionColor(container.getConnectionConfiguration());
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private record FieldReflection<T_CLASS, T_FIELD>(@Nullable Field field) {
        static <T, R> FieldReflection<T, R> of(@NotNull Class<T> declaringClass, @NotNull String fieldName) {
            Field field = null;

            try {
                field = declaringClass.getDeclaredField(fieldName);
                field.setAccessible(true);
            } catch (ReflectiveOperationException e) {
                log.error("Cannot get field '" + fieldName + "' from class " + declaringClass.getName(), e);
            }

            return new FieldReflection<>(field);
        }

        @Nullable
        T_FIELD get(@NotNull T_CLASS object) {
            if (field == null) {
                return null;
            }
            try {
                return (T_FIELD) field.get(object);
            } catch (ReflectiveOperationException e) {
                log.error("Cannot get value of field '" + field.getName() + "' from object " + object, e);
                return null;
            }
        }

        void set(@NotNull T_CLASS object, @Nullable T_FIELD value) {
            if (field == null) {
                return;
            }
            try {
                field.set(object, value);
            } catch (ReflectiveOperationException e) {
                log.error("Cannot set value of field '" + field.getName() + "' from object " + object, e);
            }
        }
    }
}
