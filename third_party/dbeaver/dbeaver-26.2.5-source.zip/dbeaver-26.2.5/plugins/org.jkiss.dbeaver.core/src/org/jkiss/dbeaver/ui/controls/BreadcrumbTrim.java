/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.dbeaver.ui.controls;

import jakarta.annotation.PostConstruct;
import org.eclipse.e4.ui.model.application.ui.MUIElement;
import org.eclipse.e4.ui.workbench.modeling.EModelService;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.*;
import org.eclipse.ui.internal.Workbench;
import org.eclipse.ui.internal.WorkbenchWindow;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBeaverPreferences;
import org.jkiss.dbeaver.model.DBPDataSourceContainerProvider;
import org.jkiss.dbeaver.model.app.DBPProject;
import org.jkiss.dbeaver.model.navigator.DBNDatabaseNode;
import org.jkiss.dbeaver.model.navigator.DBNModel;
import org.jkiss.dbeaver.model.navigator.DBNNode;
import org.jkiss.dbeaver.runtime.DBWorkbench;
import org.jkiss.dbeaver.ui.AbstractPartListener;
import org.jkiss.dbeaver.ui.UIExecutionQueue;
import org.jkiss.dbeaver.ui.UIUtils;
import org.jkiss.dbeaver.ui.actions.AbstractPageListener;
import org.jkiss.dbeaver.ui.editors.DatabaseEditorPreferences.BreadcrumbLocation;
import org.jkiss.dbeaver.ui.editors.ILazyEditorInput;
import org.jkiss.dbeaver.ui.editors.INavigatorEditorInput;
import org.jkiss.dbeaver.ui.editors.MultiPageAbstractEditor;
import org.jkiss.dbeaver.ui.navigator.breadcrumb.NodeBreadcrumbViewer;

import java.util.function.Consumer;

public class BreadcrumbTrim {
    private static final String STATUS_CONTROLS_ID = "org.jkiss.dbeaver.core.ui.Breadcrumb"; //$NON-NLS-1$
    private static final String BOTTOM_TRIM_ID = "org.eclipse.ui.trim.status"; //$NON-NLS-1$

    @PostConstruct
    public void createControls(@NotNull Composite parent) {
        if (!DBWorkbench.getPlatform().getApplication().isStandalone()) {
            // don't add breadcrumb to status line for DBeaver as Eclipse plugin
            return;
        }
        Composite composite = UIUtils.createPlaceholder(parent, 2, 0);
        ((GridLayout) composite.getLayout()).marginLeft = 5;
        ProjectsPanel projectsPanel = new ProjectsPanel(composite);
        var viewer = new NodeBreadcrumbViewer(composite, SWT.BOTTOM);

        installListeners(viewer);
        UIUtils.asyncExec(() -> updateElementVisibility(viewer));
    }

    private static void updateElementVisibility(@NotNull NodeBreadcrumbViewer viewer) {
        var store = DBWorkbench.getPlatform().getPreferenceStore();
        var breadcrumbsVisible = BreadcrumbLocation.get(store) == BreadcrumbLocation.IN_STATUS_BAR;
        if (!viewer.getControl().isDisposed()) {
            UIUtils.setControlVisible(viewer.getControl(), breadcrumbsVisible);
            viewer.getControl().getParent().layout(true, true);
        }

        refreshStatusBar();
    }

    public static void refreshStatusBar() {
        for (IWorkbenchWindow window : Workbench.getInstance().getWorkbenchWindows()) {
            if (window instanceof WorkbenchWindow workbenchWindow) {
                updateElementVisibility(workbenchWindow);
            }
        }
    }

    private static void updateElementVisibility(@NotNull WorkbenchWindow window) {
        var store = DBWorkbench.getPlatform().getPreferenceStore();
        var model = window.getModel();
        var modelService = window.getService(EModelService.class);

        boolean dirty = false;

        var statusControlsElement = modelService.find(STATUS_CONTROLS_ID, model);
        if (statusControlsElement != null && !statusControlsElement.isToBeRendered()) {
            statusControlsElement.setToBeRendered(true);
            dirty = true;
        }

        var statusLineVisible = store.getBoolean(DBeaverPreferences.UI_STATUS_BAR_SHOW_STATUS_LINE);
        if (statusLineVisible) {
            MUIElement statusLineElement = modelService.find(WorkbenchWindow.STATUS_LINE_ID, model);
            if (statusLineElement != null && !statusLineElement.isToBeRendered()) {
                statusLineElement.setToBeRendered(true);
                dirty = true;
            }
        }
        MUIElement element = modelService.find(BOTTOM_TRIM_ID, model);
        if (element != null) {
            if (element.isVisible() != statusLineVisible) {
                element.setVisible(statusLineVisible);
                dirty = true;
            }
            if (element.getWidget() instanceof Composite composite && !composite.isDisposed()) {
                if (composite.getVisible() != statusLineVisible) {
                    composite.setVisible(statusLineVisible);
                    dirty = true;
                }
            }
            if (dirty) {
                window.getShell().layout(true, true);
            }
        }
    }

    private static void installListeners(@NotNull NodeBreadcrumbViewer viewer) {
        var propertyListener = new IPropertyListener() {
            @Override
            public void propertyChanged(Object source, int propId) {
                if (propId != IEditorPart.PROP_INPUT && propId != IEditorPart.PROP_DIRTY) {
                    return;
                }
                if (source instanceof IEditorPart editorPart) {
                    setInput(viewer, editorPart.getEditorInput());
                }
            }
        };

        var partListener = new AbstractPartListener() {
            IEditorPart lastEditorPart;

            @Override
            public void partActivated(IWorkbenchPart part) {
                if (part instanceof IEditorPart editorPart) {
                    UIExecutionQueue.queueExec(() -> setLastEditorPart(editorPart, true));
                }
            }

            @Override
            public void partClosed(IWorkbenchPart part) {
                if (part instanceof IEditorPart editorPart) {
                    UIExecutionQueue.queueExec(() -> {
                        setLastEditorPart(editorPart, false);
                        viewer.disposeContextMenuSite(editorPart.getSite());
                    });
                }
            }

            private void setLastEditorPart(@Nullable IEditorPart part, boolean activated) {
                if (viewer.getControl() == null || viewer.getControl().isDisposed()) {
                    return;
                }
                // If activated, then part != lastEditorPart, otherwise part == lastEditorPart
                boolean shouldRemoveLastEditor = activated != (lastEditorPart == part) && lastEditorPart != null;
                boolean shouldSetLastEditor = activated && part != null;
                if (shouldRemoveLastEditor) {
                    lastEditorPart.removePropertyListener(propertyListener);
                    lastEditorPart = null;
                    viewer.setSelectionSiteSupplier(null);
                    viewer.setContextMenuSite(null);
                    viewer.setInput(null);
                }
                if (shouldSetLastEditor) {
                    lastEditorPart = part;
                    lastEditorPart.addPropertyListener(propertyListener);
                    viewer.setSelectionSiteSupplier(() -> {
                        if (part instanceof MultiPageAbstractEditor multiPageEditor) {
                            IEditorPart editor = multiPageEditor.getActiveEditor();
                            if (editor != null) {
                                return editor.getSite();
                            }
                        }
                        return part.getSite();
                    });
                    viewer.setContextMenuSite(part.getSite());
                    setInput(viewer, part.getEditorInput());
                }
            }
        };

        var pageListener = new AbstractPageListener() {
            @Override
            public void pageOpened(IWorkbenchPage page) {
                page.addPartListener(partListener);
            }

            @Override
            public void pageClosed(IWorkbenchPage page) {
                page.removePartListener(partListener);
            }
        };

        IWorkbenchWindow window = UIUtils.getActiveWorkbenchWindow();
        window.addPageListener(pageListener);

        for (IWorkbenchPage page : window.getPages()) {
            page.addPartListener(partListener);
        }
        IWorkbenchPage activePage = window.getActivePage();
        if (activePage != null && activePage.getActiveEditor() != null) {
            partListener.partActivated(activePage.getActiveEditor());
        }

        DBWorkbench.getPlatform().getPreferenceStore().addPropertyChangeListener(event -> {
            switch (event.getProperty()) {
                case DBeaverPreferences.UI_STATUS_BAR_SHOW_BREADCRUMBS:
                case DBeaverPreferences.UI_STATUS_BAR_SHOW_STATUS_LINE:
                    updateElementVisibility(viewer);
                    break;
                default:
                    break;
            }
        });
    }

    private static void setInput(@NotNull NodeBreadcrumbViewer viewer, @NotNull IEditorInput input) {
        if (viewer.getControl().isDisposed()) {
            return;
        }
        if (!tryExtractNode(input, viewer::setInput)) {
            viewer.setInput(null);
        }
    }

    private static boolean tryExtractNode(@NotNull IEditorInput input, @NotNull Consumer<? super DBNNode> consumer) {
        if (input instanceof ILazyEditorInput lazyEditorInput && input instanceof DBPDataSourceContainerProvider provider) {
            DBPProject project = lazyEditorInput.getProject();
            if (project == null || !project.isOpen() || !project.isRegistryLoaded()) {
                return false;
            }
            DBNModel navigatorModel = project.getNavigatorModel();
            if (navigatorModel != null) {
                DBNDatabaseNode node = navigatorModel.findNode(provider.getDataSourceContainer());
                if (node != null) {
                    consumer.accept(node);
                    return true;
                }
            }
        }
        if (input instanceof INavigatorEditorInput navigatorEditorInput) {
            DBNNode node = navigatorEditorInput.getNavigatorNode();
            if (node != null) {
                consumer.accept(node);
                return true;
            }
        }
        return false;
    }
}
