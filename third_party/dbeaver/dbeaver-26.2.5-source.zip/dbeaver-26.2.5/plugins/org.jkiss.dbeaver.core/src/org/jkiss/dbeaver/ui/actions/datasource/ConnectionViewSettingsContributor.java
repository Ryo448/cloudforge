/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.dbeaver.ui.actions.datasource;

import org.eclipse.jface.action.*;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.IWorkbenchPage;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.DBPDataSourceContainer;
import org.jkiss.dbeaver.model.navigator.DBNBrowseSettings;
import org.jkiss.dbeaver.model.navigator.DBNDatabaseNode;
import org.jkiss.dbeaver.registry.DataSourceDescriptor;
import org.jkiss.dbeaver.registry.DataSourceNavigatorSettings;
import org.jkiss.dbeaver.registry.DataSourceNavigatorSettingsUtils;
import org.jkiss.dbeaver.registry.internal.RegistryMessages;
import org.jkiss.dbeaver.runtime.DBWorkbench;
import org.jkiss.dbeaver.runtime.ui.UIServiceConnections;
import org.jkiss.dbeaver.ui.DBeaverIcons;
import org.jkiss.dbeaver.ui.internal.UIConnectionMessages;
import org.jkiss.dbeaver.ui.UIIcon;
import org.jkiss.dbeaver.ui.UIUtils;
import org.jkiss.dbeaver.ui.actions.AbstractDataSourceHandler;
import org.jkiss.dbeaver.ui.dialogs.connection.EditConnectionNavigatorSettingsDialog;
import org.jkiss.dbeaver.ui.internal.UINavigatorMessages;
import org.jkiss.dbeaver.ui.navigator.INavigatorModelView;
import org.jkiss.dbeaver.ui.navigator.NavigatorPreferences;

import java.util.List;

public class ConnectionViewSettingsContributor extends DataSourceMenuContributor {
    private static final Log log = Log.getLog(ConnectionViewSettingsContributor.class);

    @Override
    protected void fillContributionItems(@NotNull List<IContributionItem> menuItems) {
        DBPDataSourceContainer dsContainer = AbstractDataSourceHandler.getDataSourceContainerFromPart(UIUtils.getActiveWorkbenchWindow()
            .getActivePage().getActivePart());
        if (dsContainer == null) {
            return;
        }

        MenuManager customizeViewMenu = new MenuManager(RegistryMessages.navigator_settings_customize_view);
        customizeViewMenu.setImageDescriptor(DBeaverIcons.getImageDescriptor(UIIcon.SHOW_ALL_DETAILS));
        addPresetSettings(customizeViewMenu, dsContainer);
        addSystemObjects(customizeViewMenu, dsContainer);
        addAdditionalSettings(customizeViewMenu, dsContainer);
        menuItems.add(customizeViewMenu);
    }

    private void addPresetSettings(@NotNull MenuManager customizeViewMenu, @NotNull DBPDataSourceContainer dsContainer) {
        DBNBrowseSettings chosenSettings = dsContainer.getNavigatorSettings();
        boolean presetChecked = false;
        for (DataSourceNavigatorSettings.Preset preset : DataSourceNavigatorSettings.PRESETS.values()) {
            if (preset == DataSourceNavigatorSettings.PRESET_CUSTOM) {
                continue;
            }
            boolean isChecked = preset.getSettings().equals(chosenSettings);
            if (isChecked) {
                presetChecked = true;
            }
            customizeViewMenu.add(new UseSettingsPresetAction(dsContainer, preset, isChecked));
        }
        customizeViewMenu.add(new UseSettingsCustomAction(dsContainer, !presetChecked));
        customizeViewMenu.add(new Separator());
    }

    private void addSystemObjects(@NotNull MenuManager customizeViewMenu, @NotNull DBPDataSourceContainer dsContainer) {
        customizeViewMenu.add(new ShowSystemObjectsAction(dsContainer));
        customizeViewMenu.add(new Separator());
    }

    private void addAdditionalSettings(@NotNull MenuManager customizeViewMenu, @NotNull DBPDataSourceContainer dsContainer) {
        customizeViewMenu.add(new ShowHostNameAction(dsContainer));
        customizeViewMenu.add(new ShowObjectsDescriptionAction(dsContainer));
        customizeViewMenu.add(new ShowStatisticsAction(dsContainer));
        customizeViewMenu.add(new ShowStatusIconsAction(dsContainer));
        if (DBWorkbench.isDistributed()) {
            addClearUserSettingsAction(customizeViewMenu, dsContainer);
        }
    }


    private void addClearUserSettingsAction(@NotNull MenuManager customizeViewMenu, @NotNull DBPDataSourceContainer dsContainer) {
        Separator separator = new Separator();
        ClearCurrentUserSettings settingsClearAction = new ClearCurrentUserSettings(dsContainer);
        ActionContributionItem clearUserSettings = new ActionContributionItem(settingsClearAction);
        settingsClearAction.setSeparator(separator);
        settingsClearAction.setClearUserSettings(clearUserSettings);
        settingsClearAction.visibleCheck();
        customizeViewMenu.add(separator);
        customizeViewMenu.add(clearUserSettings);
    }

    private abstract static class SettingsAction extends Action {
        final DBPDataSourceContainer dsContainer;

        SettingsAction(@NotNull DBPDataSourceContainer dsContainer, @Nullable String name, int style) {
            super(name, style);
            this.dsContainer = dsContainer;
        }

        void updateSettings(@NotNull DBNBrowseSettings settings) {
            if (isUseUserSettings() && settings instanceof DataSourceNavigatorSettings dataSourceNavigatorSettings) {
                try {
                    DataSourceNavigatorSettingsUtils.updateCustomNavigatorSettings(dsContainer, dataSourceNavigatorSettings);
                    dataSourceNavigatorSettings.setUserSettings(true);
                } catch (DBException e) {
                    log.error("Error updating custom navigator settings", e);
                    return;
                }
            } else {
                ((DataSourceDescriptor) this.dsContainer).setNavigatorSettings(settings);
                dsContainer.persistConfiguration();
            }
            askToReconnectIfNeeded();
            refreshNavigator();
        }

        private boolean isUseUserSettings() {
            return DBWorkbench.isDistributed()
                && !dsContainer.getProject().isPrivateProject();
        }

        protected void askToReconnectIfNeeded() {
            UIServiceConnections serviceConnections = DBWorkbench.getService(UIServiceConnections.class);
            if (serviceConnections != null) {
                serviceConnections.askToReconnect(dsContainer);
            }
        }

        void refreshNavigator() {
            if (dsContainer.getProject().getNavigatorModel() != null) {
                DBNDatabaseNode node = dsContainer.getProject().getNavigatorModel().findNode(dsContainer);
                UIUtils.asyncExec(() -> refreshNavigatorInUI(node));
            }
        }

        private void refreshNavigatorInUI(@Nullable DBNDatabaseNode node) {
            IWorkbenchPage activePage = UIUtils.getActiveWorkbenchWindow().getActivePage();
            if (activePage == null) {
                return;
            }
            for (IViewReference viewReference : activePage.getViewReferences()) {
                IViewPart view = viewReference.getView(false);
                if (!(view instanceof INavigatorModelView navigatorModelView)) {
                    continue;
                }
                Viewer navigatorViewer = navigatorModelView.getNavigatorViewer();
                if (navigatorViewer == null) {
                    continue;
                }

                Control control = navigatorViewer.getControl();
                if (control == null || control.isDisposed()) {
                    continue;
                }
                if (node != null && navigatorViewer instanceof StructuredViewer structuredViewer) {
                    structuredViewer.refresh(node, true);
                } else {
                    navigatorViewer.refresh();
                }
                control.redraw();
            }
        }
    }

    private static class UseSettingsPresetAction extends SettingsAction {
        private final DataSourceNavigatorSettings.Preset preset;

        UseSettingsPresetAction(
            @NotNull DBPDataSourceContainer dsContainer,
            @NotNull DataSourceNavigatorSettings.Preset preset,
            boolean checked
        ) {
            super(dsContainer, preset.getName(), AS_RADIO_BUTTON);
            this.preset = preset;
            setToolTipText(preset.getDescription());
            setChecked(checked);
        }

        @Override
        public void run() {
            if (isChecked()) {
                updateSettings(preset.getSettings());
            }
        }
    }

    private static class UseSettingsCustomAction extends SettingsAction {
        UseSettingsCustomAction(@NotNull DBPDataSourceContainer dsContainer, boolean checked) {
            super(dsContainer, DataSourceNavigatorSettings.PRESET_CUSTOM.getName() + " ...", AS_RADIO_BUTTON);
            setToolTipText(DataSourceNavigatorSettings.PRESET_CUSTOM.getDescription());
            setChecked(checked);
        }

        @Override
        public void run() {
            if (!isChecked() || UIUtils.getActiveWorkbenchShell() == null) {
                return;
            }
            EditConnectionNavigatorSettingsDialog dialog = new EditConnectionNavigatorSettingsDialog(
                UIUtils.getActiveWorkbenchShell(),
                dsContainer.getNavigatorSettings(),
                dsContainer);
            if (dialog.open() == IDialogConstants.OK_ID) {
                updateSettings(dialog.getNavigatorSettings());
            }
        }
    }

    private static class ShowSystemObjectsAction extends SettingsAction {
        ShowSystemObjectsAction(@NotNull DBPDataSourceContainer container) {
            super(container, UIConnectionMessages.dialog_connection_wizard_final_checkbox_show_system_objects, AS_CHECK_BOX);
            setToolTipText(UIConnectionMessages.dialog_connection_wizard_final_checkbox_show_system_objects_tip);
            setChecked(container.getNavigatorSettings().isShowSystemObjects());
        }

        @Override
        public void run() {
            DataSourceNavigatorSettings newSettings = new DataSourceNavigatorSettings(dsContainer.getNavigatorSettings());
            newSettings.setShowSystemObjects(isChecked());
            updateSettings(newSettings);
        }
    }

    private static class ShowHostNameAction extends SettingsAction {
        ShowHostNameAction(@NotNull DBPDataSourceContainer container) {
            super(container, UINavigatorMessages.pref_page_database_general_label_show_host_name, AS_CHECK_BOX);
            setToolTipText(UINavigatorMessages.pref_page_database_general_label_show_host_name_tip);
            setChecked(DBWorkbench.getPlatform().getPreferenceStore().getBoolean(NavigatorPreferences.NAVIGATOR_SHOW_CONNECTION_HOST_NAME));
        }

        @Override
        public void run() {
            DBWorkbench.getPlatform().getPreferenceStore().setValue(NavigatorPreferences.NAVIGATOR_SHOW_CONNECTION_HOST_NAME, isChecked());
            refreshNavigator();
        }
    }

    private static class ShowObjectsDescriptionAction extends SettingsAction {
        ShowObjectsDescriptionAction(@NotNull DBPDataSourceContainer container) {
            super(container, UINavigatorMessages.pref_page_database_general_label_show_objects_description, AS_CHECK_BOX);
            setToolTipText(UINavigatorMessages.pref_page_database_general_label_show_objects_description_tip);
            setChecked(DBWorkbench.getPlatform().getPreferenceStore().getBoolean(NavigatorPreferences.NAVIGATOR_SHOW_OBJECTS_DESCRIPTION));
        }

        @Override
        public void run() {
            DBWorkbench.getPlatform().getPreferenceStore().setValue(NavigatorPreferences.NAVIGATOR_SHOW_OBJECTS_DESCRIPTION, isChecked());
            refreshNavigator();
        }
    }

    private static class ShowStatisticsAction extends SettingsAction {
        ShowStatisticsAction(@NotNull DBPDataSourceContainer container) {
            super(container, UINavigatorMessages.pref_page_database_general_label_show_statistics, AS_CHECK_BOX);
            setToolTipText(UINavigatorMessages.pref_page_database_general_label_show_statistics_tip);
            setChecked(DBWorkbench.getPlatform().getPreferenceStore().getBoolean(NavigatorPreferences.NAVIGATOR_SHOW_STATISTICS_INFO));
        }

        @Override
        public void run() {
            DBWorkbench.getPlatform().getPreferenceStore().setValue(NavigatorPreferences.NAVIGATOR_SHOW_STATISTICS_INFO, isChecked());
            refreshNavigator();
        }
    }

    private static class ShowStatusIconsAction extends SettingsAction {
        ShowStatusIconsAction(@NotNull DBPDataSourceContainer container) {
            super(container, UINavigatorMessages.pref_page_database_general_label_show_node_actions, AS_CHECK_BOX);
            setToolTipText(UINavigatorMessages.pref_page_database_general_label_show_node_actions_tip);
            setChecked(DBWorkbench.getPlatform().getPreferenceStore().getBoolean(NavigatorPreferences.NAVIGATOR_SHOW_NODE_ACTIONS));
        }

        @Override
        public void run() {
            DBWorkbench.getPlatform().getPreferenceStore().setValue(NavigatorPreferences.NAVIGATOR_SHOW_NODE_ACTIONS, isChecked());
            refreshNavigator();
        }
    }

    private static class ClearCurrentUserSettings extends SettingsAction {

        private Separator separator;
        private ActionContributionItem clearUserSettings;


        public ClearCurrentUserSettings(@NotNull DBPDataSourceContainer container) {
            super(container, UINavigatorMessages.dialog_connection_set_default_connection_settings, AS_PUSH_BUTTON);
            setToolTipText(UINavigatorMessages.dialog_connection_set_default_connection_settings_tip);
        }

        @Override
        public void run() {
            clearCurrentUserSettings();
            refreshNavigator();
        }

        public void setSeparator(@NotNull Separator separator) {
            this.separator = separator;
        }

        public void setClearUserSettings(@NotNull ActionContributionItem clearUserSettings) {
            this.clearUserSettings = clearUserSettings;
        }

        @Override
        protected void updateSettings(@NotNull DBNBrowseSettings settings) {
            super.updateSettings(settings);
            visibleCheck();
        }

        private void clearCurrentUserSettings() {
            if (DBWorkbench.isDistributed()) {
                try {
                    DataSourceNavigatorSettingsUtils.clearCustomNavigatorSettings(dsContainer);
                } catch (DBException logged) {
                    log.error("Error clearing custom navigator settings", logged);
                }
            }
            askToReconnectIfNeeded();
            visibleCheck();
        }

        public void visibleCheck() {
            boolean isVisible = dsContainer.getNavigatorSettings().isUserSettings();
            separator.setVisible(isVisible);
            clearUserSettings.setVisible(isVisible);
        }
    }


}
