/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.dbeaver.ui.preferences;

public final class PrefPageConstants {

    public static final String WORKBENCH_PREF_PAGE_ID = "org.eclipse.ui.preferencePages.Workbench";
    public static final String APPEARANCE_PREF_PAGE_ID = "org.eclipse.ui.preferencePages.Views";
    public static final String EDITORS_PREF_PAGE_ID = "org.eclipse.ui.preferencePages.Editors";

    public static final String P2_PROVISIONING_PREF_PAGE_ID = "org.eclipse.equinox.internal.p2.ui.sdk.ProvisioningPreferencePage";
    public static final String P2_SITES_PREF_PAGE_ID = "org.eclipse.equinox.internal.p2.ui.sdk.SitesPreferencePage";

    private PrefPageConstants() {
    }
}
