/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.dbeaver.ext.altibase.model;

import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.model.data.DBDInsertReplaceMethod;
import org.jkiss.dbeaver.model.runtime.DBRProgressMonitor;
import org.jkiss.dbeaver.model.struct.DBSAttributeBase;
import org.jkiss.dbeaver.model.struct.rdb.DBSTable;

public class AltibaseInsertReplaceMethod implements DBDInsertReplaceMethod {

    @Nullable
    @Override
    public String getOpeningClause(@NotNull DBRProgressMonitor monitor, @NotNull DBSTable table) {
        return "UPDATE OR INSERT INTO";
    }

    @Nullable
    @Override
    public String getTrailingClause(@NotNull DBRProgressMonitor monitor, @NotNull DBSTable table, @NotNull DBSAttributeBase[] attributes) {
        return null;
    }
}
