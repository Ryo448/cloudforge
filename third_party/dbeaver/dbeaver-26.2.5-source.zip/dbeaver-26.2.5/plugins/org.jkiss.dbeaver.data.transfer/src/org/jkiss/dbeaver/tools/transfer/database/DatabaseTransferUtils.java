/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.dbeaver.tools.transfer.database;

import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.*;
import org.jkiss.dbeaver.model.edit.*;
import org.jkiss.dbeaver.model.exec.*;
import org.jkiss.dbeaver.model.impl.DBObjectNameCaseTransformer;
import org.jkiss.dbeaver.model.impl.edit.AbstractCommandContext;
import org.jkiss.dbeaver.model.impl.edit.SQLDatabasePersistAction;
import org.jkiss.dbeaver.model.impl.sql.edit.SQLObjectEditor;
import org.jkiss.dbeaver.model.navigator.DBNModel;
import org.jkiss.dbeaver.model.navigator.DBNUtils;
import org.jkiss.dbeaver.model.preferences.DBPPreferenceStore;
import org.jkiss.dbeaver.model.preferences.DBPPropertyDescriptor;
import org.jkiss.dbeaver.model.runtime.DBRProgressMonitor;
import org.jkiss.dbeaver.model.sql.SQLUtils;
import org.jkiss.dbeaver.model.struct.*;
import org.jkiss.dbeaver.model.struct.rdb.DBSCatalog;
import org.jkiss.dbeaver.model.struct.rdb.DBSSchema;
import org.jkiss.dbeaver.runtime.DBWorkbench;
import org.jkiss.dbeaver.runtime.properties.ObjectPropertyDescriptor;
import org.jkiss.dbeaver.runtime.properties.PropertySourceEditable;
import org.jkiss.dbeaver.tools.transfer.internal.DTActivator;
import org.jkiss.utils.BeanUtils;
import org.jkiss.utils.CommonUtils;
import org.jkiss.utils.Pair;

import java.util.*;

/**
* DatabaseTransferUtils
*/
public class DatabaseTransferUtils {

    private static final Log log = Log.getLog(DatabaseTransferUtils.class);

    private static final boolean USE_STRUCT_DDL = true;

    private static final Pair<DBPDataKind, String> DATA_TYPE_UNKNOWN = new Pair<>(DBPDataKind.UNKNOWN, null);
    private static final Pair<DBPDataKind, String> DATA_TYPE_INTEGER = new Pair<>(DBPDataKind.NUMERIC, "INTEGER");
    private static final Pair<DBPDataKind, String> DATA_TYPE_BIGINT = new Pair<>(DBPDataKind.NUMERIC, "BIGINT");
    private static final Pair<DBPDataKind, String> DATA_TYPE_REAL = new Pair<>(DBPDataKind.NUMERIC, "REAL");
    private static final Pair<DBPDataKind, String> DATA_TYPE_BOOLEAN = new Pair<>(DBPDataKind.BOOLEAN, "BOOLEAN");
    private static final Pair<DBPDataKind, String> DATA_TYPE_STRING = new Pair<>(DBPDataKind.STRING, "VARCHAR");
    private static final Pair<DBPDataKind, String> DATA_TYPE_NATIONAL_STRING = new Pair<>(DBPDataKind.STRING, "NVARCHAR");

    public static void refreshDatabaseModel(DBRProgressMonitor monitor, DatabaseConsumerSettings consumerSettings, DatabaseMappingContainer containerMapping) throws DBException {
        monitor.subTask("Refresh database model");
        DBSObjectContainer container = consumerSettings.getContainer();
        DBNModel navigatorModel = DBNUtils.getNavigatorModel(container);

        boolean refreshed = false;
        if (navigatorModel != null) {
            var containerNode = navigatorModel.getNodeByObject(monitor, container, false);
            if (containerNode != null) {
                containerNode.refreshNode(monitor, containerMapping);
                refreshed = true;
            }
        }
        if (!refreshed && container instanceof DBPRefreshableObject refreshableObject) {
            refreshableObject.refreshObject(monitor);
        }
        refreshDatabaseMappings(monitor, consumerSettings, containerMapping, false);
    }

    public static void refreshDatabaseMappings(@NotNull DBRProgressMonitor monitor, @NotNull DatabaseConsumerSettings consumerSettings, @Nullable DatabaseMappingContainer containerMapping, boolean force) throws DBException {
        DBSObjectContainer container = consumerSettings.getContainer();
        if (container == null) {
            log.debug("Null target container");
            return;
        }
        if (containerMapping == null) {
            log.debug("Null container mapping");
            return;
        }

        // Reflect database changes in mappings
        {
            boolean updateMappingTarget = false;
            boolean updateMappingAttributes = false;

            switch (containerMapping.getMappingType()) {
                case create:
                case recreate:
                    updateMappingTarget = true;
                    updateMappingAttributes = true;
                    break;
                case existing:
                    updateMappingTarget = false;
                    updateMappingAttributes = true;
                    break;
                default:
                    break;
            }

            if (updateMappingTarget || force) {
                monitor.subTask("Refresh database mappings");

                DBSObject newTarget = container.getChild(monitor, DBUtils.getUnQuotedIdentifier(container.getDataSource(), containerMapping.getTargetName()));
                if (newTarget == null) {
                    throw new DBCException("New table " + containerMapping.getTargetName() + " not found in container " + DBUtils.getObjectFullName(container, DBPEvaluationContext.UI));
                } else if (!(newTarget instanceof DBSDataManipulator)) {
                    throw new DBCException("New table " + DBUtils.getObjectFullName(newTarget, DBPEvaluationContext.UI) + " doesn't support data manipulation");
                }
                setMappingTarget(containerMapping, (DBSDataManipulator) newTarget);
            }

            if (updateMappingAttributes || force) {
                for (DatabaseMappingAttribute attr : containerMapping.getAttributeMappings(monitor)) {
                    if (attr.getMappingType() == DatabaseMappingType.create || (attr.getMappingType().isValid() && force)) {
                        attr.updateMappingType(monitor, false, false);
                        if (attr.getTarget() == null) {
                            log.debug("Can't find target attribute '" + attr.getTargetName() + "' in '" + containerMapping.getTargetName() + "'");
                        }
                    }
                }
            }
        }
    }

    static void setMappingTarget(
        @NotNull DatabaseMappingContainer containerMapping,
        @NotNull DBSDataManipulator target
    ) {
        containerMapping.setTarget(target);
        if (containerMapping.getMappingType() == DatabaseMappingType.create) {
            containerMapping.setMappingType(DatabaseMappingType.existing);
        }
    }

    /**
     * Method generates array of actions for table creation for containers with correct mapping type.
     * Has old code inside with the simple table creations.
     *
     * @param monitor progress monitor
     * @param executionContext execution context for DDL generation
     * @param schema table container
     * @param containerMapping mapping container can not be null
     * @param changedProperties list of properties what feature table must have
     * @return array of persist actions table creation
     * @throws DBException on any DB error
     */
    public static DBEPersistAction[] generateTargetTableDDL(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBCExecutionContext executionContext,
        @NotNull DBSObjectContainer schema,
        @NotNull DatabaseMappingContainer containerMapping,
        @Nullable Map<DBPPropertyDescriptor, Object> changedProperties) throws DBException {
        return generateTargetTableDDL(monitor, executionContext, schema, containerMapping, changedProperties, null);
    }

    /**
     * Method generates array of actions for table creation and optional key migration.
     *
     * @param monitor progress monitor
     * @param executionContext execution context for DDL generation
     * @param schema table container
     * @param containerMapping mapping container can not be null
     * @param changedProperties list of properties what feature table must have
     * @param consumerSettings transfer settings; when set, PK/FK migration flags are respected
     * @return array of persist actions table creation
     * @throws DBException on any DB error
     */
    @NotNull
    public static DBEPersistAction[] generateTargetTableDDL(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBCExecutionContext executionContext,
        @NotNull DBSObjectContainer schema,
        @NotNull DatabaseMappingContainer containerMapping,
        @Nullable Map<DBPPropertyDescriptor, Object> changedProperties,
        @Nullable DatabaseConsumerSettings consumerSettings
    ) throws DBException {
        if (containerMapping.getMappingType() == DatabaseMappingType.skip) {
            return new DBEPersistAction[0];
        }
        boolean hasExtraTargetStructure = consumerSettings != null && consumerSettings.hasExtraTargetStructure();
        // Check whether we have any changes in mappings
        if (containerMapping.getMappingType() == DatabaseMappingType.existing) {
            boolean hasChanges = false;
            for (DatabaseMappingAttribute attr : containerMapping.getAttributeMappings(monitor)) {
                if (attr.getMappingType() != DatabaseMappingType.existing &&
                    attr.getMappingType() != DatabaseMappingType.skip) {
                    hasChanges = true;
                    break;
                }
            }
            if (!hasChanges && !hasExtraTargetStructure) {
                return new DBEPersistAction[0];
            }
        }
        monitor.subTask("Validate table structure table '" + containerMapping.getTargetName() + "'");
        if (USE_STRUCT_DDL) {
            try {
                final List<DBEPersistAction> actions = new ArrayList<>();
                generateStructTableDDL(monitor, executionContext, schema, containerMapping, actions, changedProperties);
                if (hasExtraTargetStructure) {
                    Collections.addAll(actions, consumerSettings.generateExtraTargetTableDDL(
                        monitor, executionContext, schema, containerMapping));
                }
                return actions.toArray(DBEPersistAction[]::new);
            } catch (DBException e) {
                DBWorkbench.getPlatformUI().showError("Can't create or update target table", null, e);
                if (!DBWorkbench.getPlatformUI().confirmAction(
                    "Generate DDL automatically",
                    "Do you want to create or update target object with auto-generated SQL script?")) {
                    throw new DBException("Target table create or update was canceled");
                }
            }
        }

        // Struct doesn't work (no proper object managers?)
        // Try plain SQL mode

        DBPDataSource dataSource = executionContext.getDataSource();

        String tableName;
        if (containerMapping.getMappingType() == DatabaseMappingType.create) {
            tableName = getTransformedName(dataSource, containerMapping.getTargetName(), false);
        } else {
            tableName = DBObjectNameCaseTransformer.transformName(dataSource, containerMapping.getTargetName());
        }
        containerMapping.setTargetName(tableName);

        if (CommonUtils.isEmpty(tableName)) {
            return new DBEPersistAction[0];
        }

        List<DBEPersistAction> actions = new ArrayList<>();
        StringBuilder sql = new StringBuilder(500);

        if (containerMapping.getMappingType() == DatabaseMappingType.recreate && containerMapping.getTarget() != null) {
            sql.append("DROP TABLE ");
            getTableFullName(schema, dataSource, sql, tableName);
            sql.append(dataSource.getSQLDialect().getScriptDelimiters()[0]);
        }

        if (containerMapping.hasNewTargetObject()) {
            sql.append("CREATE TABLE ");
            getTableFullName(schema, dataSource, sql, tableName);
            sql.append("(\n");
            Map<DBSAttributeBase, DatabaseMappingAttribute> mappedAttrs = new HashMap<>();
            for (DatabaseMappingAttribute attr : containerMapping.getAttributeMappings(monitor)) {
                if (attr.getMappingType() != DatabaseMappingType.create) {
                    continue;
                }
                if (!mappedAttrs.isEmpty()) {
                    sql.append(",\n");
                }
                sql.append("\t");
                appendAttributeClause(monitor, dataSource, sql, attr);
                mappedAttrs.put(attr.getSource(), attr);
            }
            if (!hasExtraTargetStructure && containerMapping.getSource() instanceof DBSEntity) {
                // Make primary key
                Collection<? extends DBSEntityAttribute> identifier = DBUtils.getBestTableIdentifier(monitor, (DBSEntity) containerMapping.getSource());
                if (!CommonUtils.isEmpty(identifier)) {
                    boolean idMapped = true;
                    for (DBSEntityAttribute idAttr : identifier) {
                        if (!mappedAttrs.containsKey(idAttr)) {
                            idMapped = false;
                            break;
                        }
                    }
                    if (idMapped) {
                        sql.append(",\n\tPRIMARY KEY (");
                        boolean hasAttr = false;
                        for (DBSEntityAttribute idAttr : identifier) {
                            DatabaseMappingAttribute mappedAttr = mappedAttrs.get(idAttr);
                            if (hasAttr) sql.append(",");
                            sql.append(DBUtils.getQuotedIdentifier(dataSource, mappedAttr.getTargetName()));
                            hasAttr = true;
                        }
                        sql.append(")\n");
                    }
                }
            }
            sql.append(")");
            actions.add(new SQLDatabasePersistAction("Table DDL", sql.toString()));
        } else {
            for (DatabaseMappingAttribute attr : containerMapping.getAttributeMappings(monitor)) {
                if (attr.getMappingType() == DatabaseMappingType.create) {
                    actions.add(generateTargetAttributeDDL(monitor, dataSource, attr));
                }
            }
        }
        if (hasExtraTargetStructure) {
            Collections.addAll(actions, consumerSettings.generateExtraTargetTableDDL(
                monitor, executionContext, schema, containerMapping));
        }
        return actions.toArray(new DBEPersistAction[0]);
    }

    /**
     * Transform target mapping name by mapping rules (if we have them)
     *
     * @param dataSource for preferences and dialect info
     * @param targetName name for transformation
     * @param skipCaseChanging true if we do not want to change name case of the original name
     * @return transformed target name (container or attribute)
     */
    @NotNull
    public static String getTransformedName(@NotNull DBPDataSource dataSource, @NotNull String targetName, boolean skipCaseChanging) {
        String finalName = targetName;
        DBPPreferenceStore dbpPreferenceStore = dataSource.getContainer().getPreferenceStore();
        DBPPreferenceStore store = DTActivator.getDefault().getPreferences();
        MappingNameCase nameCase = MappingNameCase.getCaseFromPreferences(dbpPreferenceStore, store);
        MappingReplaceMechanism mechanism = MappingReplaceMechanism.getCaseFromPreferences(dbpPreferenceStore, store);
        if (nameCase != MappingNameCase.DEFAULT) {
            finalName = nameCase.getIdentifierCase().transform(targetName);
        } else if (!skipCaseChanging && mechanism != MappingReplaceMechanism.CAMELCASE) {
            finalName = DBObjectNameCaseTransformer.transformName(dataSource, targetName);
        }
        if (mechanism != MappingReplaceMechanism.ABSENT && CommonUtils.isNotEmpty(finalName) && finalName.contains(" ")) {
            if (MappingReplaceMechanism.UNDERSCORES == mechanism) {
                finalName = finalName.replaceAll(" ", "_");
            } else if (MappingReplaceMechanism.CAMELCASE == mechanism
                && !(nameCase == MappingNameCase.DEFAULT && dataSource.getSQLDialect().storesUnquotedCase() == DBPIdentifierCase.UPPER)
                && nameCase != MappingNameCase.UPPER // No need to transform upper case names
            ) {
                String camelCaseName = CommonUtils.toCamelCase(finalName);
                if (CommonUtils.isNotEmpty(camelCaseName)) {
                    finalName = camelCaseName.replaceAll(" ", "");
                }
            }
        }
        if (CommonUtils.isNotEmpty(finalName)) {
            // Add quotes for the result name if needed
            return DBUtils.getQuotedIdentifier(dataSource, finalName);
        }
        log.debug("Can't transform target attribute name");
        return targetName;
    }

    private static void getTableFullName(
        @Nullable DBSObjectContainer schema,
        @NotNull DBPDataSource dataSource,
        @NotNull StringBuilder sql,
        @NotNull String tableName
    ) {
        if (schema instanceof DBSSchema || schema instanceof DBSCatalog) {
            sql.append(DBUtils.getFullyQualifiedName(dataSource, schema.getName(), tableName));
        } else {
            sql.append(DBUtils.getQuotedIdentifier(dataSource, tableName));
        }
    }

    @NotNull
    private static SQLObjectEditor<DBSEntity, ?> getTableManager(
        @NotNull DBERegistry editorsRegistry,
        @NotNull Class<? extends DBSObject> tableClass
    ) throws DBException {
        SQLObjectEditor<DBSEntity, ?> tableManager = editorsRegistry.getObjectManager(tableClass, SQLObjectEditor.class);
        if (tableManager == null) {
            throw new DBException("Table manager not found for '" + tableClass.getName() + "'");
        }
        return tableManager;
    }

    @NotNull
    private static Class<? extends DBSObject> getTableClass(@Nullable DBRProgressMonitor monitor, @NotNull DBSObjectContainer schema)
            throws DBException {
        Class<? extends DBSObject> tableClass = schema.getPrimaryChildType(monitor);
        if (!DBSEntity.class.isAssignableFrom(tableClass)) {
            throw new DBException("Wrong table container child type: " + tableClass.getName());
        }
        return tableClass;
    }

    /**
     * This method returns object of the feature new created table and fill the table creating actions list
     *
     * @param monitor progress monitor
     * @param executionContext not null execution context to get datasource etc.
     * @param schema feature table container
     * @param containerMapping mapping container
     * @param actions will be filled by persist actions
     * @param changedProperties list of properties what feature table must have
     * @return DBSEntity table object that can be used as temporary to work with its properties, for example
     * @throws DBException on any DB error
     */
    @NotNull
    public static DBSEntity generateStructTableDDL(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBCExecutionContext executionContext,
        @NotNull DBSObjectContainer schema,
        @NotNull DatabaseMappingContainer containerMapping,
        @NotNull List<DBEPersistAction> actions,
        @Nullable Map<DBPPropertyDescriptor, Object> changedProperties
    ) throws DBException {
        final DBERegistry editorsRegistry = DBWorkbench.getPlatform().getEditorsRegistry();

        try {
            Class<? extends DBSObject> tableClass = getTableClass(monitor, schema);
            SQLObjectEditor<DBSEntity, ?> tableManager = getTableManager(editorsRegistry, tableClass);
            if (!tableManager.canCreateObject(schema)) {
                throw new DBException("Table create is not supported by driver " + schema.getDataSource().getContainer().getDriver().getName());
            }
            Class<? extends DBSEntityAttribute> attrClass;
            SQLObjectEditor<DBSEntityAttribute, ?> attributeManager;
            Class<?>[] childTypes;
            if (executionContext.getDataSource().getInfo().isDynamicMetadata()) {
                attrClass = null;
                attributeManager = null;
            } else {
                if (!(tableManager instanceof DBEStructEditor<?> dbeStructEditor)) {
                    throw new DBException(
                        "Table create not supported by " + executionContext.getDataSource().getContainer().getDriver().getName());
                }
                childTypes = dbeStructEditor.getChildTypes();
                attrClass = BeanUtils.findAssignableType(childTypes, DBSEntityAttribute.class);
                if (attrClass == null) {
                    throw new DBException("Column manager not found for '" + tableClass.getName() + "'");
                }
                attributeManager = editorsRegistry.getObjectManager(attrClass, SQLObjectEditor.class);
            }

            Map<String, Object> options = new HashMap<>();
            options.put(SQLObjectEditor.OPTION_SKIP_CONFIGURATION, true);
            options.put(DBPScriptObject.OPTION_INCLUDE_COMMENTS, true);

            DBECommandContext commandContext = new TargetCommandContext(executionContext);

            String tableFinalName;

            DBSEntity table;
            DBECommand createCommand = null;
            if (containerMapping.getMappingType() == DatabaseMappingType.create || (
                containerMapping.getMappingType() == DatabaseMappingType.recreate && containerMapping.getTarget() == null)) {
                table = tableManager.createNewObject(monitor, commandContext, schema, null, options);
                applyPropertyChanges(monitor, changedProperties, commandContext, containerMapping, table);
                transferComment(monitor, commandContext, table, getSourceDescription(containerMapping.getSource()));
                tableFinalName = getTableFinalName(containerMapping.getTargetName(), tableClass, table, true);
                createCommand = tableManager.makeCreateCommand(table, options);
            } else {
                table = (DBSEntity) containerMapping.getTarget();
                if (table == null) {
                    throw new DBException("Internal error - target table not set");
                }
                if (containerMapping.getMappingType() == DatabaseMappingType.recreate) {
                    tableManager.deleteObject(commandContext, table, options);
                    table = tableManager.createNewObject(
                        monitor,
                        commandContext,
                        table.getParentObject(),
                        null,
                        options);
                    applyPropertyChanges(monitor, changedProperties, commandContext, containerMapping, table);
                    transferComment(monitor, commandContext, table, getSourceDescription(containerMapping.getSource()));
                    tableFinalName = getTableFinalName(containerMapping.getTargetName(), tableClass, table, false);
                    createCommand = tableManager.makeCreateCommand(table, options);
                } else {
                    tableFinalName = table.getName();
                }
            }

            if (attributeManager != null) {
                for (DatabaseMappingAttribute attributeMapping : containerMapping.getAttributeMappings(monitor)) {
                    if (attributeMapping.getMappingType() != DatabaseMappingType.create) {
                        continue;
                    }
                    DBSEntityAttribute newAttribute = attributeManager.createNewObject(monitor, commandContext, table, null, options);
                    if (!(newAttribute instanceof DBPNamedObject2 namedObject2)) {
                        throw new DBException("Table column name cannot be set for " + attrClass.getName());
                    }
                    namedObject2.setName(getTransformedName(newAttribute.getDataSource(), attributeMapping.getTargetName(), false));

                    // Set attribute properties
                    if (newAttribute instanceof DBSTypedObjectExt2 typedAttr) {
                        boolean typeModifiersSet = false;
                        if (typedAttr instanceof DBSTypedObjectExt3 typedObjectExt3) {
                            String fullTargetTypeName = attributeMapping.getTargetType(executionContext.getDataSource(), true);
                            typeModifiersSet = fullTargetTypeName.contains("(");
                            typedObjectExt3.setFullTypeName(fullTargetTypeName);
                        } else {
                            String targetAttrType = attributeMapping.getTargetType(executionContext.getDataSource(), false);
                            typedAttr.setTypeName(targetAttrType);
                        }

                        if (!typeModifiersSet) {
                            DBSAttributeBase sourceAttr = attributeMapping.getSource();
                            if (sourceAttr != null) {
                                typedAttr.setMaxLength(sourceAttr.getMaxLength());
                                typedAttr.setPrecision(sourceAttr.getPrecision());
                                typedAttr.setScale(sourceAttr.getScale());
                                typedAttr.setRequired(sourceAttr.isRequired());
                            }
                        }
                    }

                    if (newAttribute instanceof DBSAttributeCollation collationAttr) {
                        collationAttr.setCollationName(attributeMapping.getTargetCollation(monitor));
                    }

                    transferComment(monitor, commandContext, newAttribute, getSourceDescription(attributeMapping.getSource()));
                    var attrCache = attributeManager.getObjectsCache(newAttribute);
                    if (attrCache != null) {
                        attrCache.cacheObject(newAttribute);
                    }

                    SQLObjectEditor.ObjectCreateCommand attrCreateCommand = attributeManager.makeCreateCommand(newAttribute, options);
                    if (createCommand instanceof DBECommandAggregator<?> aggregator) {
                        aggregator.aggregateCommand(attrCreateCommand);
                    }
                }
            }

            containerMapping.setTargetName(tableFinalName);

            actions.addAll(
                DBExecUtils.getActionsListFromCommandContext(
                    monitor,
                    commandContext,
                    executionContext,
                    options,
                    null));
            return table;
        } catch (DBException e) {
            throw new DBException("Can't create or modify target table", e);
        }
    }

    @Nullable
    private static String getSourceDescription(@Nullable Object source) {
        return source instanceof DBPObjectWithDescription described ? described.getDescription() : null;
    }

    private static void transferComment(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBECommandContext commandContext,
        @NotNull DBSObject target,
        @Nullable String description
    ) {
        if (CommonUtils.isEmpty(description) || !(target instanceof DBSDescriptionEditable descEditable)) {
            return;
        }
        PropertySourceEditable propertySource = new PropertySourceEditable(commandContext, target, target);
        propertySource.collectProperties();
        DBPPropertyDescriptor descProperty = propertySource.getProperty(DBConstants.PROP_ID_DESCRIPTION);
        if (descProperty instanceof ObjectPropertyDescriptor objectProperty) {
            if (objectProperty.isEditPossible(target)) {
                propertySource.setPropertyValue(monitor, target, objectProperty, description);
            }
        } else {
            descEditable.setDescription(description);
        }
    }

    public static void applyPropertyChanges(
        @Nullable DBRProgressMonitor monitor,
        @Nullable Map<DBPPropertyDescriptor, Object> changedProperties,
        @Nullable DBECommandContext commandContext,
        @Nullable DatabaseMappingContainer containerMapping,
        @NotNull DBSEntity table
    ) {
        PropertySourceEditable propertySource = new PropertySourceEditable(commandContext, table, table);
        if (CommonUtils.isEmpty(changedProperties) && containerMapping != null
            && !CommonUtils.isEmpty(containerMapping.getRawChangedPropertiesMap())) {
            // Probably it is the task with saved properties map
            // But this map has only the id of ObjectPropertyDescriptor
            // So we should find the correct properties and bound them
            propertySource.collectProperties();
            Map<String, Object> rawChangedPropertiesMap = containerMapping.getRawChangedPropertiesMap();
            for (Map.Entry<String, Object> entry : rawChangedPropertiesMap.entrySet()) {
                DBPPropertyDescriptor property = propertySource.getProperty(entry.getKey());
                if (property != null) {
                    propertySource.addChangedProperties(property, entry.getValue());
                }
            }
            changedProperties = propertySource.getChangedPropertiesValues();
        }
        if (!CommonUtils.isEmpty(changedProperties)) {
            for (Map.Entry<DBPPropertyDescriptor, Object> entry : changedProperties.entrySet()) {
                propertySource.setPropertyValue(monitor, table, (ObjectPropertyDescriptor) entry.getKey(), entry.getValue());
            }
        }
    }

    @NotNull
    private static String getTableFinalName(
        @NotNull String targetName,
        @NotNull Class<? extends DBSObject> tableClass,
        @Nullable DBSEntity table,
        boolean extraTransform
    ) throws DBException {
        if (table == null) {
            throw new DBException("Internal error - target table not set");
        }
        if (table.getDataSource() == null) {
            return targetName;
        }
        String tableFinalName;
        if (extraTransform) {
            tableFinalName = getTransformedName(table.getDataSource(), targetName, false);
        } else {
            tableFinalName = DBObjectNameCaseTransformer.transformName(table.getDataSource(), targetName);
        }
        if (table instanceof DBPNamedObject2 namedObject2 && tableFinalName != null) {
            namedObject2.setName(tableFinalName);
        } else {
            throw new DBException("Table name cannot be set for " + tableClass.getName());
        }
        return tableFinalName;
    }

    @NotNull
    static DBEPersistAction generateTargetAttributeDDL(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBPDataSource dataSource,
        @NotNull DatabaseMappingAttribute attribute
    ) {
        StringBuilder sql = new StringBuilder(500);
        sql.append("ALTER TABLE ").append(DBUtils.getObjectFullName(attribute.getParent().getTarget(), DBPEvaluationContext.DDL))
            .append(" ADD ");
        appendAttributeClause(monitor, dataSource, sql, attribute);
        return new SQLDatabasePersistAction(sql.toString());
    }

    private static void appendAttributeClause(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBPDataSource dataSource,
        @NotNull StringBuilder sql,
        @NotNull DatabaseMappingAttribute attr
    ) {
        String attrName = getTransformedName(dataSource, attr.getTargetName(), false);
        sql.append(DBUtils.getQuotedIdentifier(dataSource, attrName)).append(" ").append(attr.getTargetType(dataSource, true));
        String collation = attr.getTargetCollation(monitor);
        if (!CommonUtils.isEmpty(collation)) {
            sql.append(" COLLATE ").append(collation);
        }
        if (SQLUtils.getDialectFromDataSource(dataSource).supportsNullability()) {
            if (attr.getSource() != null && attr.getSource().isRequired()) {
                sql.append(" NOT NULL");
            }
        }
    }

    public static void executeDDL(@NotNull DBCSession session, @NotNull DBEPersistAction[] actions) throws DBException {
        if (actions.length == 0) {
            return;
        }
        ensureHasEditMetadataPermission(session.getDataSource().getContainer());
        // Process actions
        DBExecUtils.executePersistActions(session, actions);
        // Commit DDL changes
        DBCTransactionManager txnManager = DBUtils.getTransactionManager(session.getExecutionContext());
        if (txnManager != null && txnManager.isSupportsTransactions() && !txnManager.isAutoCommit()) {
            txnManager.commit(session);
        }
    }

    @Nullable
    static DBSDataManipulator createTargetDynamicTable(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBCExecutionContext executionContext,
        @NotNull DBSObjectContainer schema,
        @NotNull DatabaseMappingContainer containerMapping,
        boolean recreate
    ) throws DBException {
        ensureHasEditMetadataPermission(executionContext.getDataSource().getContainer());
        final DBERegistry editorsRegistry = DBWorkbench.getPlatform().getEditorsRegistry();

        Class<? extends DBSObject> tableClass = getTableClass(monitor, schema);
        SQLObjectEditor tableManager = getTableManager(editorsRegistry, tableClass);
        DBECommandContext commandContext = new TargetCommandContext(executionContext);
        Map<String, Object> options = new HashMap<>();
        options.put(SQLObjectEditor.OPTION_SKIP_CONFIGURATION, true);
        if (recreate && containerMapping.getTarget() != null) {
            tableManager.deleteObject(commandContext, containerMapping.getTarget(), options);
            commandContext.saveChanges(monitor, options);
        }
        DBSObject targetEntity = tableManager.createNewObject(monitor, commandContext, schema, null, options);
        if (targetEntity == null) {
            throw new DBException("Null target entity returned");
        }
        if (targetEntity instanceof DBPNamedObject2) {
            ((DBPNamedObject2) targetEntity).setName(containerMapping.getTargetName());
        } else {
            throw new DBException("Can not set name for target entity '" + targetEntity.getClass().getName() + "'");
        }
        commandContext.saveChanges(monitor, options);
        if (targetEntity instanceof DBSDataManipulator dataManipulator) {
            if (targetEntity instanceof DBSDocumentContainer && tableManager.getObjectsCache(targetEntity) == null) {
                return dataManipulator;
            }
            return null;
        }
        throw new DBException("Target entity doesn't support data manipulation: '" + targetEntity.getClass().getName() + "'");
    }

    @NotNull
    public static Pair<DBPDataKind, String> getDataType(@Nullable String value) {
        if (CommonUtils.isEmpty(value)) {
            return DATA_TYPE_UNKNOWN;
        }

        char firstChar = value.charAt(0);
        if (isNumericStart(firstChar)) {
            Pair<DBPDataKind, String> numeric = tryClassifyNumber(value);
            if (numeric != null) {
                return numeric;
            }
        }

        if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
            return DATA_TYPE_BOOLEAN;
        }
        if (!SQLUtils.isLatinLetter(firstChar)) {
            return DATA_TYPE_NATIONAL_STRING;
        }
        return DATA_TYPE_STRING;
    }

    private static boolean isNumericStart(char c) {
        return Character.isDigit(c) || c == '+' || c == '-' || c == '.';
    }

    @Nullable
    private static Pair<DBPDataKind, String> tryClassifyNumber(@NotNull String value) {
        try {
            Integer.parseInt(value);
            return DATA_TYPE_INTEGER;
        } catch (NumberFormatException ignore) {
        }
        try {
            Long.parseLong(value);
            return DATA_TYPE_BIGINT;
        } catch (NumberFormatException ignore) {
        }
        try {
            Double.parseDouble(value);
            return DATA_TYPE_REAL;
        } catch (NumberFormatException ignore) {
            return null;
        }
    }

    private static void ensureHasEditMetadataPermission(@NotNull DBPDataSourceContainer container) throws DBCException {
        if (!container.hasModifyPermission(DBPDataSourcePermission.PERMISSION_EDIT_METADATA)) {
            throw new DBCException("New table creation in database [" + container.getName() + "] restricted by connection configuration");
        }
    }

    public static class TargetCommandContext extends AbstractCommandContext implements DBETransientObjectContext {
        public TargetCommandContext(DBCExecutionContext executionContext) {
            super(executionContext, true);
        }
    }
}
