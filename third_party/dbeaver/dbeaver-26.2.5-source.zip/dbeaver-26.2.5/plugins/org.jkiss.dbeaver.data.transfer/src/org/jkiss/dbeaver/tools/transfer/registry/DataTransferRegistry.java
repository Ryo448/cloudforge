/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jkiss.dbeaver.tools.transfer.registry;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.impl.AbstractDescriptor;
import org.jkiss.dbeaver.model.struct.DBSObject;
import org.jkiss.dbeaver.tools.transfer.IDataTransferNode;
import org.jkiss.utils.CommonUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * DataTransferRegistry
 */
public class DataTransferRegistry {

    public static final String EXTENSION_ID = "org.jkiss.dbeaver.dataTransfer"; //$NON-NLS-1$

    private static DataTransferRegistry instance = null;

    private static final Log log = Log.getLog(DataTransferRegistry.class);

    private final List<DataTransferNodeDescriptor> nodes = new ArrayList<>();
    private final Map<String, DataTransferAttributeTransformerDescriptor> transformers = new LinkedHashMap<>();
    private final Map<String, DataTransferEventProcessorDescriptor> eventProcessors = new LinkedHashMap<>();

    private DataTransferRegistry(@NotNull IExtensionRegistry registry) {
        // Load datasource providers from external plugins
        IConfigurationElement[] extElements = registry.getConfigurationElementsFor(EXTENSION_ID);
        for (IConfigurationElement ext : extElements) {
            // Load main nodes
            if ("node".equals(ext.getName())) {
                if (!CommonUtils.isEmpty(ext.getAttribute("ref"))) {
                    continue;
                }
                DataTransferNodeDescriptor node = new DataTransferNodeDescriptor(ext);
                nodes.add(node);
            } else if ("transformer".equals(ext.getName())) {
                // Load transformers
                DataTransferAttributeTransformerDescriptor at = new DataTransferAttributeTransformerDescriptor(ext);
                transformers.put(at.getId(), at);
            } else if ("eventProcessor".equals(ext.getName())) {
                final DataTransferEventProcessorDescriptor descriptor = new DataTransferEventProcessorDescriptor(ext);
                eventProcessors.put(descriptor.getId(), descriptor);
            }

        }

        // Load references
        for (IConfigurationElement ext : extElements) {
            if ("node".equals(ext.getName())) {
                String nodeReference = ext.getAttribute("ref");
                if (CommonUtils.isEmpty(nodeReference)) {
                    continue;
                }
                DataTransferNodeDescriptor refNode = getNodeById(nodeReference);
                if (refNode == null) {
                    log.error("Referenced data transfer node '" + nodeReference + "' not found");
                } else {
                    refNode.loadNodeConfigurations(ext);
                    String settingsOverride = ext.getAttribute("settings");
                    if (!CommonUtils.isEmpty(settingsOverride)) {
                        refNode.overrideSettingsType(new NodeSettingsContributor(ext).settingsType);
                        log.debug("Settings of data transfer node '" + nodeReference + "' overridden with '" + settingsOverride + "'");
                    }
                }
            }
        }
        nodes.sort(Comparator.comparing(DataTransferNodeDescriptor::getName));

        //transformers.sort(Comparator.comparing(DataTransferAttributeTransformerDescriptor::getName));
    }

    @NotNull
    public synchronized static DataTransferRegistry getInstance() {
        if (instance == null) {
            instance = new DataTransferRegistry(Platform.getExtensionRegistry());
        }
        return instance;
    }

    @NotNull
    public List<DataTransferNodeDescriptor> getAvailableProducers(@NotNull Collection<DBSObject> sourceObjects) {
        return getAvailableNodes(DataTransferNodeDescriptor.NodeType.PRODUCER, sourceObjects);
    }

    @NotNull
    public List<DataTransferNodeDescriptor> getAvailableConsumers(@NotNull Collection<DBSObject> sourceObjects) {
        return getAvailableNodes(DataTransferNodeDescriptor.NodeType.CONSUMER, sourceObjects);
    }

    @NotNull
    List<DataTransferNodeDescriptor> getAvailableNodes(
        @NotNull DataTransferNodeDescriptor.NodeType nodeType,
        @NotNull Collection<DBSObject> sourceObjects
    ) {
        List<DataTransferNodeDescriptor> result = new ArrayList<>();
        for (DataTransferNodeDescriptor node : nodes) {
            if (node.getNodeType() == nodeType) {
                for (DBSObject sourceObject : sourceObjects) {
                    if (node.appliesToType(sourceObject.getClass())) {
                        result.add(node);
                        break;
                    }
                }
            }
        }
        return result;
    }

    @NotNull
    public List<DataTransferNodeDescriptor> getNodes(@NotNull DataTransferNodeDescriptor.NodeType nodeType) {
        List<DataTransferNodeDescriptor> result = new ArrayList<>();
        for (DataTransferNodeDescriptor node : nodes) {
            if (node.getNodeType() == nodeType) {
                result.add(node);
            }
        }
        return result;
    }

    @Nullable
    public DataTransferNodeDescriptor getNodeByType(@NotNull Class<? extends IDataTransferNode> type) {
        for (DataTransferNodeDescriptor node : nodes) {
            if (type.equals(node.getNodeClass())) {
                return node;
            }
        }
        return null;
    }

    @Nullable
    public DataTransferNodeDescriptor getNodeById(@NotNull String id) {
        for (DataTransferNodeDescriptor node : nodes) {
            if (node.getId().equals(id)) {
                return node;
            }
        }
        return null;
    }

    @Nullable
    public DataTransferProcessorDescriptor getProcessor(@NotNull String processorFullId) {
        String[] idParts = processorFullId.split(":");
        if (idParts.length == 2) {
            DataTransferNodeDescriptor node = getNodeById(idParts[0]);
            if (node != null) {
                return node.getProcessor(idParts[1]);
            }
        }
        return null;
    }

    @NotNull
    public List<DataTransferProcessorDescriptor> getAvailableProcessors(
        @NotNull Class<? extends IDataTransferNode<?>> nodeType,
        @NotNull Class<?> objectType) {
        for (DataTransferNodeDescriptor node : nodes) {
            if (node.getNodeClass() == nodeType) {
                if (node.appliesToType(objectType)) {
                    return node.getAvailableProcessors(objectType);
                }
            }
        }
        return List.of();
    }

    @NotNull
    public List<DataTransferAttributeTransformerDescriptor> getAttributeTransformers() {
        return new ArrayList<>(transformers.values());
    }

    @Nullable
    public DataTransferAttributeTransformerDescriptor getAttributeTransformer(String id) {
        return transformers.get(id);
    }

    @Nullable
    public DataTransferAttributeTransformerDescriptor getAttributeTransformerByName(@NotNull String tName) {
        return transformers.values().stream().filter(t -> t.getName().equals(tName)).findFirst().orElse(null);
    }

    @NotNull
    public Collection<DataTransferEventProcessorDescriptor> getEventProcessors(@NotNull String nodeId) {
        return eventProcessors.values().stream()
            .filter(x -> x.isApplicable(nodeId))
            .sorted(Comparator.comparingInt(DataTransferEventProcessorDescriptor::getOrder))
            .collect(Collectors.toList());
    }

    @Nullable
    public DataTransferEventProcessorDescriptor getEventProcessorById(@NotNull String id) {
        return eventProcessors.get(id);
    }

    private static final class NodeSettingsContributor extends AbstractDescriptor {
        private final ObjectType settingsType;

        private NodeSettingsContributor(@NotNull IConfigurationElement config) {
            super(config);
            this.settingsType = new ObjectType(config, "settings");
        }
    }
}
