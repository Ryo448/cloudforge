/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jkiss.dbeaver.tools.transfer;

import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.model.exec.DBCStatistics;
import org.jkiss.dbeaver.model.runtime.DBRProgressMonitor;
import org.jkiss.dbeaver.model.task.DBTTask;

/**
 * Data transfer
 */
public interface IDataTransferProducer<SETTINGS extends IDataTransferSettings> extends IDataTransferNode<SETTINGS>, AutoCloseable {

    /**
     * Transfer data to consumer
     *
     * @param monitor   progress monitor
     * @param consumer  transfer consumer
     * @param processor transfer processor (optional)
     * @param settings  settings
     * @param task      task (optional)
     * @param maxRows   maximum rows to transfer. <= 0 means no limits.
     */
    void transferData(
        @NotNull DBRProgressMonitor monitor,
        @NotNull IDataTransferConsumer consumer,
        @Nullable IDataTransferProcessor processor,
        @NotNull SETTINGS settings,
        @Nullable DBTTask task,
        long maxRows
    ) throws DBException;

    @NotNull
    default DBCStatistics getStatistics() {
        return new DBCStatistics();
    }

    @Override
    default void close() throws DBException {
    }
}
