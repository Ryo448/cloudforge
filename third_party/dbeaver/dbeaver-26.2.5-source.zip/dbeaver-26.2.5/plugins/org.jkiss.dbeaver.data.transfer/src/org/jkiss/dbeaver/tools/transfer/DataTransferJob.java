/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.dbeaver.tools.transfer;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.osgi.util.NLS;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.exec.DBCStatistics;
import org.jkiss.dbeaver.model.runtime.AbstractJob;
import org.jkiss.dbeaver.model.runtime.DBRProgressMonitor;
import org.jkiss.dbeaver.model.runtime.ProxyProgressMonitor;
import org.jkiss.dbeaver.model.task.DBTTask;
import org.jkiss.dbeaver.runtime.DBInterruptedException;
import org.jkiss.dbeaver.tools.transfer.internal.DTMessages;
import org.jkiss.utils.CommonUtils;

import java.io.IOException;
import java.io.PrintStream;

/**
 * Data transfer job
 */
public class DataTransferJob extends AbstractJob {

    private final DBCStatistics totalStatistics = new DBCStatistics();
    private final DataTransferSettings settings;
    private final DBTTask task;
    private final DBRProgressMonitor parentMonitor;
    private long elapsedTime;
    private volatile boolean transferCanceled;

    private final Log log;
    private final PrintStream logStream;

    public DataTransferJob(
        @NotNull DataTransferSettings settings,
        @NotNull DBTTask task,
        @NotNull Log log,
        @Nullable PrintStream logStream,
        @Nullable DBRProgressMonitor parentMonitor,
        int index
    ) {
        super("Data transfer job [" + index + "]: " + settings.getConsumer().getName());
        this.settings = settings;
        this.task = task;
        this.log = log;
        this.logStream = logStream;
        this.parentMonitor = parentMonitor;
    }

    public DataTransferSettings getSettings() {
        return settings;
    }

    public long getElapsedTime() {
        return elapsedTime;
    }

    public DBCStatistics getTotalStatistics() {
        return totalStatistics;
    }

    @NotNull
    @Override
    protected IStatus run(@NotNull DBRProgressMonitor jobMonitor) {
        final int pipeCount = settings.getDataPipes().size();
        final DBRProgressMonitor baseMonitor = parentMonitor != null ? parentMonitor : jobMonitor;
        final DBRProgressMonitor monitor = new ProxyProgressMonitor(baseMonitor) {
            @Override
            public boolean isCanceled() {
                return transferCanceled || super.isCanceled();
            }
        };
        monitor.beginTask("Perform data transfer", pipeCount);
        long startTime = System.currentTimeMillis();
        for (; ;) {
            if (monitor.isCanceled()) {
                break;
            }
            DataTransferPipe transferPipe = settings.acquireDataPipe(monitor, task);
            if (transferPipe == null) {
                break;
            }
            PrintStream oldLogWriter = Log.getLogWriter();
            try {
                if (logStream != null) {
                    Log.setLogWriter(logStream);
                }
                transferData(monitor, transferPipe);

                if (parentMonitor != null) {
                    parentMonitor.worked(1);
                }
                jobMonitor.worked(1);
            } catch (DBInterruptedException e) {
                return Status.CANCEL_STATUS;
            } catch (Exception e) {
                if (monitor.isCanceled()) {
                    return Status.CANCEL_STATUS;
                }
                // Report as an OK status to avoid showing the error in the UI (it's handled by the caller)
                return new Status(IStatus.OK, getClass(), "Data transfer failed", e);
            } finally {
                Log.setLogWriter(oldLogWriter);
                monitor.done();
                elapsedTime = System.currentTimeMillis() - startTime;
            }
        }
        return monitor.isCanceled() ? Status.CANCEL_STATUS : Status.OK_STATUS;
    }

    @Override
    protected void canceling() {
        transferCanceled = true;
        super.canceling();
    }

    @Nullable
    @Override
    protected DBRProgressMonitor getCancellationMonitor() {
        // A single transfer uses the parent monitor for its JDBC sessions and active blocks.
        return parentMonitor != null ? parentMonitor : super.getCancellationMonitor();
    }

    void transferData(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DataTransferPipe transferPipe
    ) throws DBException, IOException {
        IDataTransferProducer producer = transferPipe.getProducer();
        if (producer == null) {
            throw new DBException("Null producer");
        }
        String inputName = "unknown";
        try {
            IDataTransferConsumer<?, ?> consumer = transferPipe.getConsumer();
            if (consumer == null) {
                throw new DBException("Null consumer");
            }

            inputName = producer.getObjectName();
            String outputName = consumer.getObjectName();
            try {
                //consumer.initTransfer(producer.getDatabaseObject(), consumerSettings, );

                inputName = producer.getObjectFullName(monitor);
                outputName = consumer.getObjectFullName(monitor);
                monitor.beginTask(
                    NLS.bind(DTMessages.data_transfer_wizard_job_container_name,
                        CommonUtils.truncateString(inputName, 200),
                        CommonUtils.truncateString(outputName, 200)), 1);

                IDataTransferSettings nodeSettings = settings.getNodeSettings(producer);

                IDataTransferProcessor processor = settings.getProcessor() == null ? null : settings.getProcessor().getInstance();
                producer.transferData(monitor, consumer, processor, nodeSettings, task, -1);

                if (isTransferCanceled(monitor)) {
                    throw new DBInterruptedException("Data transfer was canceled");
                }

                totalStatistics.accumulate(producer.getStatistics());
                totalStatistics.accumulate(consumer.getStatistics());

                consumer.finishTransfer(monitor, false);
            } catch (Exception e) {
                consumer.finishTransfer(monitor, e, task, false);
                log.error("Error transferring data from " + inputName + " to " + outputName, e);
                throw e;
            } finally {
                monitor.done();
            }
        } finally {
            try {
                producer.close();
            } catch (Exception e) {
                log.error("Error closing data producer " + inputName, e);
            }
        }
    }

    private boolean isTransferCanceled(@NotNull DBRProgressMonitor monitor) {
        return monitor.isCanceled() || isCanceled() || (parentMonitor != null && parentMonitor.isCanceled());
    }

}
