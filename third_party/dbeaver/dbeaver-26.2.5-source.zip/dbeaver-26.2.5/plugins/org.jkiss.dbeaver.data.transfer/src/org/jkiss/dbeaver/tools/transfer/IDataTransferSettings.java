/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.dbeaver.tools.transfer;

import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.model.runtime.DBRRunnableContext;

import java.util.Map;

/**
 * Transfer settings
 */
public interface IDataTransferSettings {

    void loadSettings(
        @NotNull DBRRunnableContext runnableContext,
        @NotNull DataTransferSettings dataTransferSettings,
        @NotNull Map<String, Object> settings
    );

    void saveSettings(@NotNull Map<String, Object> settings);

    @NotNull
    String getSettingsSummary();

    /**
     * Returns non-persistent parameters for data transfer execution which is shared between consumers of the task
     */
    @Nullable
    default Object prepareRuntimeParameters() {
        return null;
    }
}
