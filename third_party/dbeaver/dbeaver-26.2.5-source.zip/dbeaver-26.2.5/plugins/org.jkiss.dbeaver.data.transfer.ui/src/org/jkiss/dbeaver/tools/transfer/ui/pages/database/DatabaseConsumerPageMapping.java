/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.dbeaver.tools.transfer.ui.pages.database;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.viewers.*;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.custom.ControlEditor;
import org.eclipse.swt.events.*;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.TextStyle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.*;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.*;
import org.jkiss.dbeaver.model.app.DBPProject;
import org.jkiss.dbeaver.model.impl.DBObjectNameCaseTransformer;
import org.jkiss.dbeaver.model.impl.struct.RelationalObjectType;
import org.jkiss.dbeaver.model.navigator.DBNDatabaseNode;
import org.jkiss.dbeaver.model.navigator.DBNModel;
import org.jkiss.dbeaver.model.navigator.DBNNode;
import org.jkiss.dbeaver.model.navigator.DBNUtils;
import org.jkiss.dbeaver.model.preferences.DBPPreferenceStore;
import org.jkiss.dbeaver.model.runtime.DBRProgressMonitor;
import org.jkiss.dbeaver.model.runtime.LoggingProgressMonitor;
import org.jkiss.dbeaver.model.struct.*;
import org.jkiss.dbeaver.model.struct.rdb.DBSSchema;
import org.jkiss.dbeaver.runtime.DBWorkbench;
import org.jkiss.dbeaver.tools.transfer.DTConstants;
import org.jkiss.dbeaver.tools.transfer.DataTransferPipe;
import org.jkiss.dbeaver.tools.transfer.DataTransferSettings;
import org.jkiss.dbeaver.tools.transfer.IDataTransferConsumer;
import org.jkiss.dbeaver.tools.transfer.database.*;
import org.jkiss.dbeaver.tools.transfer.internal.DTActivator;
import org.jkiss.dbeaver.tools.transfer.internal.DTMessages;
import org.jkiss.dbeaver.tools.transfer.registry.DataTransferAttributeTransformerDescriptor;
import org.jkiss.dbeaver.tools.transfer.registry.DataTransferRegistry;
import org.jkiss.dbeaver.tools.transfer.ui.handlers.DataImportPropertyTester;
import org.jkiss.dbeaver.tools.transfer.ui.internal.DTUIMessages;
import org.jkiss.dbeaver.tools.transfer.ui.pages.DataTransferPageNodeSettings;
import org.jkiss.dbeaver.ui.*;
import org.jkiss.dbeaver.ui.controls.CustomComboBoxCellEditor;
import org.jkiss.dbeaver.ui.controls.ObjectContainerSelectorPanel;
import org.jkiss.dbeaver.ui.controls.TreeContentProvider;
import org.jkiss.dbeaver.ui.navigator.dialogs.ObjectBrowserDialog;
import org.jkiss.utils.ArrayUtils;
import org.jkiss.utils.CommonUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class DatabaseConsumerPageMapping extends DataTransferPageNodeSettings {
    private static final Log log = Log.getLog(DatabaseConsumerPageMapping.class);

    private static final String TARGET_NAME_BROWSE = "[browse]";
    private static final int MAPPING_COLUMN_WIDTH = 20;
    private static final int CHECKBOX_COLUMN_WIDTH = 16;
    private static final StyledString.Styler STRIKEOUT_STYLER = new StyledString.Styler() {
        @Override
        public void applyStyles(TextStyle style) {
            style.strikeout = true;
        }
    };
    private final List<DatabaseMappingContainer> model = new ArrayList<>();
    protected CheckboxTreeViewer mappingViewer;
    protected Composite buttonsPanel;
    private Button configureButton;
    protected Button previewButton;
    private Button loadMappingsButton;
    private Button chooseContainerButton;
    private ControlEditor chooseContainerEditor;
    private Button upButton;
    private Button downButton;
    private Composite bottomBar;
    private Button recreateCheck;
    private Button transformCheck;
    private Combo transformCombo;
    protected Button mappingRules;
    private ObjectContainerSelectorPanel containerPanel;
    private boolean transformComboKeyboardSelection;
    private boolean firstInit = true;
    private String mappingErrorMessage;

    private static abstract class MappingLabelProvider extends CellLabelProvider {
        @Override
        public void update(ViewerCell cell)
        {
        }
    }

    private class SourceStyledLabelProvider extends ColumnLabelProvider
        implements DelegatingStyledCellLabelProvider.IStyledLabelProvider, IToolTipProvider {
        @Nullable
        @Override
        public String getToolTipText(Object element) {
            return getMappingTooltip((DatabaseMappingObject) element);
        }

        @Override
        public StyledString getStyledText(Object element) {
            DatabaseMappingObject mapping = (DatabaseMappingObject) element;
            StyledString text = new StyledString(getSourceLabel(mapping));
            if (mapping.getMappingType() == DatabaseMappingType.skip) {
                text.setStyle(0, text.length(), STRIKEOUT_STYLER);
            }
            return text;
        }

        @Nullable
        @Override
        public Image getImage(Object element) {
            DatabaseMappingObject mapping = (DatabaseMappingObject) element;
            DBPImage icon = mapping.getIcon();
            if (icon == null) {
                return null;
            }
            if (getMappingTooltip(mapping) != null) {
                icon = new DBIconComposite(icon, false, null, DBIcon.OVER_ERROR, null, null);
            }
            return DBeaverIcons.getImage(icon);
        }
    }

    private class TargetStyledLabelProvider extends ColumnLabelProvider
        implements DelegatingStyledCellLabelProvider.IStyledLabelProvider {
        @Override
        public StyledString getStyledText(Object element) {
            DatabaseMappingObject mapping = (DatabaseMappingObject) element;
            String targetName = mapping.getTargetName();
            if (CommonUtils.isEmpty(targetName) && isConfigurationRow(element)) {
                return new StyledString(DTUIMessages.database_consumer_page_mapping_target_unspecified);
            }
            StyledString text = new StyledString(CommonUtils.notEmpty(targetName));
            if (mapping.getMappingType() == DatabaseMappingType.skip) {
                text.setStyle(0, text.length(), STRIKEOUT_STYLER);
            }
            String transformerLabel = getTransformerLabel(mapping);
            if (transformerLabel != null) {
                text.append(" → " + transformerLabel, StyledString.QUALIFIER_STYLER);
            }
            return text;
        }

        @Nullable
        @Override
        public Color getBackground(Object element) {
            if (isConfigurationRow(element)) {
                return null;
            }
            if (((DatabaseMappingObject) element).getMappingType() == DatabaseMappingType.unspecified) {
                return UIUtils.getSharedTextColors().getColor(SharedTextColors.COLOR_WARNING);
            }
            return null;
        }

        @Nullable
        @Override
        public Image getImage(Object element) {
            return null;
        }
    }

    @Nullable
    private static String getTransformerLabel(@NotNull DatabaseMappingObject mapping) {
        if (!(mapping instanceof DatabaseMappingAttribute attribute) || !attribute.getMappingType().isValid()) {
            return null;
        }
        DataTransferAttributeTransformerDescriptor transformer = attribute.getTransformer();
        if (transformer == null) {
            return null;
        }
        Map<String, Object> properties = attribute.getTransformerProperties();
        String values = transformer.getProperties().stream()
            .map(property -> CommonUtils.toString(properties.get(property.getId())))
            .filter(CommonUtils::isNotEmpty)
            .collect(Collectors.joining(", "));
        return values.isEmpty() ? transformer.getName() : transformer.getName() + ": " + values;
    }

    public DatabaseConsumerPageMapping() {
        super(DTUIMessages.database_consumer_page_mapping_name_and_title);
        setTitle(DTUIMessages.database_consumer_page_mapping_name_and_title);
        setDescription(DTUIMessages.database_consumer_page_mapping_description);
        setPageComplete(false);
    }

    protected DatabaseConsumerSettings getDatabaseConsumerSettings() {
        return getWizard().getPageSettings(this, DatabaseConsumerSettings.class);
    }

    @Override
    public void createControl(Composite parent) {
        initializeDialogUnits(parent);

        final DatabaseConsumerSettings settings = getDatabaseConsumerSettings();

        Composite composite = UIUtils.createComposite(parent, 1);

        {
            // Target container
            // Use first source object as cur selection (it's better than nothing)
            containerPanel = new ObjectContainerSelectorPanel(composite,
                getWizard().getProject(),
                "container.data-transfer.database-consumer",
                DTMessages.data_transfer_db_consumer_target_container,
                DTMessages.data_transfer_db_consumer_choose_container) {
                @Nullable
                @Override
                protected DBNNode selectContainer(@NotNull DBNNode rootNode, @Nullable DBNNode selectedNode) {
                    return ObjectBrowserDialog.selectObject(
                        getShell(),
                        DTMessages.data_transfer_db_consumer_choose_container,
                        rootNode,
                        selectedNode,
                        new Class[] {DBSInstance.class, DBSObjectContainer.class},
                        new Class[] {DBSObjectContainer.class},
                        new Class[] {DBSSchema.class},
                        null,
                        this::isContainerSelectable
                    );
                }

                @Override
                protected boolean isContainerSelectable(@NotNull DBNNode node) {
                    return !(node instanceof DBNDatabaseNode databaseNode)
                        || DataImportPropertyTester.supportsImport(databaseNode.getDataSource());
                }

                @Nullable
                @Override
                protected DBNNode getSelectedNode() {
                    DBSObjectContainer container = settings.getContainer();
                    DBNModel navigatorModel = DBWorkbench.getPlatform().getNavigatorModel();
                    DBNNode selectedNode = navigatorModel.getNodeByObject(container);
                    if (selectedNode == null && !settings.getDataMappings().isEmpty()) {
                        // Use first source object as cur selection (it's better than nothing)
                        DBSDataContainer firstSource = settings.getDataMappings().keySet().iterator().next();
                        selectedNode = navigatorModel.getNodeByObject(firstSource);
                        while (selectedNode != null) {
                            if (selectedNode instanceof DBSWrapper && ((DBSWrapper) selectedNode).getObject() instanceof DBSObjectContainer) {
                                break;
                            } else {
                                selectedNode = selectedNode.getParentNode();
                            }
                        }
                    }
                    return selectedNode;
                }

                @Override
                protected void setSelectedNode(@NotNull DBNDatabaseNode node) {
                    try {
                        node.initializeNode(null, status -> {
                            if (!status.isOK()) {
                                return;
                            }
                            if (!isContainerSelectable(node)) {
                                DBWorkbench.getPlatformUI().showError(
                                    DTUIMessages.database_consumer_page_mapping_title_mapping_error,
                                    DTUIMessages.database_consumer_page_mapping_error_message_import_not_supported
                                );
                                return;
                            }
                            settings.setContainer(DBUtils.getAdapter(DBSObjectContainer.class, node.getObject()));
                        });
                    } catch (DBException e) {
                        DBWorkbench.getPlatformUI().showError("Container init failed", null, e);
                    }
                    loadSettings(false);
                    setContainerInfo(node);
                    getWizard().runWithProgress(monitor -> {
                        // Reset mappings
                        for (DatabaseMappingContainer mappingContainer : settings.getDataMappings().values()) {
                            setMappingTarget(
                                monitor,
                                mappingContainer,
                                mappingContainer.getTargetName(),
                                true,
                                true);
                        }
                    });
                    mappingViewer.refresh();
                    updatePageCompletion();
                    setMessage(null);
                }
            };
        }

        Composite mappingsGroup = UIUtils.createComposite(composite, 2);
        mappingsGroup.setLayoutData(new GridData(GridData.FILL_BOTH));

        createMappingsTree(mappingsGroup);

        {
            // Control buttons
            buttonsPanel = UIUtils.createComposite(mappingsGroup, 1);
            buttonsPanel.setLayoutData(new GridData(GridData.FILL_VERTICAL));

            UIUtils.createLabelSeparator(buttonsPanel, SWT.HORIZONTAL);

            configureButton = UIUtils.createDialogButton(
                buttonsPanel,
                DTMessages.data_transfer_db_consumer_button_customise,
                DBIcon.TREE_COLUMNS,
                DTMessages.data_transfer_db_consumer_button_customise_description,
                SelectionListener.widgetSelectedAdapter(selectionEvent -> {
                    DatabaseMappingObject selectedMapping = getSelectedMapping();
                    mapColumnsAndTable(
                        selectedMapping instanceof DatabaseMappingContainer dmc ? dmc :
                            ((DatabaseMappingAttribute) selectedMapping).getParent());
                }));
            configureButton.setEnabled(false);

            previewButton = UIUtils.createDialogButton(
                buttonsPanel,
                DTMessages.data_transfer_wizard_page_preview_name,
                UIIcon.SQL_PREVIEW,
                DTMessages.data_transfer_wizard_page_preview_description,
                SelectionListener.widgetSelectedAdapter(e -> {
                    DBPDataSourceContainer dataSourceContainer = getDatabaseConsumerSettings().getContainer().getDataSource().getContainer();
                    if (!dataSourceContainer.hasModifyPermission(DBPDataSourcePermission.PERMISSION_EDIT_METADATA)) {
                        UIUtils.showMessageBox(
                            getShell(),
                            DTMessages.data_transfer_wizard_restricted_title,
                            NLS.bind(DTMessages.data_transfer_wizard_restricted_description, dataSourceContainer.getName()),
                            SWT.ICON_WARNING
                        );
                        return;
                    }
                    DatabaseMappingObject selectedMapping = getSelectedMapping();
                    showPreview(selectedMapping instanceof DatabaseMappingContainer ?
                        (DatabaseMappingContainer) selectedMapping :
                        ((DatabaseMappingAttribute)selectedMapping).getParent());
                }));
            previewButton.setEnabled(false);

            UIUtils.createLabelSeparator(buttonsPanel, SWT.HORIZONTAL);

            UIUtils.createEmptyLabel(buttonsPanel, 1, 1).setLayoutData(new GridData(GridData.FILL_VERTICAL));

            mappingRules = UIUtils.createDialogButton(
                buttonsPanel,
                DTMessages.data_transfer_db_consumer_mapping_rules_button,
                UIIcon.CONFIGURATION,
                DTMessages.data_transfer_db_consumer_mapping_rules_button_tip,
                SelectionListener.widgetSelectedAdapter(selectionEvent -> updateMappingRules()));
            mappingRules.setEnabled(false);

            mappingViewer.getTree().addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.character == SWT.SPACE) {
                        e.doit = false;
                    }
                }

                @Override
                public void keyReleased(KeyEvent e) {
                    try {
                        boolean updated = false;
                        Object element = null;
                        if (e.character == SWT.CR) {
                            //Object element = mappingViewer.getStructuredSelection().getFirstElement();
                            //mappingViewer.editElement(element, 1);
                        } else if (e.character == SWT.DEL) {
                            for (TreeItem item : mappingViewer.getTree().getSelection()) {
                                element = item.getData();
                                applyMappingSkip(element);
                            }
                            updated = true;
                        } else if (e.character == SWT.SPACE) {
                            for (TreeItem item : mappingViewer.getTree().getSelection()) {
                                if (item.getData() instanceof DatabaseMappingObject mapping
                                    && !isConfigurationRow(mapping)) {
                                    toggleMappingTransfer(mapping);
                                }
                            }
                        } else if (e.keyCode == SWT.SHIFT) {
                            TreeItem[] selection = mappingViewer.getTree().getSelection();
                            if (selection.length > 0) {
                                mappingViewer.editElement(selection[0].getData(), 1);
                            }
                        }
                        if (updated) {
                            Object nextParentElement = null;
                            int nextChildIndex = -1;
                            TreeItem[] curSelection = mappingViewer.getTree().getSelection();
                            if (curSelection.length > 0) {
                                TreeItem last = curSelection[curSelection.length - 1];
                                TreeItem parentItem = last.getParentItem();
                                if (parentItem != null) {
                                    nextParentElement = parentItem.getData();
                                    nextChildIndex = ArrayUtils.indexOf(parentItem.getItems(), last) + 1;
                                }
                            }
                            updateMappingsAndButtons();
                            updatePageCompletion();
                            if (element instanceof DatabaseMappingContainer) {
                                // Select next container
                                @SuppressWarnings("unchecked")
                                List<DatabaseMappingContainer> model = (List<DatabaseMappingContainer>) mappingViewer.getInput();
                                int curIndex = model.indexOf(element);
                                if (curIndex < model.size() - 1) {
                                    mappingViewer.setSelection(new StructuredSelection(model.get(curIndex + 1)), true);
                                }
                            } else if (nextParentElement != null) {
                                selectChildByPosition(nextParentElement, nextChildIndex);
                            }
                        }
                    } catch (DBException e1) {
                        DBWorkbench.getPlatformUI().showError(DTUIMessages.database_consumer_page_mapping_title_error_mapping_table,
                            DTUIMessages.database_consumer_page_mapping_message_error_mapping_target_table, e1);
                    }
                }
            });
            mappingViewer.addSelectionChangedListener(this::onMappingChanged);
        }

        {
            boolean withUpDown = getWizard().getSettings().getDataPipes().size() > 1;
            bottomBar = UIUtils.createComposite(composite, 5 + (withUpDown ? 2 : 0));
            bottomBar.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

            Label hintInfo = new Label(bottomBar, SWT.NONE);
            hintInfo.setImage(DBeaverIcons.getImage(DBIcon.SMALL_INFO));
            hintInfo.setCursor(hintInfo.getDisplay().getSystemCursor(SWT.CURSOR_HELP));
            hintInfo.setToolTipText(DTUIMessages.database_consumer_page_mapping_label_hint);

            recreateCheck = new Button(bottomBar, SWT.CHECK);
            recreateCheck.setText(DTUIMessages.database_consumer_page_mapping_button_recreate);
            recreateCheck.setLayoutData(new GridData());
            recreateCheck.setEnabled(false);
            recreateCheck.addSelectionListener(SelectionListener.widgetSelectedAdapter(e -> toggleRecreateSelection()));
            transformCheck = new Button(bottomBar, SWT.CHECK);
            transformCheck.setLayoutData(new GridData());
            transformCheck.setText(DTUIMessages.database_consumer_page_mapping_column_transformer_text);
            transformCheck.setToolTipText(DTUIMessages.database_consumer_page_mapping_button_transform_tip);
            transformCheck.setEnabled(false);
            transformCheck.addSelectionListener(SelectionListener.widgetSelectedAdapter(e -> onTransformCheckToggled()));

            transformCombo = new Combo(bottomBar, SWT.DROP_DOWN | SWT.READ_ONLY);
            transformCombo.setLayoutData(new GridData());
            transformCombo.setToolTipText(DTUIMessages.database_consumer_page_mapping_column_transformer_tip);
            transformCombo.setEnabled(false);
            for (DataTransferAttributeTransformerDescriptor transformer :
                DataTransferRegistry.getInstance().getAttributeTransformers()) {
                transformCombo.add(transformer.getName());
            }
            transformCombo.addListener(SWT.KeyDown, event -> {
                if (event.keyCode == SWT.ARROW_DOWN && !transformCombo.getListVisible()) {
                    event.doit = false;
                    transformCombo.setListVisible(true);
                } else if (transformCombo.getListVisible()
                    && (event.keyCode == SWT.ARROW_DOWN || event.keyCode == SWT.ARROW_UP)) {
                    // Native combos fire a selection event while the user is only moving the highlighted item.
                    transformComboKeyboardSelection = true;
                    transformCombo.getDisplay().asyncExec(() -> transformComboKeyboardSelection = false);
                } else if (event.keyCode == SWT.CR || event.keyCode == SWT.KEYPAD_CR) {
                    event.doit = false;
                    int selectionIndex = transformCombo.getSelectionIndex();
                    transformCombo.setListVisible(false);
                    transformCombo.select(selectionIndex);
                    onTransformComboSelected();
                } else if (transformCombo.getListVisible() && event.keyCode == SWT.ESC) {
                    event.doit = false;
                    transformCombo.setListVisible(false);
                    updateTransformControls(getTransformableSelection());
                }
            });
            transformCombo.addSelectionListener(new SelectionAdapter() {
                @Override
                public void widgetSelected(SelectionEvent e) {
                    if (!transformComboKeyboardSelection) {
                        onTransformComboSelected();
                    }
                }


                @Override
                public void widgetDefaultSelected(SelectionEvent e) {
                    onTransformComboSelected();
                }
            });
            if (withUpDown) {
                upButton = UIUtils.createPushButton(
                    bottomBar,
                    null,
                    DTMessages.data_transfer_db_consumer_up_tooltip,
                    UIIcon.ARROW_UP,
                    SelectionListener.widgetSelectedAdapter(e -> {
                        DataTransferPipe pipe = getPipeFromCurrentSelection();
                        DatabaseMappingContainer mappingContainer = getMappingContainerFromCurrentSelection();
                        if (pipe == null || mappingContainer == null) {
                            return;
                        }
                        getWizard().getSettings().processPipeEarlier(pipe);
                        CommonUtils.shiftLeft(model, mappingContainer);
                        mappingViewer.refresh();
                        updateUpAndDownButtons(pipe);
                    }));
                upButton.setEnabled(false);

                downButton = UIUtils.createPushButton(
                    bottomBar,
                    null,
                    DTMessages.data_transfer_db_consumer_down_tooltip,
                    UIIcon.ARROW_DOWN,
                    SelectionListener.widgetSelectedAdapter(e -> {
                        DataTransferPipe pipe = getPipeFromCurrentSelection();
                        DatabaseMappingContainer mappingContainer = getMappingContainerFromCurrentSelection();
                        if (pipe == null || mappingContainer == null) {
                            return;
                        }
                        getWizard().getSettings().processPipeLater(pipe);
                        CommonUtils.shiftRight(model, mappingContainer);
                        mappingViewer.refresh();
                        updateUpAndDownButtons(pipe);
                    }));
                downButton.setEnabled(false);
            }
        }
        composite.pack(true);
        setControl(composite);
    }

    private void updateUpAndDownButtons() {
        DataTransferPipe pipe = getPipeFromCurrentSelection();
        if (pipe != null) {
            updateUpAndDownButtons(pipe);
            return;
        }
        if (upButton != null) upButton.setEnabled(false);
        if (downButton != null) downButton.setEnabled(false);
    }

    private void updateUpAndDownButtons(@NotNull DataTransferPipe pipeFromCurrentSelection) {
        List<DataTransferPipe> pipes = getWizard().getSettings().getDataPipes();
        int idx = pipes.indexOf(pipeFromCurrentSelection);
        if (upButton != null) upButton.setEnabled(idx > 0);
        if (downButton != null) downButton.setEnabled(idx > -1 && idx < pipes.size() - 1);
    }

    private void selectChildByPosition(@NotNull Object parentElement, int childIndex) {
        if (childIndex < 0 || !(mappingViewer.testFindItem(parentElement) instanceof TreeItem parentItem)) {
            return;
        }
        TreeItem[] children = parentItem.getItems();
        if (childIndex < children.length) {
            mappingViewer.setSelection(new StructuredSelection(children[childIndex].getData()), true);
        }
    }

    private void createMappingsTree(@NotNull Composite composite) {
        // Mapping table
        mappingViewer = new CheckboxTreeViewer(composite, SWT.FULL_SELECTION);
        mappingViewer.getTree().setLayoutData(new GridData(GridData.FILL_BOTH));
        mappingViewer.getTree().setLinesVisible(false);
        mappingViewer.getTree().setHeaderVisible(true);
        mappingViewer.getTree().addControlListener(new ControlAdapter() {
            @Override
            public void controlResized(ControlEvent e) {
                updateTreeColumnWidths();
            }
        });

        final DBPDataSourceContainer container = DatabaseConsumerSettings.getDataSourceContainer(getWizard().getSettings());
        if (container != null) {
            loadMappingsButton = new Button(mappingViewer.getTree(), SWT.PUSH);
            loadMappingsButton.setText(NLS.bind(DTUIMessages.columns_mapping_dialog_composite_button_reconnect, container.getName()));
            loadMappingsButton.setImage(DBeaverIcons.getImage(UIIcon.SQL_CONNECT));
            loadMappingsButton.addSelectionListener(SelectionListener.widgetSelectedAdapter(
                e -> loadSettings(true)));

            final ControlEditor overlay = new ControlEditor(mappingViewer.getTree());
            final Point buttonSize = loadMappingsButton.computeSize(SWT.DEFAULT, SWT.DEFAULT);
            overlay.minimumWidth = buttonSize.x;
            overlay.minimumHeight = buttonSize.y;
            overlay.setEditor(loadMappingsButton);

            // Lines look weird on an empty table and visually clash with the button
            mappingViewer.getTree().setLinesVisible(false);
        } else {
            updateChooseContainerButton();
        }

        UIWidgets.setControlContextMenu(mappingViewer.getTree(), manager -> {
            IStructuredSelection selection = (IStructuredSelection) mappingViewer.getSelection();
            if (!selection.isEmpty()) {
                Object element = selection.getFirstElement();
                if (element instanceof DatabaseMappingAttribute mapping) {
                    if (mapping.getTransformer() != null && !mapping.getTransformer().getProperties().isEmpty()) {
                        manager.add(new Action("Transformer settings ...") {
                            @Override
                            public void run() {
                                AttributeTransformerSettingsDialog settingsDialog = new AttributeTransformerSettingsDialog(
                                    getShell(),
                                    mapping,
                                    mapping.getTransformer());
                                if (settingsDialog.open() == IDialogConstants.OK_ID) {
                                    mappingViewer.update(mapping, null);
                                }
                            }
                        });
                    }
                }
            }
            UIWidgets.fillDefaultTreeContextMenu(manager, mappingViewer.getTree());
        });

        mappingViewer.setCheckStateProvider(new ICheckStateProvider() {
            @Override
            public boolean isChecked(Object element) {
                return element instanceof DatabaseMappingObject mapping && mapping.getMappingType().isValid();
            }

            @Override
            public boolean isGrayed(Object element) {
                return isConfigurationRow(element);
            }
        });
        mappingViewer.addCheckStateListener(event -> {
            if (isConfigurationRow(event.getElement())) {
                mappingViewer.refresh(event.getElement());
                return;
            }
            if (event.getElement() instanceof DatabaseMappingObject mapping) {
                toggleMappingTransfer(mapping);
            }
        });

        // Source
        {
            TreeViewerColumn columnSource = new TreeViewerColumn(mappingViewer, SWT.LEFT);
            columnSource.setLabelProvider(new DelegatingStyledCellLabelProvider(new SourceStyledLabelProvider()));
            columnSource.getColumn().setText(DTUIMessages.database_consumer_page_mapping_column_source_text);
        }

        // Target
        {
            TreeViewerColumn columnTarget = new TreeViewerColumn(mappingViewer, SWT.LEFT);
            columnTarget.setLabelProvider(new DelegatingStyledCellLabelProvider(new TargetStyledLabelProvider()));
            columnTarget.getColumn().setText(DTUIMessages.database_consumer_page_mapping_column_target_text);
            columnTarget.setEditingSupport(new EditingSupport(mappingViewer) {
                @Override
                protected CellEditor getCellEditor(Object element) {
                    try {
                        return createTargetEditor(element);
                    } catch (DBException e) {
                        setErrorMessage(e.getMessage());
                        return null;
                    }
                }

                @Override
                protected boolean canEdit(Object element) {
                    return element instanceof DatabaseMappingObject mapping && isTargetEditable(mapping);
                }

                @Override
                protected Object getValue(Object element) {
                    DatabaseMappingObject mapping = (DatabaseMappingObject) element;
                    if (mapping.getMappingType() == DatabaseMappingType.unspecified) {
                        String targetName = mapping.getTargetName();
                        if (!CommonUtils.isEmpty(targetName)) {
                            return targetName;
                        }
                        return transformTargetName(DBUtils.getQuotedIdentifier(mapping.getSource()), DatabaseMappingType.unspecified);
                    }
                    return getTargetEditValue(mapping);
                }

                @Override
                protected void setValue(final Object element, Object value) {
                    final DatabaseConsumerSettings settings = getDatabaseConsumerSettings();
                    String name = CommonUtils.toString(value);
                    DatabaseMappingObject dmo = (DatabaseMappingObject) element;
                    DBPDataSource dataSource = settings.getTargetDataSource(dmo);
                    if (!name.equals(DatabaseMappingAttribute.TARGET_NAME_SKIP) && !name.equals(TARGET_NAME_BROWSE)
                        && !isConfigurationRow(dmo)
                        && dataSource != null && !DBUtils.isQuotedIdentifier(dataSource, name)
                    ) {
                        name = DBObjectNameCaseTransformer.transformName(dataSource, name);
                    }
                    setMappingTarget(
                        new LoggingProgressMonitor(log),
                        dmo,
                        name,
                        false,
                        false
                    );
                    mappingViewer.update(element, null);
                    mappingViewer.setSelection(mappingViewer.getSelection());
                    updatePageCompletion();
                }
            });
        }

        // Mapping
        {
            TreeViewerColumn columnMapping = new TreeViewerColumn(mappingViewer, SWT.CENTER);
            columnMapping.setLabelProvider(new MappingLabelProvider() {
                @Override
                public void update(ViewerCell cell) {
                    DatabaseMappingObject mapping = (DatabaseMappingObject) cell.getElement();
                    cell.setText("");
                    cell.setImage(getMappingTypeImage(mapping.getMappingType()));
                    super.update(cell);
                }

                @Override
                public String getToolTipText(Object element) {
                    DatabaseMappingType type = ((DatabaseMappingObject) element).getMappingType();
                    return type.isValid() ? type.name() : null;
                }
            });
        }

        new DefaultViewerToolTipSupport(mappingViewer);
        mappingViewer.setContentProvider(new TreeContentProvider() {
            @Override
            public boolean hasChildren(Object element) {
                return hasMappingChildren(element);
            }

            @Override
            public Object[] getChildren(Object parentElement) {
                return getElementChildren(parentElement);
            }
        });
        mappingViewer.addDoubleClickListener(event -> {
            DatabaseMappingObject selectedMapping = getSelectedMapping();
            if (selectedMapping instanceof DatabaseMappingContainer) {
                mapColumnsAndTable((DatabaseMappingContainer) selectedMapping);
            } else if (selectedMapping instanceof DatabaseMappingAttribute) {
                mapColumnsAndTable(((DatabaseMappingAttribute) selectedMapping).getParent());
            } else if (selectedMapping != null) {
                DatabaseMappingContainer parent = getMappingContainer(selectedMapping);
                if (parent != null) {
                    mapColumnsAndTable(parent);
                }
            }
        });
    }

    @NotNull
    protected Object[] getMappingChildren(@NotNull DatabaseMappingContainer containerMapping) {
        return containerMapping.getAttributeMappings().toArray();
    }

    protected boolean hasMappingChildren(@NotNull Object element) {
        return element instanceof DatabaseMappingContainer;
    }

    @Nullable
    protected Object[] getElementChildren(@NotNull Object element) {
        if (element instanceof DatabaseMappingContainer containerMapping) {
            return getMappingChildren(containerMapping);
        }
        return null;
    }

    protected boolean isConfigurationRow(@NotNull Object element) {
        return false;
    }

    protected boolean isTargetEditable(@NotNull DatabaseMappingObject mapping) {
        return true;
    }

    protected boolean shouldExpandOnToggle(@NotNull DatabaseMappingObject mapping) {
        return false;
    }

    @NotNull
    protected String getSourceLabel(@NotNull DatabaseMappingObject mapping) {
        if (mapping instanceof DatabaseMappingAttribute && mapping.getSource() != null) {
            return mapping.getSource().getName();
        }
        return DBUtils.getObjectFullName(mapping.getSource(), DBPEvaluationContext.UI);
    }

    @Nullable
    protected String getMappingTooltip(@NotNull DatabaseMappingObject mapping) {
        return null;
    }

    @Nullable
    private static Image getMappingTypeImage(@NotNull DatabaseMappingType type) {
        DBPImage icon = switch (type) {
            case existing -> DBIcon.EXISTING;
            case create -> DBIcon.CREATE;
            case recreate -> DBIcon.RECREATE;
            default -> null;
        };
        return icon == null ? null : DBeaverIcons.getImage(icon);
    }

    @Nullable
    protected Object getTargetEditValue(@NotNull DatabaseMappingObject mapping) {
        if (mapping instanceof DatabaseMappingContainer container) {
            DBSDataManipulator target = container.getTarget();
            return target != null ? target : mapping.getTargetName();
        }
        if (mapping instanceof DatabaseMappingAttribute attribute) {
            if (mapping.getMappingType() == DatabaseMappingType.existing) {
                return attribute.getTarget();
            }
            return mapping.getTargetName();
        }
        return mapping.getTargetName();
    }

    @Nullable
    protected DatabaseMappingContainer getMappingContainer(@NotNull DatabaseMappingObject mapping) {
        if (mapping instanceof DatabaseMappingContainer container) {
            return container;
        }
        if (mapping instanceof DatabaseMappingAttribute attribute) {
            return attribute.getParent();
        }
        return null;
    }

    protected void applyMappingType(@NotNull DatabaseMappingObject mapping, @NotNull DatabaseMappingType mappingType) throws DBException {
        if (mapping instanceof DatabaseMappingAttribute attributeMapping) {
            attributeMapping.setMappingType(mappingType);
        } else if (mapping instanceof DatabaseMappingContainer containerMapping) {
            containerMapping.refreshMappingType(getWizard().getRunnableContext(), mappingType, false);
        }
    }

    protected void applyMappingSkip(@Nullable Object element) throws DBException {
        if (element instanceof DatabaseMappingAttribute attribute) {
            attribute.setMappingType(DatabaseMappingType.skip);
        } else if (element instanceof DatabaseMappingContainer container) {
            container.refreshMappingType(getWizard().getRunnableContext(), DatabaseMappingType.skip, false);
        }
    }

    protected void applyMappingTransfer(@Nullable Object element) throws DBException {
        if (element instanceof DatabaseMappingAttribute attribute) {
            attribute.setMappingType(DatabaseMappingType.existing);
            attribute.updateMappingType(new LoggingProgressMonitor(log), false, false);
        } else if (element instanceof DatabaseMappingContainer container) {
            if (container.getMappingType() == DatabaseMappingType.skip) {
                for (DatabaseMappingAttribute attribute : container.getAttributeMappings()) {
                    if (attribute.getMappingType() == DatabaseMappingType.skip) {
                        attribute.setMappingType(DatabaseMappingType.unspecified);
                    }
                }
                container.setExtraMappingState(null);
            }
            container.refreshMappingType(
                getWizard().getRunnableContext(),
                container.getTarget() != null ? DatabaseMappingType.existing : DatabaseMappingType.create,
                false);
        }
    }

    private void toggleMappingTransfer(@NotNull DatabaseMappingObject mapping) {
        try {
            Object parentElement = null;
            int childIndex = -1;
            if (mappingViewer.testFindItem(mapping) instanceof TreeItem item) {
                TreeItem parentItem = item.getParentItem();
                if (parentItem != null) {
                    parentElement = parentItem.getData();
                    childIndex = ArrayUtils.indexOf(parentItem.getItems(), item);
                }
            }
            boolean wasExpanded = mappingViewer.getExpandedState(mapping);
            boolean checking = !mapping.getMappingType().isValid();
            if (mapping.getMappingType().isValid()) {
                applyMappingSkip(mapping);
            } else {
                applyMappingTransfer(mapping);
            }
            mappingViewer.refresh();
            updateMappingsAndButtons();
            updatePageCompletion();
            if (parentElement != null) {
                selectChildByPosition(parentElement, childIndex);
                Object updated = mappingViewer.getStructuredSelection().getFirstElement();
                if (updated != null && hasMappingChildren(updated)
                    && (wasExpanded || (checking && shouldExpandOnToggle(mapping)))) {
                    mappingViewer.setExpandedState(updated, true);
                }
            }
        } catch (DBException e) {
            DBWorkbench.getPlatformUI().showError(
                DTUIMessages.database_consumer_page_mapping_title_error_mapping_table,
                DTUIMessages.database_consumer_page_mapping_message_error_mapping_target_table,
                e);
        }
    }

    @Nullable
    private DatabaseMappingAttribute getTransformableSelection() {
        DatabaseMappingObject selectedMapping = getSelectedMapping();
        if (selectedMapping instanceof DatabaseMappingAttribute attribute && attribute.getMappingType().isValid()) {
            return attribute;
        }
        return null;
    }

    private void updateTransformControls(@Nullable DatabaseMappingObject selectedMapping) {
        if (transformCheck == null || transformCheck.isDisposed()) {
            return;
        }
        boolean isColumn = selectedMapping instanceof DatabaseMappingAttribute attribute
            && attribute.getMappingType().isValid();
        transformCheck.setEnabled(isColumn);
        if (!isColumn) {
            transformCheck.setSelection(false);
            transformCombo.deselectAll();
            transformCombo.setEnabled(false);
            return;
        }
        DataTransferAttributeTransformerDescriptor transformer =
            ((DatabaseMappingAttribute) selectedMapping).getTransformer();
        transformCheck.setSelection(transformer != null);
        transformCombo.setEnabled(transformer != null);
        if (transformer != null) {
            transformCombo.select(transformCombo.indexOf(transformer.getName()));
        } else {
            transformCombo.deselectAll();
        }
    }

    private void onTransformCheckToggled() {
        DatabaseMappingAttribute attribute = getTransformableSelection();
        if (attribute == null) {
            transformCheck.setSelection(false);
            return;
        }
        if (transformCheck.getSelection()) {
            transformCombo.setEnabled(true);
            int index = transformCombo.getSelectionIndex();
            if (index < 0 && transformCombo.getItemCount() > 0) {
                index = 0;
                transformCombo.select(0);
            }
            boolean applied = index >= 0 && applyTransformerByName(attribute, transformCombo.getItem(index));
            if (!applied) {
                updateTransformControls(attribute);
            }
        } else {
            applyTransformer(attribute, null);
            updateTransformControls(attribute);
        }
    }

    private void onTransformComboSelected() {
        DatabaseMappingAttribute attribute = getTransformableSelection();
        if (attribute == null) {
            return;
        }
        int index = transformCombo.getSelectionIndex();
        if (index < 0) {
            return;
        }
        if (applyTransformerByName(attribute, transformCombo.getItem(index))) {
            transformCheck.setSelection(true);
        } else {
            updateTransformControls(attribute);
        }
    }

    private boolean applyTransformerByName(@NotNull DatabaseMappingAttribute attribute, @Nullable String name) {
        DataTransferAttributeTransformerDescriptor transformer = CommonUtils.isEmpty(name)
            ? null
            : DataTransferRegistry.getInstance().getAttributeTransformerByName(name);
        return applyTransformer(attribute, transformer);
    }

    private boolean applyTransformer(
        @NotNull DatabaseMappingAttribute attribute,
        @Nullable DataTransferAttributeTransformerDescriptor transformer
    ) {
        if (transformer == attribute.getTransformer()) {
            return true;
        }
        if (transformer != null && !transformer.getProperties().isEmpty()) {
            AttributeTransformerSettingsDialog settingsDialog = new AttributeTransformerSettingsDialog(
                getShell(),
                attribute,
                transformer);
            if (settingsDialog.open() != IDialogConstants.OK_ID) {
                return false;
            }
        }
        attribute.setTransformer(transformer);
        mappingViewer.refresh();
        return true;
    }

    private void toggleRecreateSelection() {
        TreeItem[] selection = mappingViewer.getTree().getSelection();
        try {
            boolean recreateConfirmed = false;
            for (TreeItem item : selection) {
                if (!(item.getData() instanceof DatabaseMappingContainer container)) {
                    continue;
                }
                DatabaseMappingType type = container.getMappingType();
                if (type == DatabaseMappingType.existing) {
                    if (!recreateConfirmed) {
                        boolean confirmed = UIUtils.confirmAction(
                            getShell(),
                            DTUIMessages.database_consumer_page_mapping_recreate_confirm_title,
                            DTUIMessages.database_consumer_page_mapping_recreate_confirm_tip,
                            DBIcon.STATUS_WARNING);
                        if (!confirmed) {
                            return;
                        }
                        recreateConfirmed = true;
                    }
                    applyMappingType(container, DatabaseMappingType.recreate);
                } else if (type == DatabaseMappingType.recreate) {
                    applyMappingType(container, DatabaseMappingType.existing);
                }
            }
            mappingViewer.refresh();
            updateMappingsAndButtons();
            updatePageCompletion();
        } catch (DBException e) {
            DBWorkbench.getPlatformUI().showError(
                DTUIMessages.database_consumer_page_mapping_title_error_mapping_table,
                DTUIMessages.database_consumer_page_mapping_message_error_mapping_target_table,
                e);
        } finally {
            // The click already toggled the checkbox visually - re-sync it with the actual
            // mapping state (the confirmation may have been cancelled or the update failed)
            updateRecreateCheck(getSelectedMapping());
        }
    }

    @NotNull
    protected CustomComboBoxCellEditor createMappingTypeEditor(@NotNull DatabaseMappingObject mapping) {
        List<String> mappingTypes = new ArrayList<>();
        DatabaseMappingType mappingType = mapping.getMappingType();
        if (mappingType != DatabaseMappingType.skip) {
            mappingTypes.add(mappingType.name());
        }
        if (mapping instanceof DatabaseMappingContainer) {
            if (mappingType == DatabaseMappingType.existing || mappingType == DatabaseMappingType.create) {
                // Recreate can be used for not-existing at this moment tables if user will save this mapping in the task
                mappingTypes.add(DatabaseMappingType.recreate.name());
            } else if (mappingType == DatabaseMappingType.recreate) {
                // Depends on the existence of the target table
                if (mapping.getTarget() != null) {
                    mappingTypes.add(DatabaseMappingType.existing.name());
                } else {
                    mappingTypes.add(DatabaseMappingType.create.name());
                }
            }
        }
        if (mapping instanceof DatabaseMappingAttribute) {
            DatabaseMappingType parentMapping = ((DatabaseMappingAttribute) mapping).getParent().getMappingType();
            if (mappingType != parentMapping && parentMapping == DatabaseMappingType.create) {
                mappingTypes.add(DatabaseMappingType.create.name());
            }
        }
        return new CustomComboBoxCellEditor(
            mappingViewer,
            mappingViewer.getTree(),
            mappingTypes.toArray(new String[0]),
            SWT.DROP_DOWN | SWT.READ_ONLY);
    }

    @NotNull
    protected CellEditor createTargetEditor(@NotNull Object element) throws DBException {
        final DatabaseConsumerSettings settings = getDatabaseConsumerSettings();
        boolean allowsCreate = true;
        List<String> items = new ArrayList<>();
        boolean isContainer = false;

        if (element instanceof DatabaseMappingContainer dmc) {
            isContainer = true;
            if (settings.getContainer() == null) {
                allowsCreate = false;
            }
            if (settings.getContainer() != null) {
                // container's tables
                DBSObjectContainer container = settings.getContainer();
                Collection<? extends DBSObject> children = container.getChildren(new LoggingProgressMonitor(log));
                for (DBSObject child : CommonUtils.safeCollection(children)) {
                    if (child instanceof DBSDataManipulator) {
                        items.add(transformTargetName(
                            DBUtils.getQuotedIdentifier(child),
                            dmc.getMappingType()));
                    }
                }
            }
            items.add(TARGET_NAME_BROWSE);
        } else if (element instanceof DatabaseMappingAttribute mapping) {
            allowsCreate = switch (mapping.getParent().getMappingType()) {
                case skip, unspecified -> false;
                default -> true;
            };
            DBSDataManipulator target = mapping.getParent().getTarget();
            if (target instanceof DBSEntity parentEntity) {
                List<? extends DBSEntityAttribute> attributes = parentEntity.getAttributes(new LoggingProgressMonitor(log));
                for (DBSEntityAttribute attr : CommonUtils.safeCollection(attributes)) {
                    items.add(transformTargetName(DBUtils.getQuotedIdentifier(attr), mapping.getMappingType()));
                }
            } else if (target == null && mapping.getSource() != null) {
                // New table?
                items.add(transformTargetName(DBUtils.getQuotedIdentifier(mapping.getSource()), mapping.getMappingType()));
            }

        }
        items.add(DatabaseMappingAttribute.TARGET_NAME_SKIP);
        boolean finalAllowsCreate = allowsCreate;
        boolean finalIsContainer = isContainer;
        return new CellEditor(mappingViewer.getTree()) {
            private CCombo combo;

            @Override
            protected Control createControl(Composite parent) {
                Composite composite = UIUtils.createPlaceholder(parent, finalIsContainer ? 2 : 1, 0);

                combo = new CCombo(
                    composite,
                    SWT.DROP_DOWN | (finalAllowsCreate ? SWT.NONE : SWT.READ_ONLY));
                combo.setVisibleItemCount(15);
                combo.setItems(items.toArray(new String[0]));
                combo.setLayoutData(new GridData(GridData.FILL_BOTH));

                combo.addSelectionListener(SelectionListener.widgetSelectedAdapter(e -> {
                    String sel = combo.getText();
                    if (TARGET_NAME_BROWSE.equals(sel) && finalIsContainer) {
                        doSetValue(doGetValue());
                        openDialogBox();
                    } else {
                        markDirty();
                        doSetValue(sel);
                        fireApplyEditorValue();
                    }
                }));

                combo.addTraverseListener(e -> {
                    fireApplyEditorValue();
                    e.doit = false;
                });

                if (finalIsContainer) {
                    UIUtils.createPushButton(
                        composite,
                        null,
                        DTUIMessages.database_consumer_page_mapping_browse_button_tooltip,
                        UIIcon.DOTS_BUTTON,
                        SelectionListener.widgetSelectedAdapter(e -> {
                            Object newVal = openDialogBox();
                            doSetValue(newVal);
                            markDirty();
                            fireApplyEditorValue();
                        })
                    );
                }

                return composite;
            }

            @Override
            protected void doSetFocus() {
                if (combo != null && !combo.isDisposed()) {
                    combo.setFocus();
                }
            }

            private Object openDialogBox() {
                DatabaseMappingContainer dmc = (DatabaseMappingContainer) element;
                mapExistingTables(new DatabaseMappingContainer[]{dmc});
                return (dmc).getTargetName();
            }

            @Override
            protected Object doGetValue() {
                return combo != null && !combo.isDisposed()
                    ? combo.getText()
                    : "";
            }

            @Override
            protected void doSetValue(Object value) {
                if (combo == null || combo.isDisposed()) {
                    return;
                }
                if (value == null) {
                    combo.setText("");
                } else {
                    if (value instanceof DBPNamedObject dbpNamedObject) {
                        combo.setText(dbpNamedObject.getName());
                    } else {
                        combo.setText(CommonUtils.toString(value));
                    }
                }
            }
        };
    }

    protected void setMappingTarget(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DatabaseMappingObject mapping,
        @NotNull String name,
        boolean forceRefresh,
        boolean updateAttributesNames
    ) {
        final DatabaseConsumerSettings settings = getDatabaseConsumerSettings();
        try {
            if (name.equals(DatabaseMappingAttribute.TARGET_NAME_SKIP)) {
                if (mapping instanceof DatabaseMappingAttribute) {
                    ((DatabaseMappingAttribute) mapping).setMappingType(DatabaseMappingType.skip);
                } else {
                    ((DatabaseMappingContainer) mapping).refreshMappingType(
                        monitor,
                        DatabaseMappingType.skip,
                        false,
                        false);
                }
            } else if (name.equals(TARGET_NAME_BROWSE)) {
                mapExistingTable((DatabaseMappingContainer) mapping);
            } else {
                name = transformTargetName(name, mapping.getMappingType());
                if (mapping instanceof DatabaseMappingContainer containerMapping) {
                    if (settings.getContainer() != null) {
                        if (setMappingTargetContainer(monitor, containerMapping, settings, name, forceRefresh)) {
                            return;
                        }
                    }
                    if (forceRefresh && mapping.getMappingType() == DatabaseMappingType.recreate) {
                        // Keep container mapping type, refresh only attributes
                        containerMapping.refreshAttributesMappingTypes(monitor, false, false);
                    } else {
                        containerMapping.setTarget(null);
                        containerMapping.setTargetName(name);
                        containerMapping.refreshMappingType(monitor, DatabaseMappingType.create, forceRefresh, updateAttributesNames);
                    }
                } else if (mapping instanceof DatabaseMappingAttribute attrMapping) {
                    DBPDataSource targetDataSource = settings.getTargetDataSource(mapping);
                    if (attrMapping.getParent().getTarget() instanceof DBSEntity parentEntity) {
                        Iterable<? extends DBSEntityAttribute> attributes = parentEntity.getAttributes(new LoggingProgressMonitor(log));
                        if (attributes != null) {
                            DBSEntityAttribute matchingAttribute = CommonUtils.findBestCaseAwareMatch(
                                attributes,
                                targetDataSource != null ? DBUtils.getUnQuotedIdentifier(targetDataSource, name) : name, // unquote for better search
                                DBSEntityAttribute::getName);
                            if (matchingAttribute != null) {
                                attrMapping.setMappingType(DatabaseMappingType.existing);
                                attrMapping.setTarget(matchingAttribute);
                                attrMapping.setTargetName(name);
                                return;
                            }
                        }
                    }
                    attrMapping.setMappingType(DatabaseMappingType.create);
                    attrMapping.setTargetName(updateAttributesNames && targetDataSource != null
                        ? DBUtils.getUnQuotedIdentifier(targetDataSource, name) : name);
                }
                UIUtils.asyncExec(this::updateMappingsAndButtons);
            }
        } catch (Throwable e) {
            DBWorkbench.getPlatformUI().showError(DTUIMessages.database_consumer_page_mapping_title_mapping_error,
                NLS.bind(DTUIMessages.database_consumer_page_mapping_message_error_auto_mapping_source_table, name),
                e);
        }
    }

    private boolean setMappingTargetContainer(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DatabaseMappingContainer containerMapping,
        @NotNull DatabaseConsumerSettings settings,
        @NotNull String name,
        boolean forceRefresh
    ) throws DBException {
        // container's tables
        DBSObjectContainer container = settings.getContainer();
        String unQuotedNameForSearch = DBUtils.getUnQuotedIdentifier(container.getDataSource(), name);

        DBSDataManipulator targetDataContainer = null;

        // Check name conflict in namespace
        DBSNamespaceContainer namespaceContainer = DBUtils.getAdapter(DBSNamespaceContainer.class, container);
        DBSNamespace ns = null;
        if (namespaceContainer != null) {
            ns = namespaceContainer.getNamespaceForObjectType(RelationalObjectType.TYPE_TABLE);
            if (ns != null) {
                DBSObject existingObject = ns.getObjectByName(monitor, unQuotedNameForSearch);
                if (existingObject != null) {
                    if (existingObject instanceof DBSDataManipulator) {
                        targetDataContainer = (DBSDataManipulator) existingObject;
                    } else {
                        containerMapping.setTargetName(name);
                        containerMapping.refreshMappingType(
                            monitor,
                            DatabaseMappingType.unspecified,
                            false,
                            false);
                        mappingErrorMessage =
                            "Name '" + unQuotedNameForSearch + "' is already used by " + DBUtils.getObjectTypeName(existingObject);

                        UIUtils.asyncExec(() -> mappingViewer.refresh());
                        return true;
                    }
                }
            }
        }

        if (targetDataContainer == null && ns == null) {
            // Without a namespace, search for an existing data manipulator (writable table).
            // A namespace lookup already covers a missing name without loading every child in the container.
            for (DBSObject child : CommonUtils.safeCollection(container.getChildren(monitor))) {
                if (child instanceof DBSDataManipulator && unQuotedNameForSearch.equalsIgnoreCase(child.getName())) {
                    targetDataContainer = (DBSDataManipulator) child;
                    break;
                }
            }
        }
        if (targetDataContainer != null) {
            containerMapping.setTarget(targetDataContainer);
            if (forceRefresh && containerMapping.getMappingType() == DatabaseMappingType.recreate) {
                // Keep container mapping type, refresh only attributes
                containerMapping.refreshAttributesMappingTypes(monitor, false, false);
            } else {
                containerMapping.refreshMappingType(monitor, DatabaseMappingType.existing, false, false);
            }

            DBSDataManipulator finalTargetDataContainer = targetDataContainer;
            UIUtils.asyncExec(() -> {
                DataTransferPipe pipeFromCurrentSelection = getPipeFromCurrentSelection();
                if (pipeFromCurrentSelection != null) {
                    IDataTransferConsumer<?, ?> consumer = pipeFromCurrentSelection.getConsumer();
                    if (consumer instanceof DatabaseTransferConsumer) {
                        ((DatabaseTransferConsumer) consumer).setTargetObject(finalTargetDataContainer);
                    }
                }
                mappingViewer.refresh();
            });
            return true;
        }
        return false;
    }

    private void updateMappingRules() {
        DBSObjectContainer container = getDatabaseConsumerSettings().getContainer();
        if (container == null) {
            return;
        }
        DBPDataSource dataSource = container.getDataSource();
        if (dataSource == null) {
            return;
        }
        List<Object> elementList = Arrays.stream(mappingViewer.getTree().getItems())
            .map(Widget::getData).collect(Collectors.toList());
        MappingRulesDialog dialog = new MappingRulesDialog(getShell(), dataSource, elementList);
        if (dialog.open() == IDialogConstants.OK_ID) {
            mappingViewer.refresh();
            updateMappingsAndButtons();
            updatePageCompletion();
        }
    }

    void autoAssignMappings() {
        List<Object> elementList = Arrays.stream(mappingViewer.getTree().getItems())
            .map(Widget::getData).toList();

        getWizard().runWithProgress(monitor -> {
            if (getWizard().getSettings().getDataPipes().size() > 1) {
                getWizard().getSettings().sortDataPipes(monitor);
            }
            //loadAndUpdateColumnsModel();
            for (Object element : elementList) {
                if (element instanceof DatabaseMappingContainer container) {
                    setMappingTarget(monitor, container, container.getTargetName(), true, false);
                }
            }
        });
        updateMappingsAndButtons();
        updatePageCompletion();
    }

    private void mapExistingTable(@NotNull DatabaseMappingContainer mapping) {
        mapExistingTables(new DatabaseMappingContainer[]{mapping});
    }

    private void mapExistingTables(@NotNull DatabaseMappingContainer[] mappings) {
        final DatabaseConsumerSettings settings = getDatabaseConsumerSettings();
        DBPProject activeProject = DBWorkbench.getPlatform().getWorkspace().getActiveProject();
        if (activeProject != null) {
            DBNNode rootNode = DBNUtils.getNodeByObject(settings.getContainer());
            DBNModel navigatorModel = DBWorkbench.getPlatform().getNavigatorModel();
            if (rootNode == null) {
                rootNode = navigatorModel.getRoot().getProjectNode(
                    activeProject).getDatabases();
            }
            DBNNode selectedNode = rootNode;
            if (mappings.length == 1 && mappings[0].getTarget() != null) {
                selectedNode = navigatorModel.getNodeByObject(mappings[0].getTarget());
            }
            DBNNode node = DBWorkbench.getPlatformUI().selectObject(
                getShell(),
                DTUIMessages.database_consumer_page_mapping_node_title,
                rootNode,
                selectedNode,
                new Class[] {DBSObjectContainer.class, DBSDataManipulator.class},
                new Class[] {DBSDataManipulator.class},
                null);
            if (node instanceof DBSWrapper dbw) {
                DBSObject object = dbw.getObject();
                try {
                    boolean needsUpdate = false;
                    for (DatabaseMappingContainer mapping : mappings) {
                        if (object instanceof DBSDataManipulator dm) {
                            mapping.setTarget(dm);
                            mapping.refreshMappingType(getWizard().getRunnableContext(), DatabaseMappingType.existing, false);
                            if (mappings.length == 1) {
                                // Call to this method also shows up a dialog.
                                // It could be very noisy in case of a large amount of mappings
                                UIUtils.asyncExec(() -> mapColumnsAndTable(mapping));
                            } else {
                                needsUpdate = true;
                            }
                        } else {
                            mapping.setTarget(null);
                            mapping.refreshMappingType(getWizard().getRunnableContext(), DatabaseMappingType.unspecified, false);
                        }
                    }
                    if (needsUpdate) {
                        mappingViewer.refresh();
                        updatePageCompletion();
                    }
                } catch (DBException e) {
                    DBWorkbench.getPlatformUI().showError(DTUIMessages.database_consumer_page_mapping_title_error_mapping_table,
                        DTUIMessages.database_consumer_page_mapping_message_error_mapping_existing_table, e);
                }
                updateMappingsAndButtons();
                updatePageCompletion();
            }
        }
    }

    public void updateMappingsAndButtons() {
        mappingViewer.refresh();
        mappingViewer.setSelection(mappingViewer.getSelection());
    }

    private String transformTargetName(String name, @NotNull DatabaseMappingType mappingType) {
        DBSObjectContainer container = getDatabaseConsumerSettings().getContainer();
        if (container == null || container.getDataSource() == null) {
            return name;
        }
        if (mappingType == DatabaseMappingType.create) {
            return DatabaseTransferUtils.getTransformedName(container.getDataSource(), name, false);
        }
        return DBObjectNameCaseTransformer.transformName(container.getDataSource(), name);
    }

    protected void mapColumnsAndTable(DatabaseMappingContainer mapping) {
        ConfigureMetadataStructureDialog dialog = new ConfigureMetadataStructureDialog(
            getWizard(),
            getDatabaseConsumerSettings(),
            mapping,
            this);
        if (dialog.open() == IDialogConstants.OK_ID) {
            mappingViewer.refresh();
            updatePageCompletion();
        }

    }

    private void showPreview(DatabaseMappingContainer mappingContainer) {
        DataTransferPipe pipe = getPipe(mappingContainer);
        DataTransferSettings dtSettings = getWizard().getSettings();

        PreviewMappingDialog previewDialog = new PreviewMappingDialog(
            getShell(),
            pipe,
            mappingContainer,
            dtSettings);
        previewDialog.open();
    }

    @Nullable
    private DatabaseMappingContainer getMappingContainerFromCurrentSelection() {
        for (Object o: mappingViewer.getStructuredSelection()) {
            if (o instanceof DatabaseMappingContainer) {
                return (DatabaseMappingContainer) o;
            }
        }
        return null;
    }

    @Nullable
    private DataTransferPipe getPipeFromCurrentSelection() {
        DatabaseMappingContainer mappingContainer = getMappingContainerFromCurrentSelection();
        if (mappingContainer == null) {
            return null;
        }
        return getPipe(mappingContainer);
    }

    @Nullable
    protected DataTransferPipe getPipe(DatabaseMappingContainer mappingContainer) {
        final DatabaseConsumerSettings settings = getDatabaseConsumerSettings();
        for (DataTransferPipe pipe : getWizard().getSettings().getDataPipes()) {
            if (pipe.getProducer() == null) {
                continue;
            }
            DBSDataContainer sourceObject = (DBSDataContainer)pipe.getProducer().getDatabaseObject();
            DatabaseMappingContainer mapping = settings.getDataMapping(sourceObject);
            if (mapping == mappingContainer) {
                return pipe;
            }
        }
        return null;
    }

    protected DatabaseMappingObject getSelectedMapping() {
        IStructuredSelection selection = (IStructuredSelection) mappingViewer.getSelection();
        return selection.isEmpty() ? null : (DatabaseMappingObject) selection.getFirstElement();
    }

    @Override
    public void activatePage() {
        final DBPDataSourceContainer container = DatabaseConsumerSettings.getDataSourceContainer(getWizard().getSettings());
        final DBPPreferenceStore preferences = DTActivator.getDefault().getPreferences();

        if (getDatabaseConsumerSettings().getContainer() != null ||
            container != null && container.isConnected() ||
            preferences.getBoolean(DTConstants.PREF_RECONNECT_TO_LAST_DATABASE)
        ) {
            loadSettings(true);
        } else if (container != null && getDatabaseConsumerSettings().getContainer() == null) {
           String containerPath = DatabaseConsumerSettings.getSavedContainerPath(getWizard().getSettings());
            if (containerPath != null) {
                containerPanel.setContainerText(
                    containerPath.replace('/', '.') + "  [" + container.getName() + "]");
            }
        }

        UIUtils.asyncExec(this::updateTreeColumnWidths);
    }

    private void updateTreeColumnWidths() {
        Tree tree = mappingViewer.getTree();
        if (tree.isDisposed()) {
            return;
        }
        TreeColumn[] columns = tree.getColumns();
        int totalWidth = tree.getClientArea().width;
        if (columns.length < 3 || totalWidth <= 0) {
            return;
        }
        int rest = Math.max(totalWidth - MAPPING_COLUMN_WIDTH - CHECKBOX_COLUMN_WIDTH, 0);
        setColumnWidth(columns[0], rest / 2);
        setColumnWidth(columns[1], rest - rest / 2);
        setColumnWidth(columns[2], MAPPING_COLUMN_WIDTH);
    }

    private static void setColumnWidth(@NotNull TreeColumn column, int width) {
        if (column.getWidth() != width) {
            column.setWidth(width);
        }
    }

    private void loadSettings(boolean loadContainerFromSettings) {
        if (loadMappingsButton != null && !loadMappingsButton.isDisposed()) {
            loadMappingsButton.dispose();
        }

        getWizard().loadNodeSettings();

        // Detect producer container (e.g. schema)
        DBSObjectContainer producerContainer = null;
        for (DataTransferPipe pipe : getWizard().getSettings().getDataPipes()) {
            if (pipe.getProducer() != null) {
                DBSObject producerObject = pipe.getProducer().getDatabaseObject();
                if (producerObject instanceof DBSDataContainer) {
                    DBSObject container = producerObject.getParentObject();
                    if (container instanceof DBSObjectContainer) {
                        producerContainer = (DBSObjectContainer) container;
                    }
                }
            }
        }

        if (loadContainerFromSettings) {
            DatabaseConsumerSettings settings = getDatabaseConsumerSettings();
            settings.loadObjectContainer(getWizard().getRunnableContext(), getWizard().getSettings(), producerContainer);
            if (settings.getContainer() != null) {
                final DBNDatabaseNode[] containerNode = new DBNDatabaseNode[1];
                try {
                    getWizard().getRunnableContext().run(
                        true,
                        true,
                        monitor -> containerNode[0] = DBNUtils.getNodeByObject(monitor, settings.getContainer(), false)
                    );
                } catch (InvocationTargetException | InterruptedException ignored) {
                }
                if (containerNode[0] != null) {
                    try {
                        containerPanel.checkValidContainerNode(containerNode[0]);
                        containerPanel.setContainerInfo(containerNode[0]);
                    } catch (DBException e) {
                        setErrorMessage(e.getMessage());
                    }
                }
            }
        }

        if (getDatabaseConsumerSettings().getContainer() == null) {
            containerPanel.setContainerText(null);
        }

        loadAndUpdateColumnsModel();
        // loading may be deferred until the user explicitly connects to the target database
        if (firstInit && getDatabaseConsumerSettings().getContainer() != null && !model.isEmpty()) {
            firstInit = false;
            UIUtils.asyncExec(() -> {
                if (!mappingViewer.getTree().isDisposed()) {
                    updateTreeColumnWidths();
                    autoAssignMappings();
                }
            });
        }
        updatePageCompletion();
    }

    private void loadAndUpdateColumnsModel() {
        // Load columns model. Update it only if mapping have different set of source columns
        // Otherwise we keep current mappings (to allow wizard page navigation without loosing mappings)
        DatabaseConsumerSettings settings = getDatabaseConsumerSettings();
        model.clear();

        List<Throwable> errors = new ArrayList<>();

        try {
            Set<DBSObjectContainer> containersToCache = new HashSet<>();

            for (DataTransferPipe pipe : getWizard().getSettings().getDataPipes()) {
                if (pipe.getProducer() == null) {
                    continue;
                }
                DBSObject dbObject = pipe.getProducer().getDatabaseObject();
                if (!(dbObject instanceof DBSDataContainer sourceDataContainer)) {
                    continue;
                }

                DBSObject parentObject = sourceDataContainer.getParentObject();
                DBSObjectContainer container = DBUtils.getAdapter(DBSObjectContainer.class, parentObject);
                if (container != null) {
                    containersToCache.add(container);
                }
            }

            getWizard().getRunnableContext().run(true, true, monitor -> {
                for (DBSObjectContainer container : containersToCache) {
                    try {
                        container.cacheStructure(monitor, DBSObjectContainer.STRUCT_ATTRIBUTES);
                    } catch (DBException e) {
                        errors.add(e);
                        log.debug(
                            "Error structure for container '" +
                                DBUtils.getObjectFullName(container, DBPEvaluationContext.UI) + "'",
                            e
                        );
                    }
                }
                for (DataTransferPipe pipe : getWizard().getSettings().getDataPipes()) {
                    if (pipe.getProducer() == null || !(pipe.getProducer().getDatabaseObject() instanceof DBSDataContainer sourceDataContainer)) {
                        continue;
                    }

                    DatabaseMappingContainer mapping = settings.getDataMapping(sourceDataContainer);

                    // Create new mapping for source object
                    DatabaseMappingContainer newMapping;
                    IDataTransferConsumer<?, ?> pipeConsumer = pipe.getConsumer();
                    if (pipeConsumer instanceof DatabaseTransferConsumer databaseTransferConsumer && databaseTransferConsumer.getTargetObject() != null) {
                        try {
                            newMapping = new DatabaseMappingContainer(
                                monitor,
                                getDatabaseConsumerSettings(),
                                sourceDataContainer,
                                databaseTransferConsumer.getTargetObject()
                            );
                        } catch (DBException e) {
                            errors.add(e);
                            newMapping = new DatabaseMappingContainer(getDatabaseConsumerSettings(), sourceDataContainer);
                        }
                    } else {
                        newMapping = new DatabaseMappingContainer(getDatabaseConsumerSettings(), sourceDataContainer);
                    }

                    newMapping.getAttributeMappings(monitor);

                    // Update current mapping if it differs from new one
                    if (mapping == null || !mapping.isSameMapping(newMapping)) {
                        mapping = newMapping;
                        settings.addDataMappings(getWizard().getRunnableContext(), sourceDataContainer, mapping);
                    }
                    model.add(mapping);
                }
            });
        } catch (InvocationTargetException e) {
            errors.add(e.getTargetException());
        } catch (InterruptedException e) {
            errors.add(e);
        }

        if (!errors.isEmpty()) {
            Throwable lastError = errors.getLast();
            log.error(lastError);
            setMessage(lastError.getMessage(), IMessageProvider.ERROR);
        }

        if (settings.getContainer() == null) {
            mappingViewer.setInput(List.of());
            return;
        }

        Object[] expandedElements = mappingViewer.getExpandedElements();
        mappingViewer.setInput(model);
        mappingViewer.setExpandedElements(expandedElements);

        if (!model.isEmpty()) {
            // Select first element
            mappingViewer.setSelection(new StructuredSelection(model.getFirst()));
        }
    }


    @Override
    protected boolean determinePageCompletion()
    {
        final DatabaseConsumerSettings settings = getDatabaseConsumerSettings();
        if (settings.getContainer() == null) {
            setErrorMessage(DTUIMessages.database_consumer_page_mapping_error_message_set_target_container);
            return false;
        }
        if (!settings.isCompleted(getWizard().getSettings().getDataPipes())) {
            String errorMessage = DTUIMessages.database_consumer_page_mapping_error_message_set_all_tables_mappings;
            if (mappingErrorMessage != null) {
                errorMessage += ": " + mappingErrorMessage;
            }
            setErrorMessage(errorMessage);
            return false;
        } else {
            setErrorMessage(null);
            return true;
        }
    }

    @Override
    protected void updatePageCompletion() {
        super.updatePageCompletion();
        updateChooseContainerButton();
    }

    private void updateChooseContainerButton() {
        if (mappingViewer == null || mappingViewer.getTree().isDisposed()) {
            return;
        }
        boolean needed = getDatabaseConsumerSettings().getContainer() == null
            && (loadMappingsButton == null || loadMappingsButton.isDisposed());
        boolean present = chooseContainerButton != null && !chooseContainerButton.isDisposed();
        if (needed && !present) {
            chooseContainerButton = new Button(mappingViewer.getTree(), SWT.PUSH);
            chooseContainerButton.setText(DTMessages.data_transfer_db_consumer_choose_container);
            chooseContainerButton.setImage(DBeaverIcons.getImage(UIIcon.OPEN));
            chooseContainerButton.addSelectionListener(SelectionListener.widgetSelectedAdapter(
                e -> containerPanel.browseContainer()));

            chooseContainerEditor = new ControlEditor(mappingViewer.getTree());
            final Point buttonSize = chooseContainerButton.computeSize(SWT.DEFAULT, SWT.DEFAULT);
            chooseContainerEditor.minimumWidth = buttonSize.x;
            chooseContainerEditor.minimumHeight = buttonSize.y;
            chooseContainerEditor.setEditor(chooseContainerButton);
        } else if (!needed && present) {
            chooseContainerButton.dispose();
            chooseContainerButton = null;
            if (chooseContainerEditor != null) {
                chooseContainerEditor.dispose();
                chooseContainerEditor = null;
            }
        }
    }

    @Override
    public boolean isPageApplicable() {
        return isConsumerOfType(DatabaseTransferConsumer.class);
    }

    protected void onMappingChanged(SelectionChangedEvent event) {
        DatabaseMappingObject selectedMapping = getSelectedMapping();
        boolean hasMappings = hasMappings(selectedMapping);
        configureButton.setEnabled(hasMappings);
        previewButton.setEnabled(hasMappings);
        mappingRules.setEnabled(hasMappings);
        boolean isContainer = selectedMapping instanceof DatabaseMappingContainer;
        boolean isColumn = selectedMapping instanceof DatabaseMappingAttribute;
        updateRecreateCheck(selectedMapping);
        setControlExcluded(recreateCheck, !isContainer);
        setControlExcluded(transformCheck, !isColumn);
        transformCombo.setVisible(isColumn);
        layoutBottomBar();
        updateTransformControls(selectedMapping);
        updateUpAndDownButtons();
    }

    private void updateRecreateCheck(@Nullable DatabaseMappingObject selectedMapping) {
        if (recreateCheck == null || recreateCheck.isDisposed()) {
            return;
        }
        boolean isContainer = selectedMapping instanceof DatabaseMappingContainer;
        DatabaseMappingType mappingType = selectedMapping == null ? null : selectedMapping.getMappingType();
        recreateCheck.setEnabled(isContainer
            && (mappingType == DatabaseMappingType.existing || mappingType == DatabaseMappingType.recreate));
        recreateCheck.setSelection(isContainer && mappingType == DatabaseMappingType.recreate);
    }

    private static void setControlExcluded(@Nullable Control control, boolean excluded) {
        if (control == null || control.isDisposed()) {
            return;
        }
        control.setVisible(!excluded);
        if (control.getLayoutData() instanceof GridData gd) {
            gd.exclude = excluded;
        }
    }

    private void layoutBottomBar() {
        if (bottomBar == null || bottomBar.isDisposed()) {
            return;
        }
        bottomBar.layout(true);
    }

    protected boolean hasMappings(@Nullable DatabaseMappingObject mapping) {
        // There is nothing to check if the target container is not chosen
        if (getDatabaseConsumerSettings().getContainer() == null) {
            return false;
        }

        if (mapping == null) {
            return false;
        }

        if (mapping instanceof DatabaseMappingContainer container) {
            return container.getMappingType() != DatabaseMappingType.unspecified;
        }
        if (mapping instanceof DatabaseMappingAttribute attribute) {
            return attribute.getParent().getMappingType() != DatabaseMappingType.unspecified;
        }
        return false;
    }
}
