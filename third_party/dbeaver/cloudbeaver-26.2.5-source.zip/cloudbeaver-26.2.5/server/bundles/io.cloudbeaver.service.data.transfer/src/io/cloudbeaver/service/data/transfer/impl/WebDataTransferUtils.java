/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.service.data.transfer.impl;

import io.cloudbeaver.model.session.WebSession;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.preferences.DBPPropertyDescriptor;
import org.jkiss.dbeaver.tools.transfer.registry.DataTransferProcessorDescriptor;
import org.jkiss.utils.CommonUtils;

import java.util.HashMap;
import java.util.Map;

class WebDataTransferUtils {

    private static final Log log = Log.getLog(WebDataTransferUtils.class);
    public static final String EXTENSION = "extension";


    public static String getProcessorFileExtension(DataTransferProcessorDescriptor processor) {
        return processor.getProcessorFileExtension();
    }

    public static String getProcessorFileExtension(DataTransferProcessorDescriptor processor, Map<String, Object> processorProperties) {
        if (processorProperties != null && processorProperties.get(EXTENSION) != null) {
            return CommonUtils.toString(processorProperties.get(EXTENSION), "data");
        }

        return processor.getProcessorFileExtension();
    }

    @NotNull
    static Map<String, Object> makeProcessorProperties(
        @NotNull DataTransferProcessorDescriptor processor,
        @Nullable Map<String, Object> processorProperties
    ) {
        Map<String, Object> properties = new HashMap<>();
        for (DBPPropertyDescriptor property : processor.getProperties()) {
            Object value = processorProperties == null ? null : processorProperties.get(property.getId());
            properties.put(property.getId(), value != null ? value : property.getDefaultValue());
        }
        return properties;
    }

    @NotNull
    public static String normalizeFileName(
        @NotNull String fileName,
        @NotNull WebDataTransferOutputSettings outputSettings
    ) {
        return outputSettings.isCompress() ? fileName + ".zip" : fileName;
    }

    @NotNull
    public static WebDataTransferSessionConfig getSessionDataTransferConfig(@NotNull WebSession session) {
        return session.getAttribute(
            "dataTransfer",
            x -> new WebDataTransferSessionConfig(),
            WebDataTransferSessionConfig::deleteExportFiles
        );
    }
}
