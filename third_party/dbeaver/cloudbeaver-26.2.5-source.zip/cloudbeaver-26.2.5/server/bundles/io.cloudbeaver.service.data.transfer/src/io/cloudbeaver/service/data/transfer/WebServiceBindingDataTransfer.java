/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.service.data.transfer;

import io.cloudbeaver.server.CBApplication;
import io.cloudbeaver.service.DBWBindingContext;
import io.cloudbeaver.service.DBWServiceBindingServlet;
import io.cloudbeaver.service.DBWServletContext;
import io.cloudbeaver.service.WebServiceBindingBase;
import io.cloudbeaver.service.data.transfer.impl.*;
import io.cloudbeaver.service.sql.WebServiceBindingSQL;
import org.jkiss.code.NotNull;
import org.jkiss.dbeaver.DBException;

/**
 * Web service implementation
 */
public class WebServiceBindingDataTransfer extends WebServiceBindingBase<DBWServiceDataTransfer> implements DBWServiceBindingServlet<CBApplication<?>> {

    public WebServiceBindingDataTransfer() {
        super(DBWServiceDataTransfer.class, new WebServiceDataTransfer(), "schema/service.data.transfer.graphqls");
    }

    @Override
    public void bindWiring(DBWBindingContext model) {

        model.getQueryType()
            .dataFetcher("dataTransferAvailableStreamProcessors",
                env -> getService(env).getAvailableStreamProcessors(getWebSession(env)))
            .dataFetcher("dataTransferAvailableImportStreamProcessors",
                env -> getService(env).getAvailableImportStreamProcessors(getWebSession(env)))
            .dataFetcher("dataTransferExportDataFromContainer", env -> getService(env).dataTransferExportDataFromContainer(
                WebServiceBindingSQL.getSQLProcessor(env),
                getArgumentVal(env, "containerNodePath"),
                new WebDataTransferParameters(getArgument(env, "parameters"))
            ))
            .dataFetcher("dataTransferExportDataFromResults", env -> getService(env).dataTransferExportDataFromResults(
                WebServiceBindingSQL.getSQLContext(env),
                getArgumentVal(env, "resultsId"),
                new WebDataTransferParameters(getArgument(env, "parameters"))
            ))
            .dataFetcher("dataTransferImportDataIntoResults", env -> getService(env).asyncImportDataContainer(
                WebServiceBindingSQL.getSQLContext(env),
                getArgument(env, "resultsId"),
                new WebDataTransferImportParameters(getArgument(env, "parameters")),
                getWebSession(env)
            ))
            .dataFetcher("dataTransferRemoveDataFile", env -> getService(env).dataTransferRemoveDataFile(
                getWebSession(env),
                getArgumentVal(env, "dataFileId")
            ))
            .dataFetcher("dataTransferDefaultExportSettings", env -> getService(env).defaultExportSettings())
        ;

    }

    @Override
    public void addServlets(@NotNull CBApplication<?> application, @NotNull DBWServletContext servletContext) throws DBException {
        if (!application.isMultiuser()) {
            return;
        }
        servletContext.addServlet(
            "dataTransfer",
            new WebDataTransferServlet(application, getServiceImpl()),
            application.getServicesURI() + "data/*"
        );
        servletContext.addServlet(
                "dataTransferImport",
                new WebDataTransferImportServlet(application, getServiceImpl()),
                application.getServicesURI() + "data/import/*"
        );
    }
}
