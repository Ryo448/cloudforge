/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.service.core;

import io.cloudbeaver.*;
import io.cloudbeaver.model.*;
import io.cloudbeaver.model.session.WebSession;
import io.cloudbeaver.service.DBWService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.model.connection.DBPConnectionType;
import org.jkiss.dbeaver.model.rm.RMConstants;
import org.jkiss.dbeaver.registry.DataSourceNavigatorSettings;
import org.jkiss.dbeaver.registry.settings.ProductSettingDescriptor;

import java.util.List;
import java.util.Map;

/**
 * Web service API
 */
public interface DBWServiceCore extends DBWService {

    @NotNull
    @WebAction(authRequired = false, initializationRequired = false, configurationModeAllowed = true)
    WebServerConfig getServerConfig(@Nullable WebSession webSession) throws DBWebException;

    /**
     * Returns information of system.
     */
    @WebAction
    WebPropertyInfo[] getSystemInformationProperties(@NotNull WebSession webSession);

    @WebAction(configurationModeAllowed = true)
    WebGroupPropertiesInfo<ProductSettingDescriptor> getProductSettings(@NotNull WebSession webSession);

    @NotNull
    @WebAction(configurationModeAllowed = true)
    List<WebDatabaseDriverInfo> getDriverList(@NotNull WebSession webSession, @Nullable String driverId) throws DBWebException;

    @WebAction
    List<WebDatabaseAuthModel> getAuthModels(@NotNull WebSession webSession);

    @WebAction
    List<WebNetworkHandlerDescriptor> getNetworkHandlers(@NotNull WebSession webSession);

    @WebAction(authRequired = false)
    List<WebConnectionInfo> getUserConnections(
        @NotNull WebSession webSession,
        @Nullable String projectId,
        @Nullable String id,
        @Nullable List<String> projectIds) throws DBWebException;

    @WebAction(authRequired = false)
    List<WebConnectionFolderInfo> getConnectionFolders(
        @NotNull WebSession webSession, @Nullable String projectId, @Nullable String id) throws DBWebException;

    @NotNull
    @WebAction(authRequired = false, configurationModeAllowed = true)
    String[] getSessionPermissions(@NotNull WebSession webSession) throws DBWebException;

    ///////////////////////////////////////////
    // Session

    @NotNull
    @WebAction(authRequired = false, configurationModeAllowed = true)
    WebSession openSession(
        @NotNull WebSession webSession,
        @Nullable String defaultLocale,
        @NotNull HttpServletRequest servletRequest,
        @NotNull HttpServletResponse servletResponse) throws DBWebException;

    @NotNull
    @WebAction(authRequired = false, configurationModeAllowed = true)
    WebSession getSessionState(@NotNull WebSession webSession) throws DBWebException;

    @WebAction
    List<WebServerMessage> readSessionLog(@NotNull WebSession webSession, Integer maxEntries, Boolean clearEntries) throws DBWebException;

    @WebAction(authRequired = false)
    boolean closeSession(HttpServletRequest request) throws DBWebException;

    @Deprecated
    @WebAction(authRequired = false)
    boolean touchSession(@NotNull HttpServletRequest request, @NotNull HttpServletResponse servletResponse) throws DBWebException;

    @Deprecated
    @WebAction(authRequired = false)
    WebSession updateSession(@NotNull HttpServletRequest request, @NotNull HttpServletResponse response)
        throws DBWebException;

    @WebAction(authRequired = false)
    boolean refreshSessionConnections(@NotNull HttpServletRequest request, @NotNull HttpServletResponse response) throws DBWebException;

    @WebAction(configurationModeAllowed = true)
    boolean changeSessionLanguage(@NotNull WebSession webSession, @Nullable String locale) throws DBWebException;

    ///////////////////////////////////////////
    // Connections
    @NotNull
    WebPropertyInfo[] getDriverProperties(
        @NotNull WebSession webSession,
        @NotNull String projectId,
        @NotNull Map<String, Object> connectionConfig
    ) throws DBWebException;

    @NotNull
    List<DBPConnectionType> getConnectionTypes(@NotNull WebSession webSession, @Nullable String id);

    @WebAction
    WebConnectionInfo getConnectionState(WebSession webSession, @Nullable String projectId, String connectionId) throws DBWebException;

    @WebAction
    WebConnectionInfo initConnection(
        @NotNull WebSession webSession,
        @Nullable String projectId,
        @NotNull String connectionId,
        @WebParameterSecure @Nullable Map<String, Object> authProperties,
        @Nullable List<WebNetworkHandlerConfigInput> networkCredentials,
        boolean saveCredentials,
        boolean sharedCredentials,
        @Nullable String selectedCredentials
    ) throws DBWebException;

    @WebProjectAction(requireProjectPermissions = {RMConstants.PERMISSION_PROJECT_DATASOURCES_EDIT})
    WebConnectionInfo createConnection(
        @NotNull WebSession webSession,
        @Nullable @WebObjectId String projectId,
        @WebParameterSecure @NotNull Map<String, Object> connectionConfig
    ) throws DBWebException;

    @WebProjectAction(requireProjectPermissions = {RMConstants.PERMISSION_PROJECT_DATASOURCES_EDIT})
    WebConnectionInfo updateConnection(
        @NotNull WebSession webSession,
        @Nullable @WebObjectId String projectId,
        @NotNull Map<String, Object> connectionConfig
    ) throws DBWebException;

    @WebProjectAction(requireProjectPermissions = {RMConstants.PERMISSION_PROJECT_DATASOURCES_EDIT})
    boolean deleteConnection(
        @NotNull WebSession webSession,
        @Nullable @WebObjectId String projectId,
        @NotNull String connectionId
    ) throws DBWebException;

    @WebProjectAction(requireProjectPermissions = {RMConstants.PERMISSION_PROJECT_DATASOURCES_EDIT})
    WebConnectionInfo copyConnectionFromNode(
        @NotNull WebSession webSession,
        @Nullable @WebObjectId String projectId,
        @NotNull String nodePath,
        @NotNull Map<String, Object> connectionConfig
    ) throws DBWebException;

    @WebProjectAction(requireProjectPermissions = {RMConstants.PERMISSION_PROJECT_DATASOURCES_EDIT})
    WebConnectionInfo testConnection(
        @NotNull WebSession webSession,
        @Nullable @WebObjectId String projectId,
        @NotNull Map<String, Object> connectionConfig
    ) throws DBWebException;

    @WebProjectAction(requireProjectPermissions = {RMConstants.PERMISSION_PROJECT_DATASOURCES_EDIT})
    boolean changeConnectionUserPassword(
        @NotNull WebSession webSession,
        @Nullable @WebObjectId String projectId,
        @NotNull String connectionId,
        @WebParameterSecure @NotNull String oldPassword,
        @WebParameterSecure @NotNull String newPassword
    ) throws DBWebException;

    @WebProjectAction(requireProjectPermissions = {RMConstants.PERMISSION_PROJECT_DATASOURCES_EDIT})
    WebNetworkEndpointInfo testNetworkHandler(
        @NotNull WebSession webSession,
        @Nullable @WebObjectId String projectId,
        @Nullable String connectionId,
        @NotNull WebNetworkHandlerConfigInput nhConfig
    ) throws DBWebException;

    @WebAction
    WebConnectionInfo closeConnection(@NotNull WebSession webSession, @Nullable String projectId, @NotNull String connectionId) throws DBWebException;

    ///////////////////////////////////////////
    // Projects

    @WebAction
    List<WebProjectInfo> getProjects(@NotNull WebSession session);

    ///////////////////////////////////////////
    // Folders

    @WebProjectAction(requireProjectPermissions = {RMConstants.PERMISSION_PROJECT_DATASOURCES_EDIT})
    WebConnectionFolderInfo createConnectionFolder(
        @NotNull WebSession session,
        @Nullable @WebObjectId String projectId,
        @Nullable String parentNodePath,
        @NotNull String newName) throws DBWebException;

    @WebProjectAction(requireProjectPermissions = {RMConstants.PERMISSION_PROJECT_DATASOURCES_EDIT})
    WebConnectionFolderInfo renameConnectionFolder(
        @NotNull WebSession session,
        @Nullable @WebObjectId
        String projectId,
        @NotNull String folderPath,
        @NotNull String newName) throws DBWebException;

    @WebProjectAction(requireProjectPermissions = {RMConstants.PERMISSION_PROJECT_DATASOURCES_EDIT})
    boolean deleteConnectionFolder(
        @NotNull WebSession session,
        @Nullable @WebObjectId String projectId,
        @NotNull String nodePath) throws DBWebException;

    ///////////////////////////////////////////
    // Navigator settings

    @WebAction
    WebConnectionInfo setConnectionNavigatorSettings(
        @NotNull WebSession webSession,
        @Nullable String projectId,
        @NotNull String id,
        @NotNull DataSourceNavigatorSettings settings
    ) throws DBWebException;

    @WebAction
    WebConnectionInfo clearConnectionNavigatorSettings(
        @NotNull WebSession webSession,
        @NotNull String projectId,
        @NotNull String id
    ) throws DBWebException;

    @NotNull
    Map<String, String> setObjectSettingsForDatasource(
        @NotNull WebSession webSession,
        @NotNull String projectId,
        @NotNull String objectId,
        @NotNull Map<String, String> settings
    ) throws DBException;

    ///////////////////////////////////////////
    // Async tasks

    @NotNull
    @WebAction(authRequired = false, configurationModeAllowed = true)
    WebAsyncTaskInfo getAsyncTaskInfo(
        @NotNull WebSession webSession,
        @NotNull String taskId,
        @Nullable Boolean removeOnFinish
    ) throws DBWebException;

    @WebAction(authRequired = false, configurationModeAllowed = true)
    boolean cancelAsyncTask(@NotNull WebSession webSession, @NotNull String taskId) throws DBWebException;

}
