/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.service.sql;

import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.model.data.DBDAttributeConstraint;
import org.jkiss.dbeaver.model.data.DBDDataFilter;
import org.jkiss.dbeaver.model.exec.DBCLogicalOperator;
import org.jkiss.dbeaver.model.runtime.DBRProgressMonitor;
import org.jkiss.dbeaver.model.struct.DBSAttributeBase;
import org.jkiss.utils.CommonUtils;

import java.text.MessageFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Web SQL data filter.
 */
public class WebSQLDataFilter {

    private static final int DEFAULT_ROWS_NUMBER = 200;
    private static final int MAX_ROWS_NUMBER = 100000;


    private int offset;
    private int limit;
    private String where;
    private boolean anyConstraint;
    private boolean shouldUseDisjunctive;
    private final List<WebSQLDataFilterConstraint> constraints = new ArrayList<>();

    public WebSQLDataFilter() {
        this.offset = 0;
        this.limit = DEFAULT_ROWS_NUMBER;
    }

    public WebSQLDataFilter(@NotNull Map<String, Object> filterProps) {
        this.offset = CommonUtils.toInt(filterProps.get("offset"));
        this.limit = CommonUtils.toInt(filterProps.get("limit"));
        if (this.limit <= 0) {
            this.limit = DEFAULT_ROWS_NUMBER;
        } else if (this.limit > MAX_ROWS_NUMBER) {
            this.limit = MAX_ROWS_NUMBER;
        }
        this.where = CommonUtils.toString(filterProps.get("where"), null);
        this.anyConstraint = CommonUtils.toBoolean(filterProps.get("anyConstraint"));
        this.shouldUseDisjunctive = CommonUtils.toBoolean(filterProps.get("shouldUseDisjunctive"));
        Object constraints = filterProps.get("constraints");
        if (constraints instanceof Collection<?> col) {
            for (Object constrItem : col) {
                if (constrItem instanceof Map) {
                    this.constraints.add(
                        new WebSQLDataFilterConstraint((Map<String, Object>) constrItem));
                }
            }
        }
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public List<WebSQLDataFilterConstraint> getConstraints() {
        return constraints;
    }

    public String getWhere() {
        return where;
    }

    /**
     * When true constraints are combined with OR instead of AND
     */
    public boolean isAnyConstraint() {
        return anyConstraint;
    }

    @NotNull
    public static WebSQLDataFilter from(@NotNull DBDDataFilter filter) {
        var webFilter = new WebSQLDataFilter();
        webFilter.where = filter.getWhere();
        webFilter.anyConstraint = filter.isAnyConstraint();
        webFilter.shouldUseDisjunctive = filter.isUseDisjunctiveNormalForm();
        for (DBDAttributeConstraint constraint : filter.getConstraints()) {
            webFilter.constraints.add(WebSQLDataFilterConstraint.from(constraint));
        }
        return webFilter;
    }

    @NotNull
    public DBDDataFilter makeDataFilter(
        @NotNull DBRProgressMonitor monitor,
        @Nullable WebSQLResultsInfo resultInfo
    ) throws DBException {
        DBDDataFilter dataFilter = new DBDDataFilter();
        dataFilter.setWhere(where);
        dataFilter.setAnyConstraint(anyConstraint);
        dataFilter.setUseDisjunctiveNormalForm(shouldUseDisjunctive);
        if (CommonUtils.isEmpty(constraints)) {
            return dataFilter;
        }
        dataFilter.addConstraints(mapWebConstrainsToDbdConstrains(monitor, resultInfo));
        return dataFilter;
    }


    @NotNull
    private List<DBDAttributeConstraint> mapWebConstrainsToDbdConstrains(
        @NotNull DBRProgressMonitor monitor,
        @Nullable WebSQLResultsInfo resultInfo
    ) throws DBException {
        if (resultInfo == null) {
            return getDbdConstraints();
        }
        List<DBDAttributeConstraint> constraints = generateEmptyConstrains(resultInfo);
        fillEmptyConstrains(constraints);
        WebSQLUtils.convertConstraintValues(monitor, resultInfo, constraints);
        return constraints;
    }

    @NotNull
    public List<DBDAttributeConstraint> generateEmptyConstrains(@Nullable WebSQLResultsInfo resultInfo) {
        if (resultInfo == null) {
            return Collections.emptyList();
        }

        List<? extends DBSAttributeBase> result = Arrays.asList(resultInfo.getAttributes());
        return result.stream()
            .filter(attribute -> attribute.getOrdinalPosition() >= 0)
            .map(attribute -> new DBDAttributeConstraint(attribute, -1))
            .collect(Collectors.toList());
    }

    private void fillEmptyConstrains(@NotNull List<DBDAttributeConstraint> emptyConstraints) throws DBException {
        for (WebSQLDataFilterConstraint webConstr : constraints) {
            DBDAttributeConstraint dbConstr = findConstraintToFill(emptyConstraints, webConstr);
            if (dbConstr.hasCondition()) {
                // The attribute already has a condition from a previous constraint
                dbConstr = new DBDAttributeConstraint(dbConstr);
                dbConstr.reset();
                emptyConstraints.add(dbConstr);
            }
            fillEmptyConstraint(dbConstr, webConstr);
        }
    }

    @NotNull
    private DBDAttributeConstraint findConstraintToFill(
        @NotNull List<DBDAttributeConstraint> emptyConstraints,
        @NotNull WebSQLDataFilterConstraint webConstr
    ) throws DBException {
        Integer attributePosition = webConstr.getAttributePosition();
        if (attributePosition != null) {
            if (attributePosition < 0 || attributePosition >= emptyConstraints.size()) {
                throw new DBException(MessageFormat.format("Incorrect column position ''{0}'' in order clause", attributePosition));
            }
            return emptyConstraints.get(attributePosition);
        }
        // try by attribute name
        String attributeName = webConstr.getAttributeName();
        if (!CommonUtils.isEmpty(attributeName)) {
            for (DBDAttributeConstraint dbConstr : emptyConstraints) {
                if (CommonUtils.equalObjects(dbConstr.getAttributeName(), attributeName)) {
                    return dbConstr;
                }
            }
            throw new DBException(MessageFormat.format("Constraint attribute ''{0}'' not found in result set", attributeName));
        }
        throw new DBException("Constraint must specify either attributePosition or attributeName");
    }

    @NotNull
    private DBDAttributeConstraint fillEmptyConstraint(@NotNull DBDAttributeConstraint dbConstr,
                                                       @NotNull WebSQLDataFilterConstraint webConstr) {
        dbConstr.setPlainNameReference(true);

        if (webConstr.getOrderPosition() != null) {
            dbConstr.setOrderPosition(webConstr.getOrderPosition());
        }
        if (webConstr.getOrderAsc() != null) {
            dbConstr.setOrderDescending(!webConstr.getOrderAsc());
        }
        dbConstr.setCriteria(webConstr.getCriteria());
        if (webConstr.getOperator() != null) {
            dbConstr.setOperator(CommonUtils.valueOf(DBCLogicalOperator.class, webConstr.getOperator()));
        }
        if (webConstr.getValue() != null) {
            dbConstr.setValue(webConstr.getValue());
        }
        return dbConstr;
    }

    @NotNull
    private List<DBDAttributeConstraint> getDbdConstraints() {
        List<DBDAttributeConstraint> dbConstraints = new ArrayList<>();
        for (WebSQLDataFilterConstraint constraint : constraints) {
            String attributeName = constraint.getAttributeName();
            DBDAttributeConstraint dbConstraint = new DBDAttributeConstraint(
                attributeName, getOriginalVisualPosition(constraint, attributeName)
            );

            fillEmptyConstraint(dbConstraint, constraint);
            dbConstraints.add(dbConstraint);
        }
        return dbConstraints;
    }

    private static int getOriginalVisualPosition(
        @NotNull WebSQLDataFilterConstraint constraint,
        @NotNull String attributeName
    ) {
        Integer attributePosition = constraint.getAttributePosition();

        if (CommonUtils.isEmpty(attributeName)) {
            if (attributePosition == null) {
                throw new IllegalArgumentException("Constraint must specify either attributePosition or attributeName");
            }
            throw new IllegalArgumentException(
                "Can't convert constraint by attributePosition without result set metadata (attributeName is required)"
            );
        }

        return attributePosition == null ? -1 : attributePosition;
    }
}
