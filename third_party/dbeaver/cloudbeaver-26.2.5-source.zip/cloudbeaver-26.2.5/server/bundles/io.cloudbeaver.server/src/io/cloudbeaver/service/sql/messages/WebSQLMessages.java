/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2025 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.service.sql.messages;

import org.eclipse.osgi.util.NLS;

public class WebSQLMessages extends NLS {
    static final String BUNDLE_NAME = "io.cloudbeaver.service.sql.messages.WebSQLResources"; //$NON-NLS-1$

    // TODO: add localizations
    public static String model_web_ai_query_confirmation_title;
    public static String model_web_ai_query_confirmation_message;
    public static String model_web_dialog_sql_param_title;

    static {
        NLS.initializeMessages(BUNDLE_NAME, WebSQLMessages.class);
    }

    private WebSQLMessages() {
    }

}
