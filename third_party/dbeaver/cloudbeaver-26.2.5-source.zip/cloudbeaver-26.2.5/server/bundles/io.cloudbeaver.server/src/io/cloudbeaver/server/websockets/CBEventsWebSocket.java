/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.server.websockets;

import io.cloudbeaver.model.session.BaseWebSession;
import io.cloudbeaver.websocket.CBWebSessionEventHandler;
import jakarta.websocket.*;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.websocket.event.WSEvent;
import org.jkiss.dbeaver.model.websocket.event.session.WSAccessTokenExpiredEvent;
import org.jkiss.dbeaver.model.websocket.event.session.WSSocketConnectedEvent;

import java.time.Duration;

public class CBEventsWebSocket extends CBAbstractWebSocket implements CBWebSessionEventHandler {
    private static final Log log = Log.getLog(CBEventsWebSocket.class);

    @Nullable
    private volatile BaseWebSession webSession;
    @Nullable
    private FromUserEventHandler eventProcessor;
    @Nullable
    private WebSocketPingPongCallback pingPongCallback;

    @Override
    public void onOpen(Session session, EndpointConfig config) {
        super.onOpen(session, config);
        if (session.getUserProperties().containsKey(CBWebSocketServerConfigurator.PROP_TOKEN_EXPIRED)) {
            handleEvent(new WSAccessTokenExpiredEvent());
            close();
        } else {
            this.webSession = (BaseWebSession) session.getUserProperties()
                .get(CBWebSocketServerConfigurator.PROP_WEB_SESSION);
            if (this.webSession == null) {
                log.debug("No web session for websocket connection, closing");
                close();
                return;
            }
            this.webSession.addEventHandler(this);
            handleEvent(new WSSocketConnectedEvent(webSession.getApplication().getApplicationRunId()));
            log.debug("EventWebSocket connected to the " + webSession.getSessionId() + " session");

            session.setMaxIdleTimeout(Duration.ofMinutes(5).toMillis());
            this.eventProcessor = new FromUserEventHandler(webSession);
            session.addMessageHandler(String.class, eventProcessor);
            this.pingPongCallback = new WebSocketPingPongCallback(webSession);
            session.addMessageHandler(PongMessage.class, pingPongCallback);

            CBJettyWebSocketManager.registerWebSocket(webSession.getSessionId(), this);
        }
    }

    @Override
    public void migrateToSession(@NotNull BaseWebSession newSession) {
        BaseWebSession oldSession = this.webSession;
        this.webSession = newSession;
        if (eventProcessor != null) {
            eventProcessor.setWebSession(newSession);
        }
        if (pingPongCallback != null) {
            pingPongCallback.setWebSession(newSession);
        }
        if (oldSession != null) {
            CBJettyWebSocketManager.migrateWebSocket(oldSession.getSessionId(), newSession.getSessionId(), this);
        }
        log.debug("EventWebSocket migrated to the " + newSession.getSessionId() + " session");
    }

    private static class FromUserEventHandler extends CBClientEventProcessor implements MessageHandler.Whole<String> {

        private FromUserEventHandler(@NotNull BaseWebSession webSession) {
            super(webSession);
        }

        @Override
        public void onMessage(@Nullable String message) {
            process(message);
        }
    }

    @Override
    public void onClose(Session session, CloseReason closeReason) {
        super.onClose(session, closeReason);
        log.debug("Socket Closed: [" + closeReason.getCloseCode() + "] " + closeReason.getReasonPhrase());
        if (webSession != null) {
            this.webSession.removeEventHandler(this);
        }
    }

    @Override
    public void handleWebSessionEvent(WSEvent event) {
        super.handleEvent(event);
    }

    @Override
    public void onError(Session session, Throwable thr) {
        if (webSession != null) {
            webSession.addSessionError(thr);
        }
        log.trace("Error in websocket session: " + thr.getMessage(), thr);
    }

    @Override
    protected void handleEventException(Throwable e) {
        super.handleEventException(e);
        if (webSession != null) {
            webSession.addSessionError(e);
        }
    }
}
