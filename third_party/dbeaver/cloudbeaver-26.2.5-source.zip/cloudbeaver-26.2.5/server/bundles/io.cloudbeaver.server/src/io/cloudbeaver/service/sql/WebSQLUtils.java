/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.service.sql;

import io.cloudbeaver.DBWebException;
import io.cloudbeaver.model.WebAsyncTaskInfo;
import io.cloudbeaver.model.app.ServletAppConfiguration;
import io.cloudbeaver.model.session.WebAsyncTaskProcessor;
import io.cloudbeaver.model.session.WebSession;
import io.cloudbeaver.registry.WebServiceRegistry;
import io.cloudbeaver.utils.CBModelConstants;
import io.cloudbeaver.utils.ServletAppUtils;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.DBPDataKind;
import org.jkiss.dbeaver.model.DBPEvaluationContext;
import org.jkiss.dbeaver.model.DBUtils;
import org.jkiss.dbeaver.model.data.*;
import org.jkiss.dbeaver.model.exec.DBCException;
import org.jkiss.dbeaver.model.exec.DBCExecutionContext;
import org.jkiss.dbeaver.model.exec.DBCExecutionPurpose;
import org.jkiss.dbeaver.model.exec.DBCSession;
import org.jkiss.dbeaver.model.gis.DBGeometry;
import org.jkiss.dbeaver.model.gis.GisConstants;
import org.jkiss.dbeaver.model.gis.GisTransformUtils;
import org.jkiss.dbeaver.model.runtime.DBRProgressMonitor;
import org.jkiss.dbeaver.model.struct.*;
import org.jkiss.dbeaver.model.websocket.event.WSEvent;
import org.jkiss.dbeaver.utils.ContentUtils;
import org.jkiss.dbeaver.utils.GeneralUtils;
import org.jkiss.utils.Base64;
import org.jkiss.utils.CommonUtils;

import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;

/**
 * Web SQL utils.
 */
public class WebSQLUtils {

    private static final Log log = Log.getLog(WebSQLUtils.class);

    public static Object makeWebCellValue(WebSession session, DBSTypedObject type, Object cellValue, WebDataFormat dataFormat) throws DBCException {
        if (type instanceof DBDAttributeBinding &&
            (cellValue instanceof Date || cellValue instanceof Number)) {
            if (cellValue instanceof BigDecimal) {
                cellValue = ((BigDecimal) cellValue).stripTrailingZeros();
            }
            return ((DBDAttributeBinding) type).getValueHandler().getValueDisplayString(type, cellValue, DBDDisplayFormat.EDIT);
        }

        if (cellValue instanceof Boolean) {
            return cellValue;
        }
        if (cellValue instanceof Date) {
            return CBModelConstants.ISO_DATE_FORMAT.format(((Date) cellValue).toInstant());
        } else if (cellValue instanceof Number) {
            if (cellValue instanceof Double) {
                return CommonUtils.niceFormatDouble((Double) cellValue);
            } else if (cellValue instanceof Float) {
                return CommonUtils.niceFormatDouble((Float) cellValue);
            } else if (cellValue instanceof BigDecimal) {
                return ((BigDecimal) cellValue).toPlainString();
            }
            return cellValue.toString();
        }
        if (cellValue instanceof DBDValue) {
            DBDValue dbValue = (DBDValue) cellValue;
            if (dbValue.isNull()) {
                return null;
            }
            else if (dbValue instanceof DBDDocument) {
                return serializeDocumentValue(session, (DBDDocument) dbValue);
            } else if (dbValue instanceof DBDComplexValue) {
                return serializeComplexValue(session, type, (DBDComplexValue)dbValue, dataFormat);
            } else if (dbValue instanceof DBGeometry) {
                return serializeGeometryValue((DBGeometry)dbValue);
            } else if (dbValue instanceof DBDContent) {
                return serializeContentValue(session, (DBDContent)dbValue);
            }
        }
        return cellValue == null ? null : serializeStringValue(cellValue);
    }

    private static Object serializeComplexValue(WebSession session, DBSTypedObject type, DBDComplexValue value, WebDataFormat dataFormat) throws DBCException {
        if (value instanceof DBDCollection) {
            if (type instanceof DBDAttributeBinding) {
                DBDValueHandler valueHandler = ((DBDAttributeBinding) type).getValueHandler();
                return valueHandler.getValueDisplayString(type, value, DBDDisplayFormat.EDIT);
            }
            DBDCollection collection = (DBDCollection) value;
            int size = collection.getItemCount();
            Object[] items = new Object[size];
            for (int i = 0; i < size; i++) {
                items[i] = makeWebCellValue(session, collection.getComponentType(), collection.getItem(i), dataFormat);
            }

            Map<String, Object> map = createMapOfType(WebSQLConstants.VALUE_TYPE_COLLECTION);
            map.put("value", items);
            return map;
        } else if (value instanceof DBDComposite composite && composite.getAttributes().length > 0) {
            Map<String, Object> struct = new LinkedHashMap<>();
            for (DBSAttributeBase attr : composite.getAttributes()) {
                struct.put(attr.getName(), makeWebCellValue(session, attr, composite.getAttributeValue(attr), dataFormat));
            }

            Map<String, Object> map = createMapOfType(WebSQLConstants.VALUE_TYPE_MAP);
            map.put("value", struct);
            return map;
        }
        return value.toString();
    }

    @NotNull
    private static Map<String, Object> createMapOfType(String type) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put(WebSQLConstants.VALUE_TYPE_ATTR, type);
        return map;
    }

    private static Map<String, Object> serializeDocumentValue(WebSession session, DBDDocument document) throws DBCException {
        String documentData;
        try {
            StringWriter writer = new StringWriter();
            document.serializeDocument(session.getProgressMonitor(), writer);
            documentData = writer.toString();
        } catch (Exception e) {
            throw new DBCException("Error serializing document", e);
        }

        Map<String, Object> map = createMapOfType(WebSQLConstants.VALUE_TYPE_DOCUMENT);
        map.put("id", CommonUtils.toString(document.getDocumentId()));
        map.put("contentType", document.getDocumentContentType());
        map.put("properties", Collections.emptyMap());
        map.put(WebSQLConstants.ATTR_DATA, documentData);
        return map;
    }

    private static Object serializeContentValue(WebSession session, DBDContent value) throws DBCException {

        Map<String, Object> map = createMapOfType(WebSQLConstants.VALUE_TYPE_CONTENT);
        if (ContentUtils.isTextContent(value)) {
            String stringValue = ContentUtils.getContentStringValue(session.getProgressMonitor(), value);
            int textPreviewMaxLength = CommonUtils.toInt(
                ServletAppUtils.getServletApplication()
                    .getAppConfiguration()
                    .getResourceQuota(WebSQLConstants.QUOTA_PROP_TEXT_PREVIEW_MAX_LENGTH),
                WebSQLConstants.TEXT_PREVIEW_MAX_LENGTH
            );
            if (stringValue != null && stringValue.length() > textPreviewMaxLength) {
                stringValue =  stringValue.substring(0, textPreviewMaxLength);
            }
            map.put(WebSQLConstants.ATTR_TEXT, stringValue);
        } else {
            map.put(WebSQLConstants.ATTR_BINARY, true);
            byte[] binaryValue = ContentUtils.getContentBinaryValue(session.getProgressMonitor(), value);
            if (binaryValue != null) {
                byte[] previewValue = binaryValue;
                // gets parameters from the configuration file
                ServletAppConfiguration config = ServletAppUtils.getServletApplication().getAppConfiguration();
                // the max length of the text preview
                int textPreviewMaxLength = CommonUtils.toInt(
                    config.getResourceQuota(
                        WebSQLConstants.QUOTA_PROP_TEXT_PREVIEW_MAX_LENGTH), WebSQLConstants.TEXT_PREVIEW_MAX_LENGTH);
                if (previewValue.length > textPreviewMaxLength) {
                    previewValue = Arrays.copyOf(previewValue, textPreviewMaxLength);
                }
                map.put(WebSQLConstants.ATTR_TEXT, GeneralUtils.convertToString(previewValue, 0, previewValue.length));
                // the max length of the binary preview
                int binaryPreviewMaxLength = CommonUtils.toInt(
                    config.getResourceQuota(
                        WebSQLConstants.QUOTA_PROP_BINARY_PREVIEW_MAX_LENGTH),
                    WebSQLConstants.BINARY_PREVIEW_MAX_LENGTH);
                byte[] inlineValue = binaryValue;
                if (inlineValue.length > binaryPreviewMaxLength) {
                    inlineValue = Arrays.copyOf(inlineValue, textPreviewMaxLength);
                }
                map.put(WebSQLConstants.ATTR_BINARY, Base64.encode(inlineValue));
            } else {
                map.put(WebSQLConstants.ATTR_TEXT, null);
            }
        }
        map.put("contentType", value.getContentType());
        map.put("contentLength", value.getContentLength());
        return map;
    }

    private static Object serializeGeometryValue(DBGeometry value) {
        Map<String, Object> map = createMapOfType(WebSQLConstants.VALUE_TYPE_GEOMETRY);
        map.put("srid", value.getSRID());
        map.put(WebSQLConstants.ATTR_TEXT, value.toString());
        map.put("properties", value.getProperties());

        DBGeometry xValue = GisTransformUtils.transformToSRID(value, GisConstants.SRID_4326);
        if (xValue != null && xValue != value) {
            map.put("mapText", xValue.toString());
        }
        return map;
    }

    /**
     * Serializes original value from db to web form
     *
     * @param value original value
     * @return web form value
     */
    public static Object serializeStringValue(Object value) {
        int textPreviewMaxLength = CommonUtils.toInt(
            ServletAppUtils.getServletApplication()
                .getAppConfiguration()
                .getResourceQuota(WebSQLConstants.QUOTA_PROP_TEXT_PREVIEW_MAX_LENGTH),
            WebSQLConstants.TEXT_PREVIEW_MAX_LENGTH
        );
        String stringValue = value.toString();
        if (stringValue.length() < textPreviewMaxLength) {
            return value.toString();
        }
        Map<String, Object> map = createMapOfType(WebSQLConstants.VALUE_TYPE_CONTENT);
        map.put(WebSQLConstants.ATTR_TEXT, stringValue.substring(0, textPreviewMaxLength));
        map.put("contentLength", GeneralUtils.convertToBytes(stringValue).length);
        return map;
    }

    public static Object makePlainCellValue(DBCSession session, DBSTypedObject attribute, Object value) throws DBCException {
        if (value instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) value;
            Object typeAttr = map.get(WebSQLConstants.VALUE_TYPE_ATTR);
            if (typeAttr instanceof String) {
                switch ((String)typeAttr) {
                    case WebSQLConstants.VALUE_TYPE_CONTENT: {
                        if (map.get(WebSQLConstants.ATTR_BINARY) != null) {
                            throw new DBCException("Binary content edit is not supported yet");
                        }
                        value = map.get(WebSQLConstants.ATTR_TEXT);
                        break;
                    }
                    default: {
                        DBWValueSerializer<?> valueSerializer = WebServiceRegistry.getInstance().createValueSerializer((String) typeAttr);
                        if (valueSerializer == null) {
                            throw new DBCException("Value type '" + typeAttr + "' edit is not supported yet");
                        }
                        value = valueSerializer.deserializeValue(session, attribute, map);
                    }
                }
            }
        }
        return value;
    }


    /**
     * Need to convert string values in constraints to real values using value handlers
     */
    public static void convertConstraintValues(
        @NotNull DBRProgressMonitor monitor,
        @NotNull WebSQLResultsInfo resultInfo,
        @NotNull List<DBDAttributeConstraint> constraints
    ) {
        DBCExecutionContext executionContext = DBUtils.getDefaultContext(resultInfo.getDataContainer(), false);
        if (executionContext == null || !executionContext.isConnected()) {
            return;
        }
        DBCSession session = null;
        try {
            for (DBDAttributeConstraint constraint : constraints) {
                Object constraintValue = constraint.getValue();
                if (!(constraintValue instanceof String || constraintValue instanceof Object[]) ||
                    !(constraint.getAttribute() instanceof DBDAttributeBinding binding)) {
                    continue;
                }
                if (session == null) {
                    session = executionContext.openSession(monitor, DBCExecutionPurpose.UTIL, "Convert filter values");
                }
                Object[] values = constraintValue instanceof Object[] array ? array : new Object[] { constraintValue };
                for (int i = 0; i < values.length; i++) {
                    if (!(values[i] instanceof String strValue)) {
                        continue;
                    }
                    try {
                        Object value = binding.getValueHandler().getValueFromObject(session, binding, strValue, false, false);
                        if (value != null) {
                            if (constraintValue instanceof String) {
                                constraint.setValue(value);
                            } else {
                                values[i] = value;
                            }
                        }
                    } catch (Exception e) {
                        log.debug("Can't convert filter value '" + strValue + "' for attribute '" + binding.getName() + "'", e);
                    }
                }
            }
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }

    /**
     * Returns fully qualified name for a column.
     */
    @NotNull
    public static String getColumnName(@NotNull DBDAttributeBinding binding) {
        return binding.getFullyQualifiedName(DBPEvaluationContext.UI);
    }

    @NotNull
    public static Map<String, Object> makeDocumentValueMap(
        @NotNull DBDAttributeBinding documentAttribute,
        @NotNull DBDAttributeBinding[] attributes,
        @NotNull Object[] values
    ) {
        if (attributes.length != values.length) {
            throw new IllegalArgumentException("Document attributes and values have different sizes");
        }
        Map<String, Object> document = new LinkedHashMap<>();
        for (int i = 0; i < attributes.length; i++) {
            putDocumentValue(document, documentAttribute, attributes[i], values[i]);
        }
        return document;
    }

    private static void putDocumentValue(
        @NotNull Map<String, Object> document,
        @NotNull DBDAttributeBinding documentAttribute,
        @NotNull DBDAttributeBinding attribute,
        @Nullable Object value
    ) {
        LinkedList<String> path = new LinkedList<>();
        for (DBDAttributeBinding current = attribute; current != null && current != documentAttribute;
             current = current.getParentObject()) {
            path.addFirst(current.getName());
        }
        if (path.isEmpty() || attribute.getTopParent() != documentAttribute) {
            return;
        }
        Map<String, Object> target = document;
        while (path.size() > 1) {
            String name = path.removeFirst();
            Object nestedValue = target.get(name);
            if (nestedValue instanceof Map<?, ?> nestedMap) {
                @SuppressWarnings("unchecked")
                Map<String, Object> typedNestedMap = (Map<String, Object>) nestedMap;
                target = typedNestedMap;
            } else if (nestedValue != null) {
                throw new IllegalArgumentException("Conflicting document attribute path at '" + name + "'");
            } else {
                Map<String, Object> nestedMap = new LinkedHashMap<>();
                target.put(name, nestedMap);
                target = nestedMap;
            }
        }
        String name = path.getFirst();
        if (target.containsKey(name)) {
            throw new IllegalArgumentException("Duplicate document attribute path at '" + name + "'");
        }
        target.put(name, value);
    }

    @NotNull
    public static WebAsyncTaskInfo createAsyncTaskExecuteSqlQuery(
        @NotNull WebSession webSession,
        @NotNull WebSQLContextInfo contextInfo,
        @NotNull String sql,
        @Nullable String resultId,
        @Nullable WebSQLDataFilter filter,
        @Nullable WebDataFormat dataFormat,
        boolean readLogs,
        boolean useEvents
    ) {
        final WebAsyncTaskInfo task = webSession.createAsyncTask("SQL execute");
        WebAsyncTaskProcessor<String> runnable = new WebAsyncTaskProcessor<>() {
            @Override
            public void run(DBRProgressMonitor monitor) throws InvocationTargetException {
                try {
                    monitor.beginTask("Execute query", 1);
                    monitor.subTask("Process query " + sql);
                    WebSQLExecuteInfo executeResults = contextInfo.getProcessor().processQuery(
                        monitor, contextInfo, sql, resultId, filter, dataFormat, webSession, task, readLogs, useEvents
                    );
                    this.result = executeResults.getStatusMessage();
                    this.extendedResults = executeResults;
                } catch (Throwable e) {
                    throw new InvocationTargetException(e);
                } finally {
                    monitor.done();
                }
            }
        };
        return webSession.runAsyncTask(task, runnable);
    }

    @Nullable
    public static <T> T requestConfirmation(
        @NotNull WebSession webSession,
        @NotNull WebAsyncTaskInfo asyncTask,
        @NotNull WSEvent confirmationEvent,
        @NotNull CompletableFuture<T> confirmationFuture
    ) throws DBWebException {
        String attributeName = WebSQLConstants.TASK_CONFIRMATION_ATTR_PREFIX + asyncTask.getId();
        webSession.setAttribute(attributeName, confirmationFuture);

        webSession.addSessionEvent(confirmationEvent);

        try {
            return confirmationFuture.get(WebSQLConstants.TASK_CONFIRMATION_TIMEOUT_SECONDS, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            throw new DBWebException("Query confirmation timeout");
        } catch (Exception e) {
            throw new DBWebException("Error when processing confirmation response", e);
        } finally {
            webSession.removeAttribute(attributeName);
        }
    }

    @NotNull
    public static List<WebSQLQueryResultAssociation> collectAssociations(
        @NotNull WebSession session,
        @NotNull DBDAttributeBinding[] bindings
    ) {
        return collectWebSQLQueryResultAssociation(session, bindings, false);
    }

    @NotNull
    public static List<WebSQLQueryResultAssociation> collectReferences(
        @NotNull WebSession session,
        @NotNull DBDAttributeBinding[] bindings
    ) {
        return collectWebSQLQueryResultAssociation(session, bindings, true);
    }

    @NotNull
    private static List<WebSQLQueryResultAssociation> collectWebSQLQueryResultAssociation(
        @NotNull WebSession session,
        @NotNull DBDAttributeBinding[] bindings,
        boolean reverse
    ) {
        Map<DBSEntityAttribute, Integer> attrToIndex = new HashMap<>();
        Set<DBSEntity> entities = new LinkedHashSet<>();
        for (int i = 0; i < bindings.length; i++) {
            DBSEntityAttribute ea = bindings[i].getEntityAttribute();
            if (ea == null) {
                continue;
            }
            attrToIndex.putIfAbsent(ea, i);
            DBSEntity parent = ea.getParentObject();
            entities.add(parent);
        }

        Function<DBSEntityAttribute, DBDAttributeBinding> attrToBinding = attr -> {
            Integer idx = attrToIndex.get(attr);
            return idx == null ? null : bindings[idx];
        };

        List<WebSQLQueryResultAssociation> result = new ArrayList<>();
        DBRProgressMonitor monitor = session.getProgressMonitor();
        for (DBSEntity entity : entities) {
            try {
                List<DBSEntityAssociation> source = reverse
                    ? DBStructUtils.readReferences(monitor, entity, attrToBinding)
                    : DBStructUtils.readAssociations(monitor, entity, attrToBinding);
                for (DBSEntityAssociation association : source) {
                    List<WebSQLReferenceColumnMapping> mapping = collectColumnMapping(monitor, association, reverse, attrToIndex);
                    if (mapping != null) {
                        result.add(new WebSQLQueryResultAssociation(session, association, reverse, mapping));
                    }
                }
            } catch (DBException e) {
                log.debug("Error collecting references for entity " + entity.getName(), e);
            }
        }
        return result;
    }

    /**
     * Pairs source-side attributes (in our result set) with target-side attributes
     */
    @Nullable
    private static List<WebSQLReferenceColumnMapping> collectColumnMapping(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBSEntityAssociation association,
        boolean reverse,
        @NotNull Map<DBSEntityAttribute, Integer> attrToIndex
    ) throws DBException {
        if (!(association instanceof DBSEntityReferrer associationReferrer)) {
            return null;
        }
        DBSEntityConstraint refConstraint = association.getReferencedConstraint();
        if (!(refConstraint instanceof DBSEntityReferrer constraintReferrer)) {
            return null;
        }
        DBSEntityReferrer sourceSide = reverse ? constraintReferrer : associationReferrer;
        DBSEntityReferrer targetSide = reverse ? associationReferrer : constraintReferrer;

        List<? extends DBSEntityAttributeRef> sourceAttrs = sourceSide.getAttributeReferences(monitor);
        List<? extends DBSEntityAttributeRef> targetAttrs = targetSide.getAttributeReferences(monitor);
        if (sourceAttrs == null || targetAttrs == null
            || sourceAttrs.isEmpty() || sourceAttrs.size() != targetAttrs.size()
        ) {
            return null;
        }
        List<WebSQLReferenceColumnMapping> mapping = new ArrayList<>(sourceAttrs.size());
        for (int i = 0; i < sourceAttrs.size(); i++) {
            DBSEntityAttribute sourceAttr = sourceAttrs.get(i).getAttribute();
            Integer sourceIdx = sourceAttr == null ? null : attrToIndex.get(sourceAttr);
            if (sourceIdx == null) {
                return null;
            }
            DBSEntityAttribute targetAttr = targetAttrs.get(i).getAttribute();
            if (targetAttr == null) {
                return null;
            }
            // getOrdinalPosition() is 1-based. Normalize to 0-based to match sourceColumnIndex
            int targetIdx = targetAttr.getOrdinalPosition() - 1;
            mapping.add(new WebSQLReferenceColumnMapping(
                sourceIdx, sourceAttr.getName(), targetIdx, targetAttr.getName()));
        }
        return mapping;
    }

    @Nullable
    public static Object convertInputCellValue(
        @NotNull DBCSession session,
        @NotNull DBDAttributeBinding updateAttribute,
        @NotNull Object cellRawValue,
        boolean justGenerateScript
    ) throws DBCException {
        Object plainCellValue = makePlainCellValue(session, updateAttribute, cellRawValue);
        Object realCellValue = plainCellValue;
        // In some cases we already have final value here
        if (!(realCellValue instanceof DBDValue)) {
            try {
                realCellValue = updateAttribute.getValueHandler().getValueFromObject(
                    session,
                    updateAttribute,
                    plainCellValue,
                    false,
                    true
                );
                //FIXME: fix array editing for nosql databases
                if (realCellValue == null && plainCellValue != null && updateAttribute.getDataKind() == DBPDataKind.ARRAY) {
                    throw new DBCException("Array update is not supported");
                }
            } catch (DBCException e) {
                //checks if this function is used only for script generation
                if (justGenerateScript) {
                    return null;
                } else {
                    throw e;
                }
            }
        }
        return realCellValue;
    }

    @NotNull
    public static DBDDocument applyDocumentUpdate(
        @NotNull DBDDocument document,
        @Nullable DBDAttributeBinding documentAttribute,
        @NotNull DBDAttributeBinding updateAttribute,
        @Nullable Object value
    ) throws DBCException {
        if (updateAttribute == documentAttribute && value instanceof DBDDocument updatedDocument) {
            return updatedDocument;
        }
        if (document instanceof DBDComposite composite) {
            composite.setAttributeValue(updateAttribute, value);
        }
        return document;
    }

    @NotNull
    public static DBDDocument makeDocumentInputValue(
        @NotNull DBCSession session,
        @NotNull DBSDocumentLocator dataContainer,
        @NotNull WebSQLResultsInfo resultsInfo,
        @NotNull WebSQLResultsRow row,
        @Nullable Map<String, Object> metaData
    ) throws DBException {
        // Document reference
        DBDDocument document = null;
        Map<String, Object> keyMap = new LinkedHashMap<>();
        DBDAttributeBinding[] attributes = resultsInfo.getAttributes();
        for (int j = 0; j < attributes.length; j++) {
            DBDAttributeBinding attr = attributes[j];
            Object plainValue = makePlainCellValue(session, attr, row.getValues()[j]);
            if (plainValue instanceof DBDDocument dbdDocument && dataContainer.isDocumentValid(dbdDocument)) {
                // FIXME: Hack for DynamoDB. We pass entire document as a key
                // FIXME: Let's just return it back for now
                document = dbdDocument;
                break;
            }
            keyMap.put(attr.getName(), plainValue);
        }
        if (document == null) {
            document = dataContainer.findDocument(session, keyMap, metaData);
            if (document == null) {
                throw new DBCException("Error finding document by key " + keyMap);
            }
        }
        return document;
    }
}
