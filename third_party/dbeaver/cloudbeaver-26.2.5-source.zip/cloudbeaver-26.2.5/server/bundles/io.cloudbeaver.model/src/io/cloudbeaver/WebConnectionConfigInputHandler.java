/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver;

import io.cloudbeaver.model.WebConnectionConfig;
import io.cloudbeaver.model.app.WebAppConfiguration;
import io.cloudbeaver.model.session.WebSession;
import io.cloudbeaver.utils.ServletAppUtils;
import io.cloudbeaver.utils.WebDataSourceUtils;
import org.jkiss.code.NotNull;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.access.DBAAuthCredentials;
import org.jkiss.dbeaver.model.access.DBAAuthModel;
import org.jkiss.dbeaver.model.app.DBPDataSourceRegistry;
import org.jkiss.dbeaver.model.connection.DBPConnectionConfiguration;
import org.jkiss.dbeaver.model.connection.DBPDriver;
import org.jkiss.dbeaver.model.net.DBWHandlerConfiguration;
import org.jkiss.dbeaver.registry.DataSourceDescriptor;
import org.jkiss.dbeaver.registry.DataSourcePreferenceStore;
import org.jkiss.dbeaver.runtime.properties.ObjectPropertyDescriptor;
import org.jkiss.utils.CommonUtils;

import java.util.LinkedHashMap;
import java.util.Map;

public class WebConnectionConfigInputHandler<T extends WebConnectionConfig, C extends DataSourceDescriptor> {
    private static final Log log = Log.getLog(WebConnectionConfigInputHandler.class);
    protected final T input;
    protected final DBPDataSourceRegistry registry;
    protected final WebSession webSession;

    public WebConnectionConfigInputHandler(@NotNull WebSession webSession, @NotNull DBPDataSourceRegistry registry, T configInput) {
        this.webSession = webSession;
        this.registry = registry;
        this.input = configInput;
    }

    public C createDataSourceContainer() throws DBWebException {
        String driverId = input.getDriverId();
        if (CommonUtils.isEmpty(driverId)) {
            throw new DBWebException("Driver must be specified");
        }
        DBPDriver driver = WebDataSourceUtils.getDriverById(driverId);

        C newDataSource = createDataSourceContainerFromInput(driver);

        if (ServletAppUtils.getServletApplication().getAppConfiguration() instanceof WebAppConfiguration webAppConfiguration) {
            newDataSource.setNavigatorSettings(webAppConfiguration.getDefaultNavigatorSettings());
        }

        WebDataSourceUtils.saveAuthProperties(
            webSession.getProgressMonitor(),
            newDataSource,
            newDataSource.getConnectionConfiguration(),
            input.getCredentials(),
            input.isSaveCredentials(),
            input.isSharedCredentials()
        );
        return newDataSource;
    }

    public void updateDataSource(@NotNull C dataSource) throws DBWebException {
        dataSource.setId(dataSource.getId());
        if (!CommonUtils.isEmpty(input.getName())) {
            dataSource.setName(input.getName());
        }

        if (input.getDescription() != null) {
            dataSource.setDescription(input.getDescription());
        }

        dataSource.setFolder(input.getFolder() != null ? registry.getFolder(input.getFolder()) : null);
        dataSource.getConnectionConfiguration().getBootstrap().setDefaultAutoCommit(input.isDefaultAutoCommit());
        WebDataSourceUtils.setConnectionConfiguration(
            dataSource.getDriver(),
            dataSource.getConnectionConfiguration(),
            input
        );
        WebDataSourceUtils.saveAuthProperties(
            webSession.getProgressMonitor(),
            dataSource,
            dataSource.getConnectionConfiguration(),
            input.getCredentials(),
            input.isSaveCredentials(),
            input.isSharedCredentials()
        );
        dataSource.setConnectionReadOnly(input.isReadOnly());
        DataSourcePreferenceStore preferenceStore = dataSource.getPreferenceStore();
        preferenceStore.clear();
        preferenceStore.setProperties(input.getDefaultUserPreferences());
    }

    /**
     * Removes references to credentials resolved on the server.
     */
    public void clearSecretReferences() {
        input.setSharedCredentials(false);
        input.setSelectedSecretId(null);
    }

    /**
     * Removes credentials inherited from a saved data source before applying input credentials.
     */
    public void resetDataSourceCredentials(@NotNull C dataSource) {
        dataSource.setSavePassword(false);
        dataSource.setSharedCredentials(false);
        dataSource.resetAllSecrets();
        DBPConnectionConfiguration connectionConfiguration = dataSource.getConnectionConfiguration();
        resetSecureAuthModelCredentials(dataSource, connectionConfiguration);
        dataSource.resetPassword();
        for (DBWHandlerConfiguration handler : connectionConfiguration.getHandlers()) {
            handler.setSavePassword(false);
            handler.setPassword(null);
            handler.setSecureProperties(Map.of());
        }
    }

    private void resetSecureAuthModelCredentials(
        @NotNull C dataSource,
        @NotNull DBPConnectionConfiguration connectionConfiguration
    ) {
        if (connectionConfiguration.getAuthProperties().isEmpty()) {
            return;
        }
        DBAAuthModel<DBAAuthCredentials> authModel = connectionConfiguration.getAuthModel();
        DBAAuthCredentials sanitizedCredentials = authModel.loadCredentials(dataSource, connectionConfiguration);
        Map<String, Object> secureProperties = new LinkedHashMap<>();
        ObjectPropertyDescriptor.extractAnnotations(
                null,
                ObjectPropertyDescriptor.getObjectClass(sanitizedCredentials),
                (object, property) -> true,
                null
            ).stream()
            .filter(ObjectPropertyDescriptor::isPassword)
            .forEach(property -> secureProperties.put(CommonUtils.toString(property.getId()), null));
        if (!secureProperties.isEmpty()) {
            WebDataSourceUtils.updateCredentialsFromProperties(
                webSession.getProgressMonitor(),
                sanitizedCredentials,
                secureProperties
            );
            Map<String, String> sanitizedProperties = serializeAuthProperties(
                dataSource,
                connectionConfiguration,
                authModel,
                sanitizedCredentials
            );
            connectionConfiguration.setAuthProperties(sanitizedProperties);
        }
    }

    @NotNull
    private Map<String, String> serializeAuthProperties(
        @NotNull C dataSource,
        @NotNull DBPConnectionConfiguration connectionConfiguration,
        @NotNull DBAAuthModel<DBAAuthCredentials> authModel,
        @NotNull DBAAuthCredentials credentials
    ) {
        DBPConnectionConfiguration configurationCopy = new DBPConnectionConfiguration(connectionConfiguration);
        configurationCopy.setAuthProperties(null);
        authModel.saveCredentials(dataSource, configurationCopy, credentials);
        return configurationCopy.getAuthProperties();
    }

    @NotNull
    public CredentialsSnapshot createCredentialsSnapshot(@NotNull C dataSource) {
        var connectionConfiguration = new DBPConnectionConfiguration(dataSource.getConnectionConfiguration());
        var savePassword = dataSource.isSavePassword();
        var sharedCredentials = dataSource.isSharedCredentials();
        var selectedSharedCredentials = dataSource.getSelectedSharedCredentials();
        return () -> {
            dataSource.setSharedCredentials(false);
            dataSource.resetAllSecrets();
            dataSource.setConnectionInfo(connectionConfiguration);
            dataSource.setSavePassword(savePassword);
            dataSource.setSharedCredentials(sharedCredentials);
            if (selectedSharedCredentials != null) {
                dataSource.setSelectedSharedCredentials(selectedSharedCredentials);
            }
        };
    }

    public boolean isConnectionTargetChanged(@NotNull C dataSource) {
        return WebDataSourceUtils.isConnectionTargetChanged(dataSource.getConnectionConfiguration(), input);
    }

    @NotNull
    protected C createDataSourceContainerFromInput(@NotNull DBPDriver driver) {
        DBPConnectionConfiguration dsConfig = new DBPConnectionConfiguration();
        WebDataSourceUtils.setConnectionConfiguration(driver, dsConfig, input);
        C newDataSource = registry.createDataSource(driver, dsConfig);

        newDataSource.setSavePassword(true);
        newDataSource.setName(CommonUtils.notNull(input.getName(), "NewConnection"));
        newDataSource.setDescription(input.getDescription());
        newDataSource.setConnectionReadOnly(input.isReadOnly());
        if (input.getFolder() != null) {
            newDataSource.setFolder(registry.getFolder(input.getFolder()));
        }
        return newDataSource;
    }

    @FunctionalInterface
    public interface CredentialsSnapshot {
        void restore();
    }
}
