/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver;

import io.cloudbeaver.model.WebConnectionConfig;
import io.cloudbeaver.model.WebConnectionInfo;
import io.cloudbeaver.model.WebNetworkHandlerConfigInput;
import io.cloudbeaver.model.session.WebSession;
import io.cloudbeaver.utils.WebDataSourceUtils;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.DBPAdaptable;
import org.jkiss.dbeaver.model.DBPDataSourceContainer;
import org.jkiss.dbeaver.model.DBPObjectSettingsProvider;
import org.jkiss.dbeaver.model.app.DBPDataSourceRegistry;
import org.jkiss.dbeaver.model.app.DBPDataSourceRegistryCache;
import org.jkiss.dbeaver.model.auth.SMObjectType;
import org.jkiss.dbeaver.model.navigator.DBNModel;
import org.jkiss.dbeaver.model.rm.RMProject;
import org.jkiss.dbeaver.model.rm.RMUtils;
import org.jkiss.dbeaver.model.security.SMControllerUtils;
import org.jkiss.dbeaver.model.websocket.event.datasource.WSDataSourceEvent;
import org.jkiss.dbeaver.model.websocket.event.datasource.WSDataSourceProperty;
import org.jkiss.dbeaver.registry.DataSourceDescriptor;
import org.jkiss.dbeaver.registry.DataSourceRegistry;
import org.jkiss.dbeaver.registry.project.BaseProjectSettings;
import org.jkiss.dbeaver.runtime.jobs.DisconnectJob;
import org.jkiss.utils.CommonUtils;

import java.nio.file.Path;
import java.util.*;

public class WebSessionProjectImpl extends WebProjectImpl implements DBPAdaptable {
    private static final Log log = Log.getLog(WebSessionProjectImpl.class);

    protected final WebSession webSession;
    private final Map<String, WebConnectionInfo> connections = new HashMap<>();
    private final BaseProjectSettings projectSettings;
    private boolean registryIsLoaded = false;

    public WebSessionProjectImpl(
        @NotNull WebSession webSession,
        @NotNull RMProject project
    ) {
        this(webSession, project, null);
    }

    public WebSessionProjectImpl(
        @NotNull WebSession webSession,
        @NotNull RMProject project,
        @Nullable Path path
    ) {
        super(
            webSession.getWorkspace(),
            webSession.getRmController(),
            webSession.getSessionContext(),
            project,
            webSession.getUserPreferenceStore(),
            path == null ? RMUtils.getProjectPath(project) : path
        );
        this.webSession = webSession;
        this.projectSettings = new BaseProjectSettings(this) {
            @NotNull
            @Override
            protected Map<SMObjectType, Map<String, Map<String, String>>> loadAllProjectSettings() throws DBException {
                if (webSession.getUser() == null) {
                    return new LinkedHashMap<>();
                }
                return SMControllerUtils.getObjectSettingsMap(WebSessionProjectImpl.this, webSession.getSecurityController());
            }

            @Override
            protected void saveProjectSettings(
                @NotNull SMObjectType objectType,
                @NotNull String objectId,
                @NotNull Map<String, String> settings
            ) throws DBException {
                if (webSession.getUserContext().isNonAnonymousUserAuthorizedInSM()) {
                    webSession.getSecurityController().setObjectSettings(getId(), objectType, objectId, settings);
                }
            }

        };
    }

    @NotNull
    public BaseProjectSettings getProjectSettings() {
        return projectSettings;
    }

    @NotNull
    @Override
    public DBNModel getNavigatorModel() {
        return webSession.getNavigatorModel();
    }

    @Override
    public <T> T getAdapter(@NotNull Class<T> adapter) {
        if (adapter == DBPObjectSettingsProvider.class) {
            return adapter.cast(projectSettings);
        }
        return null;
    }

    @NotNull
    @Override
    protected DBPDataSourceRegistry createDataSourceRegistry() {
        return createRegistryWithCredentialsProvider();
    }

    @NotNull
    protected DataSourceRegistry<?> createRegistryWithCredentialsProvider() {
        DataSourceRegistry<?> dataSourceRegistry = createRMRegistry();
        dataSourceRegistry.setAuthCredentialsProvider(webSession);
        dataSourceRegistry.addDataSourceListener(webSession.getDataSourceConnectListener());
        return dataSourceRegistry;
    }

    private synchronized void addDataSourcesToCache() {
        if (registryIsLoaded) {
            return;
        }
        DBPDataSourceRegistry dataSourceRegistry = getDataSourceRegistry();
        // Connection node paths are resolved through the navigator model, so materialize its lazy database branch first.
        webSession.initializeProjectNavigator(this);
        dataSourceRegistry.getDataSources().forEach(this::addConnection);
        Throwable lastError = dataSourceRegistry.getLastError();
        if (lastError != null) {
            webSession.addSessionError(lastError);
            log.error("Error refreshing connections from project '" + getId() + "'", lastError);
        }
        registryIsLoaded = true;
    }

    @Override
    public void dispose() {
        super.dispose();
        Map<String, WebConnectionInfo> conCopy;
        synchronized (this.connections) {
            conCopy = new HashMap<>(this.connections);
            this.connections.clear();
        }

        for (WebConnectionInfo connectionInfo : conCopy.values()) {
            if (connectionInfo.isConnected()) {
                new DisconnectJob(connectionInfo.getDataSourceContainer()).schedule();
            }
        }
    }


    /**
     * Returns web connection info from cache (if exists).
     */
    @Nullable
    public WebConnectionInfo findWebConnectionInfo(@NotNull String connectionId) {
        synchronized (connections) {
            return connections.get(connectionId);
        }
    }

    /**
     * Returns web connection info from cache, adds it to cache if not present.
     * Throws exception if connection is not found.
     */
    @NotNull
    public WebConnectionInfo getWebConnectionInfo(@NotNull String connectionId) throws DBWebException {
        WebConnectionInfo connectionInfo = findWebConnectionInfo(connectionId);
        if (connectionInfo != null) {
            return connectionInfo;
        }
        DBPDataSourceContainer dataSource = getDataSourceRegistry().getDataSource(connectionId);
        if (dataSource != null) {
            return addConnection(dataSource);
        }
        throw new DBWebException("Connection '%s' not found".formatted(connectionId));
    }

    /**
     * Adds connection to project cache.
     */
    @NotNull
    public synchronized WebConnectionInfo addConnection(@NotNull DBPDataSourceContainer dataSourceContainer) {
        WebConnectionInfo connection = createConnectionInfo(dataSourceContainer);
        synchronized (connections) {
            connections.put(dataSourceContainer.getId(), connection);
        }
        return connection;
    }

    /**
     * Removes connection from project cache.
     */
    public void removeConnection(@NotNull DBPDataSourceContainer dataSourceContainer) {
        WebConnectionInfo webConnectionInfo = connections.get(dataSourceContainer.getId());
        if (webConnectionInfo != null) {
            webConnectionInfo.clearCache();
            synchronized (connections) {
                connections.remove(dataSourceContainer.getId());
            }
        }
    }

    /**
     * Loads connection from registry if they are not loaded.
     *
     * @return connections from cache.
     */
    @NotNull
    public List<WebConnectionInfo> getConnections() {
        if (!registryIsLoaded) {
            addDataSourcesToCache();
            registryIsLoaded = true;
        }
        synchronized (connections) {
            return new ArrayList<>(connections.values());
        }
    }

    /**
     * updates data sources based on event in web session
     *
     * @param event data source updated event
     */
    public synchronized boolean updateProjectDataSources(@NotNull WSDataSourceEvent event) {
        var sendDataSourceUpdatedEvent = false;
        DBPDataSourceRegistry registry = getDataSourceRegistry();
        Map<String, DataSourceDescriptor> dataSourceSnapshots = new HashMap<>();
        if (WSDataSourceEvent.UPDATED.equals(event.getId())) {
            for (String dsId : event.getDataSourceIds()) {
                DBPDataSourceContainer dataSource = registry.getDataSource(dsId);
                if (dataSource instanceof DataSourceDescriptor descriptor) {
                    DBPDataSourceContainer snapshot = registry.createDataSource(descriptor);
                    if (snapshot instanceof DataSourceDescriptor snapshotDescriptor) {
                        dataSourceSnapshots.put(dsId, snapshotDescriptor);
                    }
                }
            }
        }
        if (WSDataSourceEvent.CREATED.equals(event.getId()) || WSDataSourceEvent.UPDATED.equals(event.getId())) {
            registry.refreshConfig(event.getDataSourceIds());
        }
        for (String dsId : event.getDataSourceIds()) {
            DataSourceDescriptor ds = (DataSourceDescriptor) registry.getDataSource(dsId);
            if (ds == null) {
                continue;
            }
            switch (event.getId()) {
                case WSDataSourceEvent.CREATED -> {
                    addConnection(ds);
                    sendDataSourceUpdatedEvent = true;
                }
                case WSDataSourceEvent.UPDATED ->  {
                    DataSourceDescriptor snapshot = dataSourceSnapshots.get(dsId);
                    if (snapshot != null && !event.getProperty().hasEffectiveChanges(snapshot, ds)) {
                        continue;
                    }
                    if (event.getProperty() == WSDataSourceProperty.CONFIGURATION) {
                        WebDataSourceUtils.disconnectDataSource(webSession, ds, true);
                    }
                    if (event.getProperty() != WSDataSourceProperty.INTERNAL) {
                        sendDataSourceUpdatedEvent = true;
                    }
                }
                case WSDataSourceEvent.DELETED -> {
                    WebDataSourceUtils.disconnectDataSource(webSession, ds, false);
                    if (registry instanceof DBPDataSourceRegistryCache dsrc) {
                        dsrc.removeDataSourceFromList(ds);
                    }
                    removeConnection(ds);
                    sendDataSourceUpdatedEvent = true;
                }
                default -> {
                }
            }
        }
        return sendDataSourceUpdatedEvent;
    }

    @NotNull
    public WebConnectionInfo createConnectionInfo(@NotNull DBPDataSourceContainer dataSourceDescriptor) {
        return new WebConnectionInfo(webSession, dataSourceDescriptor);
    }

    @NotNull
    public WebConnectionInfo createConnection(@NotNull Map<String, Object> configMap) throws DBWebException {
        if (CommonUtils.isEmpty(configMap)) {
            throw new DBWebException("Connection configuration parameters are missing");
        }
        WebConnectionConfig config = getConnectionConfigInput(configMap);
        DataSourceDescriptor newDataSource = getDataSourceContainerFromInput(config);
        boolean hidden = Boolean.TRUE.equals(config.getHidden());
        newDataSource.setHidden(hidden);
        if (hidden) {
            return addConnection(newDataSource);
        }
        return addDataSourceToProject(newDataSource);
    }

    @NotNull
    public WebConnectionInfo addDataSourceToProject(@NotNull DBPDataSourceContainer newDataSource) throws DBWebException {
        DBPDataSourceRegistry registry = getDataSourceRegistry();
        try {
            registry.addDataSource(newDataSource);
            registry.checkForErrors();
        } catch (DBException e) {
            registry.removeDataSource(newDataSource);
            throw new DBWebException("Failed to create connection", e);
        }

        WebConnectionInfo connectionInfo = addConnection(newDataSource);
        webSession.addInfoMessage("New connection was created - " + WebDataSourceUtils.getConnectionContainerInfo(
            newDataSource));
        log.info(String.format(
            "New connection was created: [info=%s, user=%s]",
            WebDataSourceUtils.getConnectionContainerInfo(newDataSource),
            webSession.getUserId()
        ));
        return connectionInfo;
    }

    @NotNull
    @SuppressWarnings("unchecked")
    public WebConnectionInfo updateConnection(@Nullable Map<String, Object> configMap) throws DBWebException {
        WebConnectionConfig config = getConnectionConfigInput(configMap);
        WebConnectionInfo connectionInfo = getWebConnectionInfo(config.getConnectionId());
        DataSourceDescriptor dataSource = (DataSourceDescriptor) connectionInfo.getDataSourceContainer();
        if (Boolean.TRUE.equals(config.getHidden()) && !dataSource.isHidden()) {
            throw new DBWebException("Visible connection '%s' cannot be hidden".formatted(dataSource.getId()));
        }
        webSession.addInfoMessage("Update connection - " + WebDataSourceUtils.getConnectionContainerInfo(dataSource));

        DBPDataSourceRegistry registry = getDataSourceRegistry();
        boolean wasHidden = dataSource.isHidden();
        boolean publishDraft = false;
        WebConnectionConfigInputHandler.CredentialsSnapshot credentialsSnapshot = null;
        Map<String, Object> savedAuthProperties = null;
        List<WebNetworkHandlerConfigInput> savedNetworkCredentials = null;
        var inputHandler = getInputConfigHandler(config);
        try {
            if (webSession.getApplication().getAppConfiguration()
                .isFeatureEnabled(DBWConstants.FEATURE_RESET_CREDENTIALS_ON_TARGET_CHANGE) &&
                inputHandler.isConnectionTargetChanged(dataSource)) {
                credentialsSnapshot = inputHandler.createCredentialsSnapshot(dataSource);
                savedAuthProperties = connectionInfo.getSavedAuthProperties();
                savedNetworkCredentials = connectionInfo.getSavedNetworkCredentials();
                inputHandler.clearSecretReferences();
                inputHandler.resetDataSourceCredentials(dataSource);
                connectionInfo.setSavedCredentials(null, null);
            }
            inputHandler.updateDataSource(dataSource);
            if (config.getHidden() != null) {
                dataSource.setHidden(config.getHidden());
            }
            connectionInfo.setCredentialsSavedInSession(null);
            publishDraft = wasHidden && !dataSource.isHidden();
            if (publishDraft) {
                registry.addDataSource(dataSource);
            } else if (!wasHidden) {
                registry.updateDataSource(dataSource);
            }
            if (publishDraft || !wasHidden) {
                registry.checkForErrors();
            }
        } catch (DBException e) {
            if (credentialsSnapshot != null) {
                credentialsSnapshot.restore();
                connectionInfo.setSavedCredentials(savedAuthProperties, savedNetworkCredentials);
            }
            if (publishDraft) {
                registry.removeDataSource(dataSource);
            }
            dataSource.setHidden(wasHidden);
            throw new DBWebException("Failed to update connection", e);
        }
        return connectionInfo;
    }

    public boolean deleteConnection(@NotNull String connectionId) throws DBWebException {
        WebConnectionInfo connectionInfo = getWebConnectionInfo(connectionId);
        webSession.addInfoMessage("Delete connection - " +
            WebDataSourceUtils.getConnectionContainerInfo(connectionInfo.getDataSourceContainer()));
        closeAndDeleteConnection(connectionInfo);

        log.info(String.format(
            "Connection deleted: [info=%s, userId=%s]",
            WebDataSourceUtils.getConnectionContainerInfo(connectionInfo.getDataSourceContainer()),
            webSession.getUserId()
        ));
        return true;
    }

    @NotNull
    private WebConnectionInfo closeAndDeleteConnection(@NotNull WebConnectionInfo connectionInfo) throws DBWebException {
        DBPDataSourceContainer dataSourceContainer = connectionInfo.getDataSourceContainer();
        WebDataSourceUtils.disconnectDataSource(webSession, dataSourceContainer, false);
        DBPDataSourceRegistry registry = getDataSourceRegistry();
        registry.removeDataSource(dataSourceContainer);
        removeConnection(dataSourceContainer);
        return connectionInfo;
    }

    @NotNull
    public DataSourceDescriptor getDataSourceContainerFromInput(@NotNull WebConnectionConfig configInput) throws DBWebException {
        return getInputConfigHandler(configInput).createDataSourceContainer();
    }

    @NotNull
    public DataSourceDescriptor getDataSourceContainerFromInput(
        @NotNull WebConnectionConfig configInput,
        @NotNull DataSourceDescriptor sourceDataSource,
        boolean resetCredentials
    ) throws DBWebException {
        var dataSourceCopy = (DataSourceDescriptor) sourceDataSource.createCopy(sourceDataSource.getRegistry());
        var inputHandler = getInputConfigHandler(configInput);
        if (resetCredentials) {
            inputHandler.clearSecretReferences();
            inputHandler.resetDataSourceCredentials(dataSourceCopy);
        }
        inputHandler.updateDataSource(dataSourceCopy);
        return dataSourceCopy;
    }

    public void updateDataSourceContainerFromInput(
        @NotNull WebConnectionConfig configInput,
        @NotNull DataSourceDescriptor dataSource
    ) throws DBWebException {
        getInputConfigHandler(configInput).updateDataSource(dataSource);
    }

    public boolean isConnectionTargetChanged(
        @NotNull WebConnectionConfig configInput,
        @NotNull DataSourceDescriptor dataSource
    ) {
        return getInputConfigHandler(configInput).isConnectionTargetChanged(dataSource);
    }

    @NotNull
    public WebConnectionConfig getConnectionConfigInput(@Nullable Map<String, Object> configMap) {
        return new WebConnectionConfig(configMap == null ? Map.of() : configMap);
    }

    @NotNull
    protected WebConnectionConfigInputHandler getInputConfigHandler(@NotNull WebConnectionConfig configInput) {
        return new WebConnectionConfigInputHandler<>(webSession, getDataSourceRegistry(), configInput);
    }


}
