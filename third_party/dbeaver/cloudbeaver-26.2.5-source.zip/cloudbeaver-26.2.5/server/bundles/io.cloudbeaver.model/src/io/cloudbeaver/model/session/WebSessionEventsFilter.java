/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.model.session;

import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.model.websocket.event.WSEvent;
import org.jkiss.dbeaver.model.websocket.event.WSProjectResourceEvent;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

public class WebSessionEventsFilter {
    private final BaseWebSession session;
    private final Set<String> subscribedEventTopics = new CopyOnWriteArraySet<>();
    private final Set<String> subscribedProjectIds = new CopyOnWriteArraySet<>();
    private final Map<String, List<WebTopicActivityListener>> topicActivityListeners = new ConcurrentHashMap<>();
    private final Set<String> handledStartTopics = new CopyOnWriteArraySet<>();

    public WebSessionEventsFilter(BaseWebSession session) {
        this.session = session;
    }

    public void subscribeOnEventTopic(@Nullable String topic) {
        if (topic == null) {
            return;
        }
        subscribedEventTopics.add(topic);

        topicActivityListeners
            .getOrDefault(topic, List.of()).stream()
            .filter(listener -> !handledStartTopics.contains(listener.getTopicName()))
            .forEach(listener -> {
                listener.handelStartSubscriptionTopic(session);
                handledStartTopics.add(topic);
            });
    }

    public void unsubscribeFromEventTopic(@Nullable String topic) {
        if (topic == null) {
            return;
        }
        subscribedEventTopics.remove(topic);
    }

    public void setSubscribedProjects(@NotNull Set<String> subscribedProjectIds) {
        synchronized (this.subscribedProjectIds) {
            this.subscribedProjectIds.clear();
            this.subscribedProjectIds.addAll(subscribedProjectIds);
        }
    }

    public void migrateTo(@NotNull WebSessionEventsFilter target) {
        synchronized (target.subscribedProjectIds) {
            target.subscribedEventTopics.addAll(this.subscribedEventTopics);
            target.subscribedProjectIds.addAll(this.subscribedProjectIds);
        }
    }

    public boolean isEventAllowed(WSEvent event) {
        if (event.isForceProcessed()) {
            return true;
        }
        if (!subscribedEventTopics.isEmpty() && !subscribedEventTopics.contains(event.getTopicId())
        ) {
            return false;
        }

        if (!subscribedProjectIds.isEmpty() && event instanceof WSProjectResourceEvent) {
            var projectEvent = (WSProjectResourceEvent) event;
            if (!subscribedProjectIds.contains(projectEvent.getProjectId())) {
                return false;
            }
        }

        return true;
    }
    
    public void addTopicSubscribeListener(WebTopicActivityListener listener) {
        topicActivityListeners
            .computeIfAbsent(listener.getTopicName(), k -> new CopyOnWriteArrayList<>())
            .add(listener);
    }
}
