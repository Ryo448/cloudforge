/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.test;

import com.google.gson.*;
import io.cloudbeaver.server.CBConstants;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.model.data.json.JSONUtils;
import org.jkiss.dbeaver.utils.GeneralUtils;
import org.jkiss.utils.HttpConstants;

import java.net.CookieManager;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * GraphQL client for tests.
 */
public class WebGQLClient {
    private static final Gson gson = new GsonBuilder()
        .setPrettyPrinting()
        .create();
    private static final Gson REQUEST_GSON = gson.newBuilder().serializeNulls().create();
    public static final String GQL_AUTHENTICATE = """
        query authLogin($provider: ID!, $configuration: ID, $credentials: Object, $linkUser: Boolean, $forceSessionsLogout: Boolean) {
          result: authLogin(
            provider: $provider
            configuration: $configuration
            credentials: $credentials
            linkUser: $linkUser
            forceSessionsLogout: $forceSessionsLogout
          ) {
            authId
            authStatus
          }
        }""";

    @NotNull
    private final HttpClient httpClient;
    @NotNull
    private final CookieManager cookieManager;
    @NotNull
    private final String apiUrl;

    public WebGQLClient(@NotNull HttpClient httpClient, @NotNull CookieManager cookieManager, @NotNull String apiUrl) {
        this.httpClient = httpClient;
        this.cookieManager = cookieManager;
        this.apiUrl = apiUrl;
    }

    /**
     * Sends GraphQL request without additional headers
     *
     * @param query     GraphQL query
     * @param variables GraphQL query variables
     * @return GraphQL response
     */
    @Nullable
    public <T> T sendQuery(@NotNull String query, @Nullable Map<String, Object> variables) throws Exception {
        return sendQueryWithHeaders(query, variables, Map.of());
    }

    @NotNull
    public Map<String, Object> sendQueryAndGetHeaders(
        @NotNull String query,
        @Nullable Map<String, Object> variables,
        @NotNull Map<String, String> requestHeaders
    ) throws Exception {
        return executeGQLRequest(query, variables, requestHeaders);
    }

    /**
     * Sends GraphQL request without additional headers
     *
     * @param query     GraphQL query
     * @param variables GraphQL query variables
     * @param headers   HTTP request headers
     * @return GraphQL response
     */
    @NotNull
    public <T> T sendQueryWithHeaders(
        @NotNull String query,
        @Nullable Map<String, Object> variables,
        @NotNull Map<String, String> headers
    ) throws Exception {
        Map<String, Object> parsed = executeGQLRequest(query, variables, headers);
        // graphql response will be in "data" key
        return (T) parsed.get("data");
    }

    @NotNull
    private Map<String, Object> executeGQLRequest(
        @NotNull String query,
        @Nullable Map<String, Object> variables,
        @NotNull Map<String, String> requestHeaders
    ) throws Exception {
        return  executeGQLRequest(query, variables, requestHeaders, "result");
    }

    @NotNull
    public Map<String, Object> executeGQLRequest(
        @NotNull String query,
        @Nullable Map<String, Object> variables,
        @NotNull Map<String, String> requestHeaders,
        @NotNull String resultName
    ) throws Exception {
        HttpRequest.Builder requestBuilder = HttpRequest.newBuilder()
            .uri(URI.create(apiUrl))
            .POST(HttpRequest.BodyPublishers.ofString(makeGQLRequest(query, variables)))
            .setHeader("TE-Client-Version", GeneralUtils.getMajorVersion())
            .header(HttpConstants.HEADER_CONTENT_TYPE, HttpConstants.CONTENT_TYPE_JSON);
        if (!requestHeaders.isEmpty()) {
            requestHeaders.forEach(requestBuilder::header);
        }
        HttpRequest request = requestBuilder.build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        Map<String, Object> body = gson.fromJson(
            response.body(),
            JSONUtils.MAP_TYPE_TOKEN
        );
        if (body.containsKey("errors")) {
            String message = JSONUtils.getString(JSONUtils.getObjectList(body, "errors").get(0), "message");
            throw new DBException(message);
        }
        Map<String, Object> parsed = new LinkedHashMap<>();
        parsed.put("data", JSONUtils.getObject(body, "data").get(resultName));
        parsed.put("headers", response.headers().map());
        return parsed;
    }

    @NotNull
    private String makeGQLRequest(@NotNull String text, @Nullable Map<String, Object> variables) {
        Map<String, Object> request = new LinkedHashMap<>();
        request.put("query", text);
        if (variables != null && !variables.isEmpty()) {
            request.put("variables", variables);
        }

        return REQUEST_GSON.toJson(toRequestJson(request));
    }

    @NotNull
    private JsonElement toRequestJson(@Nullable Object value) {
        // Preserve explicit nulls in JSON input maps, but keep omitting unset fields of Java DTOs.
        if (value instanceof Map<?, ?> values) {
            JsonObject object = new JsonObject();
            values.forEach((key, item) -> object.add(String.valueOf(key), toRequestJson(item)));
            return object;
        }
        if (value instanceof Object[] values) {
            value = Arrays.asList(values);
        }
        if (value instanceof Iterable<?> values) {
            JsonArray array = new JsonArray();
            values.forEach(item -> array.add(toRequestJson(item)));
            return array;
        }
        if (value instanceof JsonElement json) {
            return json;
        }
        return gson.toJsonTree(value);
    }

    @NotNull
    public String getSessionIdCookie() {
        return cookieManager.getCookieStore().getCookies().stream()
            .filter(cookie -> cookie.getName().equals(CBConstants.CB_SESSION_COOKIE_NAME))
            .findFirst()
            .get()
            .getValue();
    }
}
