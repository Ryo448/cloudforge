/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.model.rm.local;

import io.cloudbeaver.DBWConstants;
import io.cloudbeaver.model.app.ServletApplication;
import io.cloudbeaver.service.security.SMUtils;
import io.cloudbeaver.service.sql.WebSQLConstants;
import io.cloudbeaver.utils.ServletAppUtils;
import io.cloudbeaver.utils.WebRMUtils;
import io.cloudbeaver.utils.file.UniversalFileVisitor;
import org.eclipse.core.runtime.IPath;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.DBPDataSourceContainer;
import org.jkiss.dbeaver.model.DBPDataSourceFolder;
import org.jkiss.dbeaver.model.app.DBPDataSourceRegistry;
import org.jkiss.dbeaver.model.app.DBPWorkspace;
import org.jkiss.dbeaver.model.auth.SMCredentials;
import org.jkiss.dbeaver.model.auth.SMCredentialsProvider;
import org.jkiss.dbeaver.model.auth.SMObjectType;
import org.jkiss.dbeaver.model.fs.lock.LockManager;
import org.jkiss.dbeaver.model.fs.lock.LockOptions;
import org.jkiss.dbeaver.model.fs.lock.LockTarget;
import org.jkiss.dbeaver.model.impl.app.BaseProjectImpl;
import org.jkiss.dbeaver.model.impl.auth.SessionContextImpl;
import org.jkiss.dbeaver.model.navigator.DBNLocalFolder;
import org.jkiss.dbeaver.model.net.DBWNetworkProfile;
import org.jkiss.dbeaver.model.rm.*;
import org.jkiss.dbeaver.model.security.SMAdminController;
import org.jkiss.dbeaver.model.sql.DBQuotaException;
import org.jkiss.dbeaver.model.websocket.event.MessageType;
import org.jkiss.dbeaver.model.websocket.event.WSSessionLogUpdatedEvent;
import org.jkiss.dbeaver.model.websocket.event.datasource.WSDataSourceEvent;
import org.jkiss.dbeaver.model.websocket.event.datasource.WSDataSourceProperty;
import org.jkiss.dbeaver.model.websocket.event.datasource.WSDatasourceFolderEvent;
import org.jkiss.dbeaver.model.websocket.event.datasource.WSNetworkProfileEvent;
import org.jkiss.dbeaver.registry.DataSourceDescriptor;
import org.jkiss.dbeaver.registry.DataSourceParseResults;
import org.jkiss.dbeaver.registry.ResourceTypeDescriptor;
import org.jkiss.dbeaver.registry.ResourceTypeRegistry;
import org.jkiss.dbeaver.runtime.DBWorkbench;
import org.jkiss.dbeaver.utils.GeneralUtils;
import org.jkiss.utils.CommonUtils;
import org.jkiss.utils.IOUtils;
import org.jkiss.utils.Pair;

import java.io.IOException;
import java.nio.file.*;
import java.text.MessageFormat;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Resource manager API
 */
public class LocalResourceController extends BaseLocalResourceController {

    private static final Log log = Log.getLog(LocalResourceController.class);

    protected final SMCredentialsProvider credentialsProvider;

    private final Path rootPath;
    private final Path userProjectsPath;
    protected final Path sharedProjectsPath;
    private final String globalProjectName;
    private Supplier<SMAdminController> smControllerSupplier;
    protected final List<RMFileOperationHandler> fileHandlers;

    private final Map<String, RMLocalProject> projectRegistries = new LinkedHashMap<>();

    public LocalResourceController(
        @NotNull DBPWorkspace workspace,
        @NotNull SMCredentialsProvider credentialsProvider,
        @NotNull Path rootPath,
        @NotNull Path userProjectsPath,
        @NotNull Path sharedProjectsPath,
        @NotNull Supplier<SMAdminController> smControllerSupplier,
        @NotNull LockManager lockController
    ) throws DBException {
        super(workspace, lockController);
        this.credentialsProvider = credentialsProvider;
        this.rootPath = rootPath;
        this.userProjectsPath = userProjectsPath;
        this.sharedProjectsPath = sharedProjectsPath;
        this.smControllerSupplier = smControllerSupplier;

        this.globalProjectName = DBWorkbench.getPlatform().getApplication().getDefaultProjectName();
        this.fileHandlers = RMFileOperationHandlersRegistry.getInstance().getFileHandlers();
    }

    @NotNull
    protected SMAdminController getSecurityController() {
        return smControllerSupplier.get();
    }

    @Nullable
    private Path getGlobalProjectPath() {
        return globalProjectName == null ? null : this.rootPath.resolve(this.globalProjectName);
    }

    @Nullable
    private Path getPrivateProjectPath() {
        SMCredentials activeUserCredentials = credentialsProvider.getActiveUserCredentials();
        String userId = activeUserCredentials == null ? null : activeUserCredentials.getUserId();
        return userId == null ? null : this.userProjectsPath.resolve(userId);
    }

    protected RMLocalProject getWebProject(@NotNull String projectId, boolean refresh) throws DBException {
        synchronized (projectRegistries) {
            RMLocalProject project = projectRegistries.get(projectId);
            if (project == null || refresh) {
                project = createWebProjectImpl(projectId, new SessionContextImpl(null));
                loadProjectInfo(project);
                projectRegistries.put(projectId, project);
            }
            return project;
        }
    }

    @NotNull
    protected RMLocalProject createWebProjectImpl(
        @NotNull String projectId,
        @NotNull SessionContextImpl sessionContext
    ) throws DBException {
        return new RMLocalProject(workspace, sessionContext, getProjectPath(projectId), WebRMUtils.parseProjectName(projectId).getType());
    }

    @NotNull
    @Override
    public RMProject[] listAccessibleProjects() throws DBException {
        List<RMProject> projects = new ArrayList<>(listAccessibleSharedProjects());
        var activeUserCreds = credentialsProvider.getActiveUserCredentials();

        //FIXME: remove legacy global project support
        //admin has all edit access
        //user has only read access
        var globalProjectPermissions = getProjectPermissions(globalProjectName, RMProjectType.GLOBAL);

        RMProject globalProject = makeProjectFromPath(getGlobalProjectPath(), globalProjectPermissions, RMProjectType.GLOBAL, true);
        if (globalProject != null) {
            projects.add(globalProject);
        }

        // Checking if private projects are enabled in the configuration and if the user has permission to them
        var webApp = ServletAppUtils.getServletApplication();
        var userHasPrivateProjectPermission = userHasAccessToPrivateProject(webApp, activeUserCreds);
        if (webApp.getAppConfiguration().isSupportsCustomConnections() && userHasPrivateProjectPermission) {
            var userProjectPermission = getProjectPermissions(null, RMProjectType.USER);
            RMProject userProject = makeProjectFromPath(getPrivateProjectPath(), userProjectPermission, RMProjectType.USER, false);
            if (userProject != null) {
                projects.add(0, userProject);
            }
        }

        projects.sort(Comparator.comparing(RMProject::getDisplayName));
        return projects.toArray(new RMProject[0]);
    }

    @NotNull
    protected List<RMProject> listAccessibleSharedProjects() throws DBException {
        return List.of();
    }

    @NotNull
    protected Set<RMProjectPermission> getProjectPermissions(
        @Nullable String projectId,
        @NotNull RMProjectType projectType
    ) throws DBException {
        var activeUserCreds = credentialsProvider.getActiveUserCredentials();

        switch (projectType) {
            case GLOBAL:
                return SMUtils.isRMAdmin(credentialsProvider)
                    ? Set.of(RMProjectPermission.PROJECT_ADMIN)
                    : Set.of(RMProjectPermission.RESOURCE_VIEW, RMProjectPermission.DATA_SOURCES_VIEW);
            case SHARED:
                return getSharedProjectPermissions(projectId, activeUserCreds);
            case USER:
                var webApp = ServletAppUtils.getServletApplication();
                if (userHasAccessToPrivateProject(webApp, activeUserCreds)) {
                    return Set.of(RMProjectPermission.RESOURCE_EDIT, RMProjectPermission.DATA_SOURCES_EDIT);
                }
            default:
                throw new DBException("Unknown project type:" + projectType);
        }
    }

    private boolean userHasAccessToPrivateProject(ServletApplication webApp, @Nullable SMCredentials activeUserCreds) {
        return !webApp.isMultiNode() ||
            (activeUserCreds != null && activeUserCreds.hasPermission(DBWConstants.PERMISSION_PRIVATE_PROJECT_ACCESS));
    }

    @NotNull
    protected Set<RMProjectPermission> getSharedProjectPermissions(
        @Nullable String projectId,
        @Nullable SMCredentials activeUserCredentials
    ) throws DBException {
        throw new DBException("Shared projects are not supported");
    }

    @NotNull
    @Override
    public RMProject[] listAllSharedProjects() throws DBException {
        return new RMProject[0];
    }

    @NotNull
    @Override
    public RMProject createProject(@NotNull String name, @Nullable String description) throws DBException {
        throw new DBException("Shared projects are not supported");
    }

    @NotNull
    @Override
    public RMProject updateProject(@NotNull String projectId, @NotNull RMProjectInfo projectInfo) throws DBException {
        throw new DBException("Shared projects are not supported");
    }

    @Override
    public void deleteProject(@NotNull String projectId) throws DBException {
        try (var ignoredLock = lockController.lock(LockTarget.of(projectId), LockOptions.of("deleteProject"))) {
            Path targetPath = getProjectPath(projectId);
            if (!Files.exists(targetPath)) {
                log.error(MessageFormat.format("Project folder ''{0}'' is not found", projectId));
                return;
            }
            try {
                log.debug("Deleting project '" + projectId + "' in persistence storage");
                getSecurityController().deleteObject(projectId, projectId, SMObjectType.project);
                log.debug("Deleting project '" + projectId + "' folder");
                IOUtils.deleteDirectory(targetPath);
                removeProjectRegistration(projectId);
                afterProjectDeleted(projectId);
            } catch (IOException e) {
                throw new DBException("Error deleting project '" + projectId + "'", e);
            }
        }
    }

    protected void afterProjectDeleted(@NotNull String projectId) {
        // Edition-specific project metadata can be cleaned up here.
    }

    @Nullable
    @Override
    public RMProject getProject(@NotNull String projectId, boolean readResources, boolean readProperties) throws DBException {
        RMProject project = makeProjectFromId(projectId, true);
        if (project == null) {
            return null;
        }
        if (readResources) {
            doProjectOperation(projectId, () -> {
                project.setChildren(
                    listResources(projectId, null, null, readProperties, false, true)
                );
                return null;
            });
        }
        return project;
    }

    @Override
    public void createProjectDataSources(
        @NotNull String projectId,
        @NotNull String configuration,
        @Nullable List<String> dataSourceIds
    ) throws DBException {
        super.createProjectDataSources(projectId, configuration, dataSourceIds);
        if (credentialsProvider.getActiveUserCredentials() != null && dataSourceIds != null) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDataSourceEvent.create(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    projectId,
                    dataSourceIds,
                    WSDataSourceProperty.CONFIGURATION
                )
            );
        }
    }

    @Override
    public boolean updateProjectDataSources(
        @NotNull String projectId,
        @NotNull String configuration,
        @Nullable List<String> dataSourceIds
    ) throws DBException {
        DBPDataSourceRegistry registry = getWebProject(projectId, false).getDataSourceRegistry();
        Map<String, DataSourceDescriptor> oldDataSources = registry.getDataSources().stream()
            .filter(ds -> dataSourceIds == null || dataSourceIds.contains(ds.getId()))
            .collect(Collectors.toMap(
                    DBPDataSourceContainer::getId,
                    registry::createDataSource
                )
            );
        Map<String, DBWNetworkProfile> oldNetworkProfiles = registry.getNetworkProfiles().getProfiles().stream()
            .collect(Collectors.toMap(
                DBWNetworkProfile::getProfileId,
                p -> p
            ));
        DataSourceParseResults parseResults = super.updateProjectDataSourcesConfig(projectId, configuration, dataSourceIds);
        sendConfigUpdatedEvent(registry, oldDataSources, oldNetworkProfiles, parseResults);
        return parseResults != null;
    }

    @Override
    public void deleteProjectDataSources(@NotNull String projectId, @NotNull String[] dataSourceIds) throws DBException {
        super.deleteProjectDataSources(projectId, dataSourceIds);

        log.debug("Delete datasources '" + Arrays.toString(dataSourceIds) + "' from security controller");
        for (String dsId : dataSourceIds) {
            try {
                getSecurityController().deleteObject(projectId, dsId, SMObjectType.datasource);
            } catch (DBException e) {
                log.error("Error deleting datasource '" + dsId + "' from database");
            }
        }
        if (credentialsProvider.getActiveUserCredentials() != null && dataSourceIds.length > 0) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDataSourceEvent.delete(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    projectId,
                    Arrays.asList(dataSourceIds),
                    WSDataSourceProperty.CONFIGURATION
                )
            );
        }
    }

    @Override
    public void createProjectDataSourceFolder(@NotNull String projectId, @NotNull String folderPath) throws DBException {
        super.createProjectDataSourceFolder(projectId, folderPath);
        if (credentialsProvider.getActiveUserCredentials() != null) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDatasourceFolderEvent.create(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    projectId,
                    List.of(createNodePathFromFolderPath(projectId, folderPath))
                )
            );
        }
    }

    @Override
    public void moveProjectDataSourceFolder(
        @NotNull String projectId,
        @NotNull String oldPath,
        @NotNull String newPath
    ) throws DBException {
        List<String> affectedDataSourceIds = getDataSourceIdsInFolders(projectId, List.of(oldPath));
        super.moveProjectDataSourceFolder(projectId, oldPath, newPath);
        if (credentialsProvider.getActiveUserCredentials() != null) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDatasourceFolderEvent.delete(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    projectId,
                    List.of(createNodePathFromFolderPath(projectId, oldPath))
                )
            );
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDatasourceFolderEvent.create(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    projectId,
                    List.of(createNodePathFromFolderPath(projectId, newPath))
                )
            );
            if (!affectedDataSourceIds.isEmpty()) {
                ServletAppUtils.getServletApplication().getEventController().addEvent(
                    WSDataSourceEvent.update(
                        credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                        credentialsProvider.getActiveUserCredentials().getUserId(),
                        projectId,
                        affectedDataSourceIds,
                        WSDataSourceProperty.NAVIGATION
                    )
                );
            }
        }
    }

    @Override
    public void deleteProjectDataSourceFolders(@NotNull String projectId, @NotNull String[] folderPaths, boolean dropContents)
    throws DBException {
        List<String> affectedDataSourceIds = getDataSourceIdsInFolders(projectId, Arrays.asList(folderPaths));
        super.deleteProjectDataSourceFolders(projectId, folderPaths, dropContents);
        if (credentialsProvider.getActiveUserCredentials() != null) {
            if (!affectedDataSourceIds.isEmpty()) {
                ServletAppUtils.getServletApplication().getEventController().addEvent(
                    dropContents ?
                        WSDataSourceEvent.delete(
                            credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                            credentialsProvider.getActiveUserCredentials().getUserId(),
                            projectId,
                            affectedDataSourceIds,
                            WSDataSourceProperty.CONFIGURATION
                        ) :
                        WSDataSourceEvent.update(
                            credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                            credentialsProvider.getActiveUserCredentials().getUserId(),
                            projectId,
                            affectedDataSourceIds,
                            WSDataSourceProperty.NAVIGATION
                        )
                );
            }
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDatasourceFolderEvent.delete(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    projectId,
                    Arrays.stream(folderPaths).map(
                        p -> createNodePathFromFolderPath(projectId, p)
                    ).collect(Collectors.toList())
                )
            );
        }
    }

    @NotNull
    private List<String> getDataSourceIdsInFolders(
        @NotNull String projectId,
        @NotNull Collection<String> folderPaths
    ) throws DBException {
        DBPDataSourceRegistry registry = getWebProject(projectId, false).getDataSourceRegistry();
        Set<DBPDataSourceFolder> folders = folderPaths.stream()
            .map(registry::getFolder)
            .filter(Objects::nonNull)
            .collect(Collectors.toSet());
        return registry.getDataSources().stream()
            .filter(dataSource -> {
                for (DBPDataSourceFolder folder = dataSource.getFolder(); folder != null; folder = folder.getParent()) {
                    if (folders.contains(folder)) {
                        return true;
                    }
                }
                return false;
            })
            .map(DBPDataSourceContainer::getId)
            .toList();
    }

    private String createNodePathFromFolderPath(String projectId, String folderPath) {
        return DBNLocalFolder.makeLocalFolderItemPath(projectId, folderPath);
    }

    private void sendConfigUpdatedEvent(
        @NotNull DBPDataSourceRegistry registry,
        @NotNull Map<String, DataSourceDescriptor> oldDataSources,
        @NotNull Map<String, DBWNetworkProfile> oldNetworkProfiles,
        @Nullable DataSourceParseResults parseResults
    ) {
        if (parseResults == null || credentialsProvider.getActiveUserCredentials() == null) {
            return;
        }
        boolean profilesChanged = !parseResults.removedProfiles.isEmpty();

        // We don't need to check for updated profiles if there are already added or removed profiles
        if (!profilesChanged) {
            for (DBWNetworkProfile updatedProfile : parseResults.updatedProfiles) {
                if (oldNetworkProfiles.containsKey(updatedProfile.getProfileId())) {
                    DBWNetworkProfile oldProfile = oldNetworkProfiles.get(updatedProfile.getProfileId());
                    if (!oldProfile.equalConfigurations(updatedProfile)) {
                        profilesChanged = true;
                        break;
                    }
                } else {
                    // profile was added
                    profilesChanged = true;
                    break;
                }
            }
        }

        if (profilesChanged) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSNetworkProfileEvent.update(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    registry.getProject().getId()
                )
            );
        }

        List<String> updatedConfigurationDataSourceIds = new ArrayList<>();
        List<String> updatedNameDataSourceIds = new ArrayList<>();
        List<String> updatedNavigationDataSourceIds = new ArrayList<>();
        List<String> updatedInternalConfigurationDataSourceIds = new ArrayList<>();

        for (Map.Entry<String, DataSourceDescriptor> entry : oldDataSources.entrySet()) {
            String dsId = entry.getKey();
            DataSourceDescriptor oldDs = entry.getValue();
            DataSourceDescriptor newDs = (DataSourceDescriptor) registry.getDataSource(dsId);
            if (newDs == null) {
                continue;
            }
            WSDataSourceProperty property = getChangedDataSourceProperty(oldDs, newDs);
            if (property != null) {
                switch (property) {
                    case CONFIGURATION -> updatedConfigurationDataSourceIds.add(dsId);
                    case NAME -> updatedNameDataSourceIds.add(dsId);
                    case NAVIGATION -> updatedNavigationDataSourceIds.add(dsId);
                    case INTERNAL -> updatedInternalConfigurationDataSourceIds.add(dsId);
                    default -> throw new IllegalStateException("Unsupported data source property: " + property);
                }
            }
        }

        if (!updatedConfigurationDataSourceIds.isEmpty()) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDataSourceEvent.update(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    registry.getProject().getId(),
                    updatedConfigurationDataSourceIds,
                    WSDataSourceProperty.CONFIGURATION
                )
            );
        }
        if (!updatedNameDataSourceIds.isEmpty()) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDataSourceEvent.update(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    registry.getProject().getId(),
                    updatedNameDataSourceIds,
                    WSDataSourceProperty.NAME
                )
            );
        }
        if (!updatedNavigationDataSourceIds.isEmpty()) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDataSourceEvent.update(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    registry.getProject().getId(),
                    updatedNavigationDataSourceIds,
                    WSDataSourceProperty.NAVIGATION
                )
            );
        }
        if (!updatedInternalConfigurationDataSourceIds.isEmpty()) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDataSourceEvent.update(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    registry.getProject().getId(),
                    updatedInternalConfigurationDataSourceIds,
                    WSDataSourceProperty.INTERNAL
                )
            );
        }

        if (!parseResults.addedDataSources.isEmpty()) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDataSourceEvent.create(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    registry.getProject().getId(),
                    parseResults.addedDataSources.stream().map(DBPDataSourceContainer::getId).toList(),
                    WSDataSourceProperty.CONFIGURATION
                )
            );
        }

        if (!parseResults.removedDataSources.isEmpty()) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDataSourceEvent.delete(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    registry.getProject().getId(),
                    parseResults.removedDataSources.stream().map(DBPDataSourceContainer::getId).toList(),
                    WSDataSourceProperty.CONFIGURATION
                )
            );
        }

        if (!parseResults.addedFolders.isEmpty()) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDatasourceFolderEvent.create(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    registry.getProject().getId(),
                    parseResults.addedFolders.stream().map(
                        f -> createNodePathFromFolderPath(registry.getProject().getId(), f.getFolderPath())
                    ).toList()
                )
            );
        }

        if (!parseResults.removedFolders.isEmpty()) {
            ServletAppUtils.getServletApplication().getEventController().addEvent(
                WSDatasourceFolderEvent.delete(
                    credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                    credentialsProvider.getActiveUserCredentials().getUserId(),
                    registry.getProject().getId(),
                    parseResults.removedFolders.stream().map(
                        f -> createNodePathFromFolderPath(registry.getProject().getId(), f.getFolderPath())
                    ).toList()
                )
            );
        }
    }

    @Nullable
    public static WSDataSourceProperty getChangedDataSourceProperty(
        @NotNull DataSourceDescriptor oldDataSource,
        @NotNull DataSourceDescriptor newDataSource
    ) {
        if (!oldDataSource.equalConfiguration(newDataSource)) {
            return WSDataSourceProperty.CONFIGURATION;
        }
        if (!oldDataSource.isLooselyEqualTo(newDataSource)) {
            return WSDataSourceProperty.NAME;
        }
        if (!oldDataSource.equalNavigation(newDataSource)) {
            return WSDataSourceProperty.NAVIGATION;
        }
        if (!oldDataSource.equalInternalConfiguration(newDataSource)) {
            return WSDataSourceProperty.INTERNAL;
        }
        return null;
    }

    @NotNull
    @Override
    public RMResource[] listResources(
        @NotNull String projectId,
        @Nullable String folder,
        @Nullable String nameMask,
        boolean readProperties,
        boolean readHistory,
        boolean recursive
    ) throws DBException {
        Path projectPath = getProjectPath(projectId);
        if (!Files.exists(projectPath)) {
            return new RMResource[0];
        }
        return doProjectOperation(projectId, () -> {
            try {
                boolean projectFolder = CommonUtils.isEmpty(folder);
                Path folderPath = projectFolder ?
                    projectPath :
                    projectPath.resolve(folder);
                folderPath = folderPath.normalize();
                // Test that folder is inside the project
                if (!folderPath.startsWith(projectPath)) {
                    throw new DBException("Invalid folder path");
                }
                createFolder(folderPath);
                return readChildResources(projectId, folderPath, nameMask, projectFolder, readProperties, readHistory, recursive);
            } catch (NoSuchFileException e) {
                throw new DBException("Invalid resource folder " + folder);
            } catch (IOException e) {
                throw new DBException("Error reading resources", e);
            }
        });
    }

    @NotNull
    private RMResource[] readChildResources(
        @NotNull String projectId,
        @NotNull Path folderPath,
        @Nullable String nameMask,
        boolean projectFolder,
        boolean readProperties,
        boolean readHistory,
        boolean recursive
    ) throws IOException {
        try (Stream<Path> files = Files.list(folderPath)) {
            Set<RMResource> children = files.filter(path -> {
                    String fileName = path.getFileName().toString();
                    return (nameMask == null || nameMask.equals(fileName)) && !fileName.startsWith(".");
                }) // skip hidden files
                .map((Path path) -> makeResourceFromPath(projectId, path, nameMask, readProperties, readHistory, recursive))
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
            if (ServletAppUtils.getServletApplication().isMultiNode() && projectFolder) {
                addResourceTypeFolders(folderPath, children);
            }
            return children.stream()
                .sorted(Comparator.comparing(RMResource::getName, String.CASE_INSENSITIVE_ORDER))
                .toArray(RMResource[]::new);
        }
    }

    private void addResourceTypeFolders(@NotNull Path projectPath, @NotNull Set<RMResource> children) {
        Set<String> folderNames = children.stream()
            .filter(RMResource::isFolder)
            .map(RMResource::getName)
            .collect(Collectors.toSet());
        // fake resources for default resource type folders
        for (ResourceTypeDescriptor type : ResourceTypeRegistry.getInstance().getResourceTypes()) {
            String defaultRoot = type.getDefaultRoot(null);
            if (CommonUtils.isEmpty(defaultRoot)) {
                continue;
            }
            Path resourceFolder = projectPath.resolve(defaultRoot);
            if (!folderNames.contains(resourceFolder.getFileName().toString())) {
                RMResource resource = new RMResource(resourceFolder.getFileName().toString());
                resource.setFolder(true);
                children.add(resource);
            }
        }
    }

    @Override
    public String createResource(
        @NotNull String projectId,
        @NotNull String resourcePath,
        boolean isFolder
    ) throws DBException {
        try (var ignoredLock = lockController.lock(LockTarget.of(projectId), LockOptions.of("createResource"))) {
            validateResourcePath(resourcePath);
            Path targetPath = getTargetPath(projectId, resourcePath);
            if (Files.exists(targetPath)) {
                throw new DBException("Resource '" + resourcePath + "' already exists");
            }
            log.debug("Creating resource '" + resourcePath + "' in project '" + projectId + "'");
            createFolder(targetPath.getParent());
            doFileWriteOperation(projectId, targetPath, () -> {
                try {
                    if (isFolder) {
                        Files.createDirectories(targetPath);
                    } else {
                        Files.createFile(targetPath);
                    }
                } catch (IOException e) {
                    throw new DBException("Error creating resource '" + resourcePath + "'", e);
                }
                return null;
            });
            fireRmResourceAddEvent(projectId, resourcePath);
        }
        return DEFAULT_CHANGE_ID;
    }


    @Override
    public String moveResource(
        @NotNull String projectId,
        @NotNull String oldResourcePath,
        @NotNull String newResourcePath
    ) throws DBException {
        try (var ignoredLock = lockController.lock(LockTarget.of(projectId), LockOptions.of("moveResource"))) {
            var normalizedOldResourcePath = CommonUtils.normalizeResourcePath(oldResourcePath);
            var normalizedNewResourcePath = CommonUtils.normalizeResourcePath(newResourcePath);
            if (log.isDebugEnabled()) {
                log.debug("Moving resource from '" + normalizedOldResourcePath + "' to '" + normalizedNewResourcePath +
                    "' in project '" + projectId + "'");
            }
            Path oldTargetPath = getTargetPath(projectId, normalizedOldResourcePath);

            doFileWriteOperation(projectId, oldTargetPath, () -> {
                if (!Files.exists(oldTargetPath)) {
                    throw new DBException("Resource '" + oldTargetPath + "' doesn't exists");
                }
                Path newTargetPath = getTargetPath(projectId, normalizedNewResourcePath);
                validateResourcePath(rootPath.relativize(newTargetPath).toString());
                if (Files.exists(newTargetPath)) {
                    throw new DBException("Resource with name %s already exists".formatted(newTargetPath.getFileName()));
                }
                if (!Files.exists(newTargetPath.getParent())) {
                    throw new DBException("Resource %s doesn't exists".formatted(newTargetPath.getParent().getFileName()));
                }
                try {
                    Files.move(oldTargetPath, newTargetPath);
                } catch (IOException e) {
                    throw new DBException("Error moving resource '" + normalizedOldResourcePath + "'", e);
                }

                log.debug("Moving resource properties");
                try {
                    movePropertiesRecursive(projectId, newTargetPath, normalizedOldResourcePath, normalizedNewResourcePath);
                } catch (IOException | DBException e) {
                    throw new DBException("Unable to move resource properties", e);
                }
                return null;
            });

            fireRmResourceDeleteEvent(projectId, normalizedOldResourcePath);
            fireRmResourceAddEvent(projectId, normalizedNewResourcePath);
        }

        return DEFAULT_CHANGE_ID;
    }

    /**
     * Iterates the tree starting at {@code rootResourcePath}.
     * Calculates for each file/folder {@code newResourcePropertiesPath} and restores {@code oldResourcePropertiesPath}
     * by replacing the first {@code newRootPropertiesPath} with {@code oldRootPropertiesPath} in {@code newResourcePropertiesPath}.
     * Gathers the old-new properties paths pairs and updates properties via BaseProjectImpl#moveResourcePropertiesBatch()
     */
    private void movePropertiesRecursive(
        @NotNull String projectId,
        @NotNull Path rootResourcePath,
        @NotNull String oldRootPropertiesPath,
        @NotNull String newRootPropertiesPath
    ) throws IOException, DBException {
        var project = getWebProject(projectId, false);
        var projectPath = getProjectPath(projectId);
        var propertiesPathsList = new ArrayList<Pair<String, String>>();
        Files.walkFileTree(rootResourcePath, (UniversalFileVisitor<Path>) (path, attrs) -> {
            var newResourcePropertiesPath = CommonUtils.normalizeResourcePath(projectPath.relativize(path.toAbsolutePath()).toString());
            var oldResourcePropertiesPath = newResourcePropertiesPath.replaceFirst(newRootPropertiesPath, oldRootPropertiesPath);
            propertiesPathsList.add(new Pair<>(oldResourcePropertiesPath, newResourcePropertiesPath));
            return FileVisitResult.CONTINUE;
        });
        if (log.isDebugEnabled()) {
            log.debug("Move resources properties:\n" + propertiesPathsList);
        }
        project.moveResourcePropertiesBatch(propertiesPathsList);
    }

    @Override
    public void deleteResource(@NotNull String projectId, @NotNull String resourcePath, boolean recursive) throws DBException {
        try (var ignoredLock = lockController.lock(LockTarget.of(projectId), LockOptions.of("deleteResource"))) {
            if (log.isDebugEnabled()) {
                log.debug("Removing resource from '" + resourcePath + "' in project '" + projectId + "'" + (recursive ? " recursive" : ""));
            }
            Path targetPath = getTargetPath(projectId, resourcePath);
            doFileWriteOperation(projectId, targetPath, () -> {
                if (!Files.exists(targetPath)) {
                    throw new DBException("Resource '" + resourcePath + "' doesn't exists");
                }
                Collection<String> propertiesToRemove = List.of();
                try {
                    if (recursive) {
                        propertiesToRemove = getPropertiesToRemove(projectId, targetPath);
                    } else {
                        propertiesToRemove = List.of(resourcePath);
                    }
                } catch (IOException | DBException e) {
                    log.warn("Failed to remove resources properties", e);
                }
                try {
                    if (Files.isDirectory(targetPath)) {
                        IOUtils.deleteDirectory(targetPath);
                    } else {
                        Files.delete(targetPath);
                    }
                } catch (IOException e) {
                    throw new DBException("Error deleting resource '" + resourcePath + "'", e);
                }
                if (log.isDebugEnabled()) {
                    log.debug("Remove resources properties:\n" + propertiesToRemove);
                }
                getWebProject(projectId, false)
                    .resetResourcesPropertiesBatch(propertiesToRemove);
                return null;
            });

            log.debug("Fire resource delete event");
            fireRmResourceDeleteEvent(projectId, resourcePath);
        }
    }

    private Collection<String> getPropertiesToRemove(@NotNull String projectId, @NotNull Path targetPath) throws DBException, IOException {
        var projectPath = getProjectPath(projectId);
        var propertiesToRemove = new ArrayList<String>();
        Files.walkFileTree(targetPath, (UniversalFileVisitor<Path>) (path, attrs) -> {
            var resourcePropertiesPath = projectPath.relativize(path.toAbsolutePath());
            propertiesToRemove.add(CommonUtils.normalizeResourcePath(resourcePropertiesPath.toString()));
            return FileVisitResult.CONTINUE;
        });
        return propertiesToRemove;
    }

    @Override
    public RMResource[] getResourcePath(@NotNull String projectId, @NotNull String resourcePath) throws DBException {
        return makeResourcePath(projectId, getTargetPath(projectId, resourcePath), false).toArray(RMResource[]::new);
    }

    @Nullable
    @Override
    public RMResource getResource(@NotNull String projectId, @NotNull String resourcePath) throws DBException {
        return makeResourceFromPath(projectId, getTargetPath(projectId, resourcePath), null, false, false, false);
    }

    @NotNull
    @Override
    public byte[] getResourceContents(@NotNull String projectId, @NotNull String resourcePath) throws DBException {
        validateResourcePath(resourcePath);
        Path targetPath = getTargetPath(projectId, resourcePath);
        if (!Files.exists(targetPath)) {
            throw new DBException("Resource '" + resourcePath + "' doesn't exists");
        }
        return doFileReadOperation(projectId, targetPath, () -> {
            try {
                return Files.readAllBytes(targetPath);
            } catch (IOException e) {
                throw new DBException("Error reading resource '" + resourcePath + "'", e);
            }
        });
    }

    @NotNull
    @Override
    public String setResourceContents(
        @NotNull String projectId,
        @NotNull String resourcePath,
        @NotNull byte[] data,
        boolean forceOverwrite
    ) throws DBException {
        try (var ignoredLock = lockController.lock(LockTarget.of(projectId), LockOptions.of("setResourceContents"))) {
            validateResourcePath(resourcePath);
            Number fileSizeLimit = ServletAppUtils.getServletApplication()
                .getAppConfiguration()
                .getResourceQuota(WebSQLConstants.QUOTA_PROP_RM_FILE_SIZE_LIMIT);
            if (fileSizeLimit != null && data.length > fileSizeLimit.longValue()) {
                throw new DBQuotaException(
                    "File size quota exceeded",
                    WebSQLConstants.QUOTA_PROP_RM_FILE_SIZE_LIMIT,
                    fileSizeLimit.longValue(),
                    data.length
                );
            }
            Path targetPath = getTargetPath(projectId, resourcePath);
            if (!forceOverwrite && Files.exists(targetPath)) {
                throw new DBException("Resource '" + IOUtils.getFileNameWithoutExtension(targetPath) + "' already exists");
            }

            doFileWriteOperation(projectId, targetPath, () -> {
                createFolder(targetPath.getParent());
                try {
                    log.debug("Writing data to resource '" + targetPath + " in project " + projectId + "'");
                    Files.write(targetPath, data);
                } catch (IOException e) {
                    throw new DBException("Error writing resource '" + resourcePath + "'", e);
                }
                return null;
            });

            if (!forceOverwrite) {
                fireRmResourceAddEvent(projectId, resourcePath);
            }
        }
        return DEFAULT_CHANGE_ID;
    }


    @NotNull
    @Override
    public String setResourceProperty(
        @NotNull String projectId,
        @NotNull String resourcePath,
        @NotNull String propertyName,
        @Nullable String propertyValue
    ) throws DBException {
        try (var ignoredLock = lockController.lock(LockTarget.of(projectId), LockOptions.of("resourcePropertyUpdate"))) {
            validateResourcePath(resourcePath);
            RMLocalProject webProject = getWebProject(projectId, false);
            doFileWriteOperation(projectId, webProject.getMetadataFilePath(),
                () -> {
                    log.debug("Updating resource property '" + propertyName + "' in project '" + projectId + "'");
                    webProject.setResourceProperty(resourcePath, propertyName, propertyValue);
                    return null;
                }
            );
            return DEFAULT_CHANGE_ID;
        }
    }

    @NotNull
    @Override
    public String setResourceProperties(
        @NotNull String projectId,
        @NotNull String resourcePath,
        @NotNull Map<String, String> properties
    ) throws DBException {
        try (var ignoredLock = lockController.lock(LockTarget.of(projectId), LockOptions.of("resourcePropertyUpdate"))) {
            validateResourcePath(resourcePath);
            RMLocalProject webProject = getWebProject(projectId, false);
            doFileWriteOperation(projectId, webProject.getMetadataFilePath(),
                () -> {
                    log.debug("Updating resource '" + resourcePath + "' properties in project '" + projectId + "'");
                    webProject.setResourceProperties(resourcePath, properties);
                    return null;
                }
            );
            return DEFAULT_CHANGE_ID;
        }
    }

    @NotNull
    private Path getTargetPath(@NotNull String projectId, @NotNull String resourcePath) throws DBException {
        Path projectPath = getProjectPath(projectId);
        if (!Files.exists(projectPath)) {
            try {
                Files.createDirectories(projectPath);
            } catch (IOException e) {
                throw new DBException("Error creating project path", e);
            }
        }
        try {
            while (resourcePath.startsWith("/")) resourcePath = resourcePath.substring(1);
            Path targetPath = projectPath.resolve(resourcePath).normalize();
            // hack for custom path implementations that returns / as root path
            Iterator<Path> projectParts = projectPath.iterator();
            Iterator<Path> targetParts = targetPath.iterator();
            Iterator<Path> unnormalizedTargetParts = projectPath.resolve(resourcePath).iterator();
            while (projectParts.hasNext()) {
                if (!targetParts.hasNext()) {
                    throw new DBException("Invalid resource path");
                }
                Path projectPart = projectParts.next();
                Path targetPart = targetParts.next();
                unnormalizedTargetParts.next();
                if (!projectPart.equals(targetPart)) {
                    throw new DBException("Invalid resource path");
                }
            }
            // validating unnormalized target parts to avoid invalid characters in resource names
            while (unnormalizedTargetParts.hasNext()) {
                GeneralUtils.validateResourceNameUnconditionally(unnormalizedTargetParts.next().toString());
            }
            return targetPath;
        } catch (InvalidPathException e) {
            throw new DBException("Resource path contains invalid characters");
        }
    }

    @Nullable
    protected RMProject makeProjectFromId(@NotNull String projectId, boolean loadPermissions) throws DBException {
        var projectName = WebRMUtils.parseProjectName(projectId);
        var projectPath = getProjectPath(projectId);
        if (!Files.exists(projectPath)) {
            if (isPrivateProject(projectId) && isProjectOwner(projectId)) {
                try {
                    Files.createDirectories(projectPath);
                } catch (Exception e) {
                    throw new DBException("Failed to create project " + projectId + ": " + e.getMessage(), e);
                }
            } else {
                return null;
            }
        }
        Set<RMProjectPermission> permissions = Set.of();
        if (loadPermissions && credentialsProvider.getActiveUserCredentials() != null) {
            permissions = getProjectPermissions(projectId, projectName.getType());
        }
        return makeProjectFromPath(projectPath, permissions, projectName.getType(), false);
    }

    @Nullable
    protected RMProject makeProjectFromPath(
        @Nullable Path path,
        @NotNull Set<RMProjectPermission> permissions,
        @NotNull RMProjectType type,
        boolean checkExistence
    ) {
        if (path == null) {
            return null;
        }
        if (Files.exists(path)) {
            if (!Files.isDirectory(path)) {
                log.error("Project path " + path + " is not a directory");
                return null;
            }
        } else if (checkExistence) {
            return null;
        }

        String[] allProjectPermissions = permissions.stream()
            .flatMap(rmProjectPermission -> rmProjectPermission.getAllPermissions().stream())
            .toArray(String[]::new);

        RMLocalProject webProject = new RMLocalProject(workspace, new SessionContextImpl(null), path, type);
        loadProjectInfo(webProject);
        return createRmProjectFromWebProject(path, webProject, allProjectPermissions);
    }

    protected void loadProjectInfo(@NotNull RMLocalProject project) {
        // Shared project metadata is supplied by editions that support shared projects.
    }

    protected void removeProjectRegistration(@NotNull String projectId) {
        synchronized (projectRegistries) {
            projectRegistries.remove(projectId);
        }
    }

    protected <T> T doProjectOperation(@NotNull String projectId, @NotNull RMFileOperation<T> operation) throws DBException {
        for (RMFileOperationHandler fileHandler : fileHandlers) {
            try {
                fileHandler.projectOpened(projectId);
            } catch (Exception e) {
                if (credentialsProvider.getActiveUserCredentials() != null) {
                    ServletAppUtils.getServletApplication().getEventController().addEvent(
                        new WSSessionLogUpdatedEvent(
                            credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                            credentialsProvider.getActiveUserCredentials().getUserId(),
                            MessageType.ERROR,
                            e.getMessage()));
                }
            }
        }
        return operation.doOperation();
    }

    protected <T> T doFileReadOperation(@NotNull String projectId, @NotNull Path file, @NotNull RMFileOperation<T> operation) throws DBException {
        for (RMFileOperationHandler fileHandler : fileHandlers) {
            try {
                fileHandler.beforeFileRead(projectId, file);
            } catch (Exception e) {
                if (credentialsProvider.getActiveUserCredentials() != null) {
                    ServletAppUtils.getServletApplication().getEventController().addEvent(
                        new WSSessionLogUpdatedEvent(
                            credentialsProvider.getActiveUserCredentials().getSmSessionId(),
                            credentialsProvider.getActiveUserCredentials().getUserId(),
                            MessageType.ERROR,
                            e.getMessage()));
                }
                log.error("Error before file reading", e);
            }
        }
        return operation.doOperation();
    }

    protected <T> T doFileWriteOperation(
        @NotNull String projectId,
        @NotNull Path file,
        @NotNull RMFileOperation<T> operation
    ) throws DBException {
        for (RMFileOperationHandler fileHandler : fileHandlers) {
            fileHandler.beforeFileChange(projectId, file);
        }
        T result;
        try {
            result = operation.doOperation();
        } catch (Exception e) {
            for (RMFileOperationHandler fileHandler : fileHandlers) {
                fileHandler.handleFileChangeException(projectId, file, e);
            }
            throw e;
        }
        for (RMFileOperationHandler fileHandler : fileHandlers) {
            fileHandler.afterFileChange(projectId, file, credentialsProvider.getActiveUserCredentials());
        }
        return result;
    }

    @NotNull
    protected Path getProjectPath(@NotNull String projectId) throws DBException {
        RMProjectName project = WebRMUtils.parseProjectName(projectId);
        RMProjectType type = project.getType();
        String projectName = project.getName();
        GeneralUtils.validateResourceNameUnconditionally(projectName);
        switch (type) {
            case GLOBAL:
                if (!projectName.equals(globalProjectName)) {
                    throw new DBException("Invalid global project name '" + projectName + "'");
                }
                return getGlobalProjectPath();
            case SHARED:
                return getSharedProjectPath(projectName);
            case USER:
                var activeUserCredentials = credentialsProvider.getActiveUserCredentials();
                var userId = activeUserCredentials == null ? null : activeUserCredentials.getUserId();
                var isAdmin = activeUserCredentials != null && activeUserCredentials.hasPermission(DBWConstants.PERMISSION_ADMIN);
                if (!(projectName.equals(userId) || isAdmin)) {
                    throw new DBException("No access to the project: " + projectName);
                }
                return userProjectsPath.resolve(projectName);
            default:
                throw new DBException("Invalid project type [" + type + "]");
        }
    }

    @NotNull
    protected Path getSharedProjectPath(@NotNull String projectName) throws DBException {
        throw new DBException("Shared projects are not supported");
    }

    private @NotNull List<RMResource> makeResourcePath(@NotNull String projectId, @NotNull Path targetPath, boolean recursive) throws DBException {
        var projectPath = getProjectPath(projectId);
        var relativeResourcePath = projectPath.relativize(targetPath.toAbsolutePath());
        var resourcePath = projectPath;

        var result = new ArrayList<RMResource>();

        for (var resourceName : relativeResourcePath) {
            resourcePath = resourcePath.resolve(resourceName);
            result.add(makeResourceFromPath(projectId, resourcePath, null, false, false, recursive));
        }

        return result;
    }

    private RMResource makeResourceFromPath(
        @NotNull String projectId,
        @NotNull Path path,
        @Nullable String nameMask,
        boolean readProperties,
        boolean readHistory,
        boolean recursive
    ) {
        if (Files.notExists(path)) {
            return null;
        }
        RMResource resource = new RMResource();
        resource.setName(path.getFileName().toString());
        resource.setFolder(Files.isDirectory(path));
        if (!resource.isFolder()) {
            try {
                resource.setLastModified(
                    Files.getLastModifiedTime(path).toMillis());
            } catch (IOException e) {
                log.debug("Error getting last modified time: " + e.getMessage());
            }
        }
        try {
            if (!resource.isFolder()) {
                resource.setLength(Files.size(path));
            }
            if (readHistory) {
                resource.setChanges(
                    Collections.singletonList(
                        new RMResourceChange(
                            DEFAULT_CHANGE_ID,
                            new Date(Files.getLastModifiedTime(path).toMillis()),
                            null
                        ))
                );
            }
            if (readProperties) {
                final BaseProjectImpl project = getWebProject(projectId, true);
                final String resourcePath = getProjectRelativePath(projectId, path);
                final Map<String, String> properties = project.getResourceProperties(resourcePath);

                if (properties != null && !properties.isEmpty()) {
                    resource.setProperties(new LinkedHashMap<>(properties));
                }
            }
        } catch (Exception e) {
            log.error(e);
        }

        if (recursive && resource.isFolder()) {
            try {
                resource.setChildren(readChildResources(projectId, path, nameMask, false, readProperties, readHistory, true));
            } catch (IOException e) {
                log.error(e);
            }
        }

        return resource;
    }

    @NotNull
    private String getProjectRelativePath(@NotNull String projectId, @NotNull Path path) throws DBException {
        return getProjectPath(projectId).toAbsolutePath().relativize(path).toString().replace('\\', IPath.SEPARATOR);
    }

    @NotNull
    public static Builder builder(
        @NotNull SMCredentialsProvider credentialsProvider,
        @NotNull DBPWorkspace workspace,
        @NotNull LockManager lockController,
        @NotNull Supplier<SMAdminController> smControllerSupplier
    ) {
        return new Builder(workspace, credentialsProvider, lockController, smControllerSupplier);
    }

    @Override
    public String ping() {
        return "pong (RM)";
    }

    public static class Builder {
        protected final SMCredentialsProvider credentialsProvider;
        protected final Supplier<SMAdminController> smController;
        protected final DBPWorkspace workspace;

        protected Path rootPath;
        protected Path userProjectsPath;
        protected Path sharedProjectsPath;
        protected LockManager lockController;

        protected Builder(
            @NotNull DBPWorkspace workspace,
            @NotNull SMCredentialsProvider credentialsProvider,
            @NotNull LockManager lockController,
            @NotNull Supplier<SMAdminController> smControllerSupplier
        ) {
            this.workspace = workspace;
            this.credentialsProvider = credentialsProvider;
            this.smController = smControllerSupplier;
            this.rootPath = RMUtils.getRootPath();
            this.userProjectsPath = RMUtils.getUserProjectsPath();
            this.sharedProjectsPath = RMUtils.getSharedProjectsPath();
            this.lockController = lockController;
        }

        @NotNull
        public Builder setRootPath(@NotNull Path rootPath) {
            this.rootPath = rootPath;
            return this;
        }

        @NotNull
        public Builder setUserProjectsPath(@NotNull Path userProjectsPath) {
            this.userProjectsPath = userProjectsPath;
            return this;
        }

        @NotNull
        public Builder setSharedProjectsPath(@NotNull Path sharedProjectsPath) {
            this.sharedProjectsPath = sharedProjectsPath;
            return this;
        }

        @NotNull
        public LocalResourceController build() throws DBException {
            return new LocalResourceController(
                workspace,
                credentialsProvider,
                rootPath,
                userProjectsPath,
                sharedProjectsPath,
                smController,
                lockController
            );
        }
    }

    public static boolean isGlobalProject(String projectId) {
        RMProjectName rmProjectName = WebRMUtils.parseProjectNameUnsafe(projectId);
        return RMProjectType.GLOBAL.getPrefix().equals(rmProjectName.getPrefix());
    }

    public static boolean isPrivateProject(String projectId) {
        RMProjectName rmProjectName = WebRMUtils.parseProjectNameUnsafe(projectId);
        return RMProjectType.USER.getPrefix().equals(rmProjectName.getPrefix());
    }

    private boolean isProjectOwner(String projectId) {
        var activeUserCredentials = credentialsProvider.getActiveUserCredentials();
        var userId = activeUserCredentials == null ? null : activeUserCredentials.getUserId();
        return isProjectOwner(projectId, userId);
    }

    public static boolean isProjectOwner(String projectId, String userId) {
        RMProjectName rmProjectName = WebRMUtils.parseProjectNameUnsafe(projectId);
        return RMProjectType.USER.getPrefix().equals(rmProjectName.getPrefix()) &&
            rmProjectName.name.equals(userId);
    }

    @NotNull
    protected static RMProject createRmProjectFromWebProject(Path path, RMLocalProject webProject, String[] allProjectPermissions) {
        RMProject project = WebRMUtils.createRmProjectFromWebProject(webProject);
        project.setProjectPermissions(allProjectPermissions);
        if (Files.exists(path)) {
            try {
                project.setCreateTime(
                    OffsetDateTime.ofInstant(Files.getLastModifiedTime(path).toInstant(), ZoneId.of("UTC")).toInstant().toEpochMilli());
            } catch (IOException e) {
                log.error(e);
            }
        }
        // Resource types
        project.setResourceTypes(ResourceTypeRegistry.getInstance().getResourceTypes()
            .stream()
            .filter(ResourceTypeDescriptor::isManageable)
            .map(RMResourceType::new)
            .toArray(RMResourceType[]::new));

        return project;
    }


}
