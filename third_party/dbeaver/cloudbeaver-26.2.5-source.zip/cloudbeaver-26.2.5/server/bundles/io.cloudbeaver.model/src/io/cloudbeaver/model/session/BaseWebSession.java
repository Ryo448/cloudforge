/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.model.session;

import io.cloudbeaver.model.WebServerMessage;
import io.cloudbeaver.model.app.ServletApplication;
import io.cloudbeaver.model.app.ServletAuthApplication;
import io.cloudbeaver.websocket.CBWebSessionEventHandler;
import org.jkiss.code.NotNull;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.auth.SMAuthInfo;
import org.jkiss.dbeaver.model.auth.SMAuthSpace;
import org.jkiss.dbeaver.model.auth.SMSessionContext;
import org.jkiss.dbeaver.model.auth.impl.AbstractSessionPersistent;
import org.jkiss.dbeaver.model.meta.Property;
import org.jkiss.dbeaver.model.rm.RMProjectInfo;
import org.jkiss.dbeaver.model.security.user.SMTeam;
import org.jkiss.dbeaver.model.websocket.event.WSEvent;
import org.jkiss.dbeaver.model.websocket.event.WSEventDeleteTempFile;
import org.jkiss.dbeaver.model.websocket.event.session.WSSessionExpiredEvent;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Base CB web session
 */
public abstract class BaseWebSession extends AbstractSessionPersistent {
    private static final Log log = Log.getLog(BaseWebSession.class);

    @NotNull
    protected final String id;
    protected final long createTime;
    @NotNull
    protected final WebUserContext userContext;
    @NotNull
    protected final ServletApplication application;
    protected volatile long lastAccessTime;
    @NotNull
    private final SessionType sessionType;

    private final List<CBWebSessionEventHandler> sessionEventHandlers = new CopyOnWriteArrayList<>();
    private WebSessionEventsFilter eventsFilter;
    private final WebSessionWorkspace workspace;

    public BaseWebSession(
        @NotNull String id,
        @NotNull ServletApplication application,
        @NotNull SessionType sessionType
    ) throws DBException {
        this.id = id;
        this.application = application;
        this.sessionType = sessionType;
        this.createTime = System.currentTimeMillis();
        this.lastAccessTime = this.createTime;
        this.workspace = createWebWorkspace();
        this.workspace.getAuthContext().addSession(this);
        this.userContext = createUserContext();
        this.eventsFilter = new WebSessionEventsFilter(this);
    }

    @NotNull
    protected WebSessionWorkspace createWebWorkspace() {
        return new WebSessionWorkspace(this);
    }

    protected WebUserContext createUserContext() throws DBException {
        return new WebUserContext(this.application, this.workspace);
    }

    @NotNull
    public WebSessionWorkspace getWorkspace() {
        return workspace;
    }

    public void addSessionEvent(WSEvent event) {
        boolean eventAllowedByFilter = eventsFilter.isEventAllowed(event);
        if (!eventAllowedByFilter) {
            return;
        }
        synchronized (sessionEventHandlers) {
            for (CBWebSessionEventHandler eventHandler : sessionEventHandlers) {
                try {
                    eventHandler.handleWebSessionEvent(event);
                } catch (DBException e) {
                    log.error(e.getMessage(), e);
                    addSessionError(e);
                }
            }
        }
    }

    public abstract void addSessionError(@NotNull Throwable exception);

    public void addEventHandler(@NotNull CBWebSessionEventHandler handler) {
        synchronized (sessionEventHandlers) {
            sessionEventHandlers.add(handler);
        }
    }

    public void removeEventHandler(@NotNull CBWebSessionEventHandler handler) {
        synchronized (sessionEventHandlers) {
            sessionEventHandlers.remove(handler);
        }
    }

    public void migrateEventHandlersTo(@NotNull BaseWebSession target) {
        synchronized (sessionEventHandlers) {
            for (CBWebSessionEventHandler handler : sessionEventHandlers) {
                handler.migrateToSession(target);
                target.addEventHandler(handler);
            }
            sessionEventHandlers.clear();
        }
    }

    public boolean updateSMSession(SMAuthInfo smAuthInfo) throws DBException {
        return userContext.refresh(smAuthInfo);
    }

    public void refreshUserData() {
        try {
            userContext.refreshPermissions();
            if (userContext.isAuthorizedInSecurityManager()) {
                userContext.refreshAccessibleProjects();
                if (userContext.getUser() != null) {
                    List<String> userTeamIds = Arrays.stream(userContext.getSecurityController().getCurrentUserTeams())
                        .map(SMTeam::getTeamId)
                        .toList();
                    userContext.getUser().setTeams(userTeamIds.toArray(new String[0]));
                }
            }
        } catch (DBException e) {
            addSessionError(e);
            log.error("Error refreshing accessible projects", e);
        }
    }

    /**
     * Refreshes user permissions, teams and accessible projects.
     * <p>
     * Unlike {@link #refreshUserData()} this method must not re-create heavyweight session state
     * (navigator model, session projects, connection caches), so it is safe to call
     * for foreign sessions on server-wide events.
     */
    public void refreshUserPermissions() {
        refreshUserData();
    }

    @NotNull
    @Override
    public SMAuthSpace getSessionSpace() {
        return workspace;
    }

    @NotNull
    @Override
    public SMSessionContext getSessionContext() {
        return workspace.getAuthContext();
    }

    protected synchronized void clearSessionContext() {
        this.workspace.getAuthContext().clearContext(false);
        this.workspace.getAuthContext().addSession(this);
    }

    @NotNull
    @Property
    public String getSessionId() {
        return id;
    }

    @NotNull
    public ServletApplication getApplication() {
        return application;
    }

    @NotNull
    @Override
    public LocalDateTime getSessionStart() {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(createTime), ZoneId.systemDefault());
    }

    public long getLastAccessTimeMillis() {
        return lastAccessTime;
    }

    @NotNull
    public SessionType getSessionType() {
        return sessionType;
    }

    public void touchSession() {
        this.lastAccessTime = System.currentTimeMillis();
    }

    @NotNull
    public WebUserContext getUserContext() {
        return userContext;
    }

    @Override
    public void close() {
        cleanUpSession(true);
        super.close();
    }

    public void close(boolean clearTokens, boolean sendSessionExpiredEvent) {
        cleanUpSession(sendSessionExpiredEvent);
        super.close();
    }

    private void cleanUpSession(boolean sendSessionExpiredEvent) {
        application.getEventController().addEvent(new WSEventDeleteTempFile(getUserContext().getSmSessionId()));
        synchronized (sessionEventHandlers) {
            var sessionExpiredEvent = new WSSessionExpiredEvent();
            for (CBWebSessionEventHandler sessionEventHandler : sessionEventHandlers) {
                if (sendSessionExpiredEvent) {
                    try {
                        sessionEventHandler.handleWebSessionEvent(sessionExpiredEvent);
                    } catch (DBException e) {
                        log.warn("Failed to send session expiration event", e);
                    }
                }
                sessionEventHandler.close();
            }
            sessionEventHandlers.clear();

            workspace.dispose();

            clearSessionContext();
        }
    }

    @NotNull
    public WebSessionEventsFilter getEventsFilter() {
        return eventsFilter;
    }

    public void setEventsFilter(@NotNull WebSessionEventsFilter eventsFilter) {
        this.eventsFilter = eventsFilter;
    }

    public boolean isProjectAccessible(@NotNull String projectId) {
        return userContext.getAccessibleProjectIds().contains(projectId);
    }

    public void addSessionProject(@NotNull String projectId) throws DBException {
        userContext.getAccessibleProjectIds().add(projectId);
    }

    public void updateSessionProject(@NotNull String projectId, @NotNull RMProjectInfo rmProjectInfo) throws DBException {

    }


    public void removeSessionProject(@NotNull String projectId) throws DBException {
        userContext.getAccessibleProjectIds().remove(projectId);
    }

    public abstract void addSessionMessage(@NotNull WebServerMessage message);

    @Property
    public boolean isValid() {
        return getRemainingTime() > 0;
    }

    @Property
    public long getRemainingTime() {
        if (application instanceof ServletAuthApplication authApplication) {
            return getMaxSessionIdleTime(authApplication) + lastAccessTime - System.currentTimeMillis();
        }
        return Integer.MAX_VALUE;
    }

    protected long getMaxSessionIdleTime(@NotNull ServletAuthApplication authApplication) {
        return authApplication.getMaxSessionIdleTime();
    }
}
