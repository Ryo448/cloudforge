/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.model.session;

import io.cloudbeaver.*;
import io.cloudbeaver.model.*;
import io.cloudbeaver.model.app.ServletApplication;
import io.cloudbeaver.model.app.ServletAuthApplication;
import io.cloudbeaver.model.session.monitor.TaskProgressMonitor;
import io.cloudbeaver.model.user.WebUser;
import io.cloudbeaver.service.DBWSessionHandler;
import io.cloudbeaver.service.sql.WebSQLConstants;
import io.cloudbeaver.utils.CBModelConstants;
import io.cloudbeaver.utils.WebDataSourceUtils;
import io.cloudbeaver.utils.WebEventUtils;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.DBFileController;
import org.jkiss.dbeaver.model.DBPAdaptable;
import org.jkiss.dbeaver.model.DBPDataSourceContainer;
import org.jkiss.dbeaver.model.DBPEventListener;
import org.jkiss.dbeaver.model.access.DBAAuthCredentials;
import org.jkiss.dbeaver.model.access.DBACredentialsProvider;
import org.jkiss.dbeaver.model.auth.*;
import org.jkiss.dbeaver.model.connection.DBPConnectionConfiguration;
import org.jkiss.dbeaver.model.exec.DBCException;
import org.jkiss.dbeaver.model.meta.Association;
import org.jkiss.dbeaver.model.meta.Property;
import org.jkiss.dbeaver.model.navigator.DBNModel;
import org.jkiss.dbeaver.model.rm.*;
import org.jkiss.dbeaver.model.runtime.AbstractJob;
import org.jkiss.dbeaver.model.runtime.BaseProgressMonitor;
import org.jkiss.dbeaver.model.runtime.DBRProgressMonitor;
import org.jkiss.dbeaver.model.security.SMAdminController;
import org.jkiss.dbeaver.model.security.SMConstants;
import org.jkiss.dbeaver.model.security.SMController;
import org.jkiss.dbeaver.model.sql.DBQuotaException;
import org.jkiss.dbeaver.model.websocket.event.MessageType;
import org.jkiss.dbeaver.model.websocket.event.WSSessionLogUpdatedEvent;
import org.jkiss.dbeaver.runtime.DBWorkbench;
import org.jkiss.utils.CommonUtils;

import java.lang.reflect.InvocationTargetException;
import java.nio.file.Path;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.stream.Collectors;
/**
 * Web session.
 * Is the main source of data in web application
 */
//TODO: split to authenticated and non authenticated context
public class WebSession extends BaseWebSession
    implements SMSessionWithAuth, SMCredentialsProvider, DBACredentialsProvider, DBPAdaptable {

    private static final Log log = Log.getLog(WebSession.class);

    public static final SMSessionType CB_SESSION_TYPE = new SMSessionType("CloudBeaver");
    private static final String WEB_SESSION_AUTH_CONTEXT_TYPE = "web-session";
    private static final AtomicInteger TASK_ID = new AtomicInteger();

    public static String RUNTIME_PARAM_AUTH_INFOS = "auth-infos";
    public static String RUNTIME_PARAM_CLIENT_ORIGIN = "client-origin";
    public static String RUNTIME_PARAM_INPUT_AUTH_ONLY = "input-auth-only";
    private final AtomicInteger taskCount = new AtomicInteger();

    private final String lastRemoteAddr;
    private String lastRemoteUserAgent;

    private String locale;
    private boolean cacheExpired;
    private String clientOrigin;

    protected WebSessionGlobalProjectImpl globalProject;
    private final List<WebServerMessage> sessionMessages = new ArrayList<>();

    private final Map<String, WebAsyncTaskInfo> asyncTasks = new HashMap<>();

    // Map of auth tokens. Key is authentication provider
    private final List<WebAuthInfo> authTokens = new ArrayList<>();

    private DBNModel navigatorModel;
    private final ReadWriteLock navigatorModelLock = new ReentrantReadWriteLock(true);
    private final DBRProgressMonitor progressMonitor = new SessionProgressMonitor();
    private final Map<String, DBWSessionHandler<WebSession>> sessionHandlers;
    private final WebDataSourceConnectEventListener connectListener = new WebDataSourceConnectEventListener(this);

    public WebSession(
        @NotNull WebHttpRequestInfo requestInfo,
        @NotNull ServletAuthApplication application,
        @NotNull Map<String, DBWSessionHandler<WebSession>> sessionHandlers
    ) throws DBException {
        this(
            Objects.requireNonNull(requestInfo.getId()),
            CommonUtils.toString(requestInfo.getLocale()),
            application,
            sessionHandlers,
            requestInfo.getLastRemoteAddress(),
            requestInfo.getSessionType()
        );
        updateSessionParameters(requestInfo);
    }

    protected WebSession(
        @NotNull String id,
        @Nullable String locale,
        @NotNull ServletApplication application,
        @NotNull Map<String, DBWSessionHandler<WebSession>> sessionHandlers,
        @Nullable String remoteAddr
    ) throws DBException {
        this(id, locale, application, sessionHandlers, remoteAddr, SessionType.WEB);
    }

    protected WebSession(
        @NotNull String id,
        @Nullable String locale,
        @NotNull ServletApplication application,
        @NotNull Map<String, DBWSessionHandler<WebSession>> sessionHandlers,
        @Nullable String remoteAddr,
        @NotNull SessionType sessionType
    ) throws DBException {
        super(id, application, sessionType);
        if (CommonUtils.isEmpty(remoteAddr)) {
            throw new DBException("Remote address cannot be empty");
        }
        this.lastRemoteAddr = remoteAddr;
        this.lastAccessTime = this.createTime;
        this.sessionHandlers = sessionHandlers;
        setLocale(CommonUtils.toString(locale, this.locale));
        //force authorization of anonymous session to avoid access error,
        //because before authorization could be called by any request,
        //but now 'updateInfo' is called only in special requests,
        //and the order of requests is not guaranteed.
        //look at CB-4747
        refreshSessionAuth();
    }

    @Nullable
    @Override
    public SMSessionPrincipal getSessionPrincipal() {
        synchronized (authTokens) {
            if (authTokens.isEmpty()) {
                return null;
            }
            return authTokens.getFirst();
        }
    }

    @Nullable
    public WebSessionProjectImpl getSingletonProject() {
        return getWorkspace().getActiveProject();
    }

    @Property
    public String getCreateTime() {
        return CBModelConstants.ISO_DATE_FORMAT.format(Instant.ofEpochMilli(createTime));
    }

    @Property
    public synchronized String getLastAccessTime() {
        return CBModelConstants.ISO_DATE_FORMAT.format(Instant.ofEpochMilli(lastAccessTime));
    }

    public String getLastRemoteAddr() {
        return lastRemoteAddr;
    }

    public String getLastRemoteUserAgent() {
        return lastRemoteUserAgent;
    }

    // Clear cache when
    @Property
    public boolean isCacheExpired() {
        return cacheExpired;
    }

    public void setCacheExpired(boolean cacheExpired) {
        this.cacheExpired = cacheExpired;
    }

    public WebUser getUser() {
        return this.userContext.getUser();
    }

    @NotNull
    public Map<String, String> getUserMetaParameters() {
        var user = getUser();
        if (user == null) {
            return Map.of();
        }
        var allMetaParams = new HashMap<>(user.getMetaParameters());

        getAllAuthInfo().forEach(authInfo -> allMetaParams.putAll(authInfo.getUserIdentity().getMetaParameters()));

        return allMetaParams;
    }

    public String getUserId() {
        return userContext.getUserId();
    }

    public synchronized boolean hasPermission(String perm) {
        Set<String> sessionPermissions = getSessionPermissions();
        return sessionPermissions.contains(DBWConstants.PERMISSION_ADMIN) || sessionPermissions.contains(perm);
    }

    public boolean isAuthorizedInSecurityManager() {
        return userContext.isAuthorizedInSecurityManager();
    }

    public Set<String> getSessionPermissions() {
        if (userContext.getUserPermissions() == null) {
            refreshSessionAuth();
        }
        return userContext.getUserPermissions();
    }

    @NotNull
    public SMController getSecurityController() {
        return userContext.getSecurityController();
    }

    @NotNull
    public SMAdminController getAdminSecurityController() throws DBException {
        if (!hasPermission(DBWConstants.PERMISSION_ADMIN)) {
            throw new DBException("Admin permissions required");
        }
        return userContext.getAdminSecurityController();
    }

    @NotNull
    public RMController getRmController() {
        return userContext.getRmController();
    }

    @NotNull
    public DBFileController getFileController() {
        return userContext.getFileController();
    }

    @Override
    public void refreshUserData() {
        refreshUserPermissions();

        initNavigatorModel();
    }

    @Override
    public void refreshUserPermissions() {
        super.refreshUserData();
        refreshSessionAuth();
        if (getUserId() == null && globalProject != null) {
            // refreshSessionAuth() updates accessible connections for named users only,
            // for anonymous sessions this was done by initNavigatorModel()
            globalProject.refreshAccessibleConnectionIds();
        }
        syncSessionProjects();
    }

    /**
     * Adds/removes only those session projects whose accessibility actually changed.
     * <p>
     * Unlike {@link #initNavigatorModel()} this keeps existing projects, and therefore
     * their live connections and SQL contexts, intact.
     */
    private void syncSessionProjects() {
        if (getNavigatorModel() == null) {
            // model was never initialized for this session - nothing to sync
            return;
        }
        try {
            Map<String, RMProject> actualProjects = new LinkedHashMap<>();
            for (RMProject rmProject : getRmController().listAccessibleProjects()) {
                actualProjects.put(rmProject.getId(), rmProject);
            }
            for (WebSessionProjectImpl project : new ArrayList<>(getWorkspace().getProjects())) {
                if (actualProjects.remove(project.getId()) == null && !project.isInMemory()) {
                    // in-memory (anonymous) projects are never listed by RM
                    deleteSessionProject(project);
                }
            }
            for (RMProject rmProject : actualProjects.values()) {
                createWebProject(rmProject);
            }
        } catch (DBException e) {
            addSessionError(e);
            log.error("Error synchronizing accessible projects", e);
        }
    }

    // Note: for admin use only
    public void resetUserState(boolean needResetUserCache) throws DBException {
        clearAuthTokens();
        if (needResetUserCache) {
            try {
                resetSessionCache();
            } catch (DBCException e) {
                addSessionError(e);
                log.error(e);
            }
        }
        refreshUserData();
        clearSessionContext();
    }

    public void resetUserState() throws DBException {
        resetUserState(true);
    }

    @NotNull
    public DBPEventListener getDataSourceConnectListener() {
        return connectListener;
    }

    @NotNull
    public String getClientOrigin() {
        return clientOrigin;
    }

    public void updateClientOrigin(@NotNull String originFromRequest) {
        this.clientOrigin = originFromRequest;
    }

    private void initNavigatorModel() {
        navigatorModelLock.writeLock().lock();
        try {
            // Cleanup current data
            if (this.navigatorModel != null) {
                this.navigatorModel.dispose();
                this.navigatorModel = null;
            }
            this.globalProject = null;

            loadProjects();

            this.navigatorModel = new DBNModel(DBWorkbench.getPlatform(), getWorkspace());
            this.navigatorModel.setModelAuthContext(getWorkspace().getAuthContext());
            this.navigatorModel.initialize();

            this.locale = Locale.getDefault().getLanguage();
        } finally {
            navigatorModelLock.writeLock().unlock();
        }
    }

    private void loadProjects() {
        WebSessionWorkspace workspace = getWorkspace();
        workspace.clearProjects();

        WebUser user = userContext.getUser();
        if (user == null && DBWorkbench.isDistributed()) {
            // No anonymous mode in distributed apps
            return;
        }
        try {
            RMController controller = getRmController();
            RMProject[] rmProjects = controller.listAccessibleProjects();
            for (RMProject project : rmProjects) {
                createWebProject(project);
            }
            if (user == null && application.isAnonymousAccessEnabled()) {
                WebProjectImpl anonymousProject = createWebProject(RMUtils.createAnonymousProject());
                anonymousProject.setInMemory(true);
            }
            if (workspace.getActiveProject() == null && !workspace.getProjects().isEmpty()) {
                workspace.setActiveProject(workspace.getProjects().getFirst());
            }
        } catch (DBException e) {
            addSessionError(e);
            log.error("Error getting accessible projects list", e);
        }
    }

    @NotNull
    private WebSessionProjectImpl createWebProject(@NotNull RMProject project) throws DBException {
        WebSessionProjectImpl sessionProject;
        if (project.isGlobal()) {
            sessionProject = createGlobalProject(project);
        } else {
            sessionProject = createSessionProject(project);
        }
        // do not load data sources for anonymous project
        if (project.getType() == RMProjectType.USER && userContext.getUser() == null) {
            sessionProject.setInMemory(true);
        }
        addSessionProject(sessionProject);
        if (!project.isShared() || application.isConfigurationMode()) {
            getWorkspace().setActiveProject(sessionProject);
        }
        return sessionProject;
    }

    @NotNull
    protected WebSessionProjectImpl createSessionProject(@NotNull RMProject project) throws DBException {
        return new WebSessionProjectImpl(this, project, getProjectPath(project));
    }

    @NotNull
    protected Path getProjectPath(@NotNull RMProject project) throws DBException {
        return RMUtils.getProjectPath(project);
    }

    @NotNull
    protected WebSessionProjectImpl createGlobalProject(RMProject project) {
        globalProject = new WebSessionGlobalProjectImpl(this, project);
        globalProject.refreshAccessibleConnectionIds();
        return globalProject;
    }

    private void resetNavigationModel() {
        navigatorModelLock.writeLock().lock();
        try {
            getWorkspace().getProjects().forEach(WebSessionProjectImpl::dispose);

            if (this.navigatorModel != null) {
                this.navigatorModel.dispose();
                this.navigatorModel = null;
            }
        } finally {
            navigatorModelLock.writeLock().unlock();
        }
    }

    private synchronized void refreshSessionAuth() {
        try {
            if (!isAuthorizedInSecurityManager()) {
                authAsAnonymousUser();
            } else if (getUserId() != null) {
                userContext.refreshPermissions();
                if (globalProject != null) {
                    globalProject.refreshAccessibleConnectionIds();
                }
            }

        } catch (Exception e) {
            addSessionError(e);
            log.error("Error reading session permissions", e);
        }
    }


    private synchronized void authAsAnonymousUser() throws DBException {
        if (!application.isAnonymousAccessEnabled()) {
            return;
        }

        SMAuthInfo authInfo = getSecurityController().authenticateAnonymousUser(this.id, getSessionParameters(), CB_SESSION_TYPE);
        updateSMSession(authInfo);
        notifySessionAuthChange();
    }

    @NotNull
    public String getLocale() {
        return locale;
    }

    public void setLocale(@Nullable String locale) {
        this.locale = locale != null ? locale : Locale.getDefault().getLanguage();
    }

    @Nullable
    public DBNModel getNavigatorModel() {
        navigatorModelLock.readLock().lock();
        try {
            return navigatorModel;
        } finally {
            navigatorModelLock.readLock().unlock();
        }
    }

    @NotNull
    public DBNModel getNavigatorModelOrThrow() throws DBWebException {
        navigatorModelLock.readLock().lock();
        try {
            if (navigatorModel != null) {
                return navigatorModel;
            }
            throw new DBWebException("Navigator model is not found in session");
        } finally {
            navigatorModelLock.readLock().unlock();
        }
    }

    /**
     * Initializes the project's lazy database branch while preventing the navigator model from being replaced.
     */
    public void initializeProjectNavigator(@NotNull WebSessionProjectImpl project) {
        navigatorModelLock.readLock().lock();
        try {
            if (navigatorModel == null) {
                return;
            }
            var projectNode = navigatorModel.getRoot().getProjectNode(project);
            if (projectNode != null) {
                projectNode.getDatabases();
            }
        } finally {
            navigatorModelLock.readLock().unlock();
        }
    }

    /**
     * Returns and clears progress messages
     */
    @Association
    public List<WebServerMessage> getSessionMessages() {
        synchronized (sessionMessages) {
            List<WebServerMessage> copy = new ArrayList<>(sessionMessages);
            sessionMessages.clear();
            return copy;
        }
    }

    public void updateInfo(boolean isOldHttpSessionUsed) {
        log.trace("Update session lifetime " + getSessionId() + " for user " + getUserId());
        touchSession();
        if (isOldHttpSessionUsed) {
            try {
                // Persist session
                if (!isAuthorizedInSecurityManager()) {
                    // Create new record
                    authAsAnonymousUser();
                } else {
                    if (!application.isConfigurationMode()) {
                        // Update record
                        //TODO use generate id from SMController
                        getSecurityController().updateSession(this.userContext.getSmSessionId(), getSessionParameters());
                    }
                }
            } catch (Exception e) {
                addSessionError(e);
                log.error("Error persisting web session", e);
            }
        }
    }

    public synchronized void updateSessionParameters(WebHttpRequestInfo requestInfo) {
        this.lastRemoteUserAgent = requestInfo.getLastRemoteUserAgent();
        this.cacheExpired = false;
    }

    @Override
    public void close() {
        try {
            resetNavigationModel();
        } catch (Throwable e) {
            log.error(e);
        }
        try {
            clearAuthTokens();
        } catch (Exception e) {
            log.error("Error closing web session tokens");
        }
        this.userContext.setUser(null);
        super.close();
    }

    @Override
    public void close(boolean clearTokens, boolean sendSessionExpiredEvent) {
        try {
            resetNavigationModel();
        } catch (Throwable e) {
            log.error(e);
        }
        if (clearTokens) {
            try {
                clearAuthTokens();
            } catch (Exception e) {
                log.error("Error closing web session tokens");
            }
        }
        this.userContext.setUser(null);
        super.close(clearTokens, sendSessionExpiredEvent);
    }

    @NotNull
    private List<WebAuthInfo> clearAuthTokens() throws DBException {
        ArrayList<WebAuthInfo> tokensCopy;
        synchronized (authTokens) {
            tokensCopy = new ArrayList<>(this.authTokens);
        }
        for (WebAuthInfo ai : tokensCopy) {
            removeAuthInfo(ai);
        }
        resetAuthToken();
        return tokensCopy;
    }

    public DBRProgressMonitor getProgressMonitor() {
        return progressMonitor;
    }

    ///////////////////////////////////////////////////////
    // Async model

    public WebAsyncTaskInfo getAsyncTask(@NotNull String taskId, @NotNull String taskName, boolean create) {
        synchronized (asyncTasks) {
            WebAsyncTaskInfo taskInfo = asyncTasks.get(taskId);
            if (taskInfo == null && create) {
                taskInfo = new WebAsyncTaskInfo(taskId, taskName);
                asyncTasks.put(taskId, taskInfo);
            }
            return taskInfo;
        }
    }

    @NotNull
    public WebAsyncTaskInfo asyncTaskStatus(String taskId, boolean removeOnFinish) throws DBWebException {
        synchronized (asyncTasks) {
            WebAsyncTaskInfo taskInfo = asyncTasks.get(taskId);
            if (taskInfo == null) {
                throw new DBWebException("Task '" + taskId + "' not found");
            }
            if (removeOnFinish && !taskInfo.isRunning()) {
                asyncTasks.remove(taskId);
            }
            return taskInfo;
        }
    }

    public boolean asyncTaskCancel(String taskId) throws DBWebException {
        WebAsyncTaskInfo taskInfo;
        synchronized (asyncTasks) {
            taskInfo = asyncTasks.get(taskId);
            if (taskInfo == null) {
                throw new DBWebException("Task '" + taskId + "' not found");
            }
        }
        AbstractJob job = taskInfo.getJob();
        if (job instanceof CustomCancelableJob cancelableJob) {
            cancelableJob.cancelJob(this, taskInfo);
        }
        CompletableFuture<?> future = getAttribute(getTaskConfirmationAttributeName(taskId));
        if (future != null) {
            future.cancel(false);
        }
        if (job != null) {
            job.cancel();
        }
        return true;
    }


    public WebAsyncTaskInfo createAsyncTask(@NotNull String taskName) {
        int taskId = TASK_ID.incrementAndGet();
        return getAsyncTask(String.valueOf(taskId), taskName, true);
    }

    public List<WebAsyncTaskInfo> findTasksByJob(@NotNull Class<? extends AbstractJob> jobClass) {
        synchronized (asyncTasks) {
            List<WebAsyncTaskInfo> result = new ArrayList<>();
            for (WebAsyncTaskInfo task : asyncTasks.values()) {
                if (task.getJob() != null && jobClass.isAssignableFrom(task.getJob().getClass())) {
                    result.add(task);
                }
            }
            return result;
        }
    }

    @NotNull
    public WebAsyncTaskInfo createAndRunAsyncTask(@NotNull String taskName, @NotNull WebAsyncTaskProcessor<?> runnable) {
        WebAsyncTaskInfo asyncTask = createAsyncTask(taskName);
        return runAsyncTask(asyncTask, runnable);
    }

    @NotNull
    public WebAsyncTaskInfo runAsyncTask(@NotNull WebAsyncTaskInfo asyncTask, @NotNull WebAsyncTaskProcessor<?> runnable) {
        AbstractJob job = new AbstractCancelableJob(asyncTask.getName()) {
            @Override
            public void cancelJob(@NotNull WebSession webSession, @NotNull WebAsyncTaskInfo taskInfo) {
                try {
                    runnable.cancel();
                } finally {
                    super.cancelJob(webSession, taskInfo);
                }
            }

            @NotNull
            @Override
            protected IStatus run(@NotNull DBRProgressMonitor monitor) {
                int curTaskCount = taskCount.incrementAndGet();

                DBRProgressMonitor taskMonitor = new TaskProgressMonitor(monitor, WebSession.this, asyncTask);

                try {
                    Number queryLimit = application.getAppConfiguration().getResourceQuota(WebSQLConstants.QUOTA_PROP_QUERY_LIMIT);
                    if (queryLimit != null && curTaskCount > queryLimit.intValue()) {
                        throw new DBQuotaException(
                            "Maximum simultaneous queries quota exceeded", WebSQLConstants.QUOTA_PROP_QUERY_LIMIT, queryLimit.intValue(), curTaskCount);
                    }

                    runnable.run(taskMonitor);
                    asyncTask.setResult(runnable.getResult());
                    asyncTask.setExtendedResult(runnable.getExtendedResults());
                    asyncTask.setStatus(DBWConstants.TASK_STATUS_FINISHED);
                } catch (InvocationTargetException e) {
                    addSessionError(e.getTargetException());
                    asyncTask.setJobError(e.getTargetException());
                } catch (Exception e) {
                    asyncTask.setJobError(e);
                } finally {
                    taskCount.decrementAndGet();
                    asyncTask.setRunning(false);
                    WebEventUtils.sendAsyncTaskEvent(WebSession.this, asyncTask);
                }
                return Status.OK_STATUS;
            }
        };

        asyncTask.setJob(job);
        asyncTask.setRunning(true);
        job.schedule();
        return asyncTask;
    }

    public void addSessionError(@NotNull Throwable exception) {
        addSessionMessage(new WebServerMessage(exception));
    }

    public void addSessionMessage(@NotNull WebServerMessage message) {
        synchronized (sessionMessages) {
            sessionMessages.add(message);
        }
        addSessionEvent(new WSSessionLogUpdatedEvent(
            this.userContext.getSmSessionId(),
            this.userContext.getUserId(),
            message.getType(),
            message.getMessage()));
    }

    public void addInfoMessage(@NotNull String message) {
        addSessionMessage(new WebServerMessage(MessageType.INFO, message));
    }

    public void addWarningMessage(@NotNull String message) {
        addSessionMessage(new WebServerMessage(MessageType.WARNING, message));
    }

    @NotNull
    public List<WebServerMessage> readLog(Integer maxEntries, Boolean clearLog) {
        synchronized (sessionMessages) {
            List<WebServerMessage> messages = new ArrayList<>();
            int entryCount = CommonUtils.toInt(maxEntries);
            if (entryCount == 0 || entryCount >= sessionMessages.size()) {
                messages.addAll(sessionMessages);
                if (CommonUtils.toBoolean(clearLog)) {
                    sessionMessages.clear();
                }
            } else {
                messages.addAll(sessionMessages.subList(0, maxEntries));
                if (CommonUtils.toBoolean(clearLog)) {
                    sessionMessages.removeAll(messages);
                }
            }
            return messages;
        }
    }

    @Property
    public Map<String, Object> getActionParameters() {
        WebActionParameters action = WebActionParameters.fromSession(this, true);
        return action == null ? null : action.getParameters();
    }

    @Nullable
    public WebAuthInfo getAuthInfo(@Nullable String providerID) {
        synchronized (authTokens) {
            if (providerID != null) {
                for (WebAuthInfo ai : authTokens) {
                    if (ai.getAuthProvider().equals(providerID)) {
                        return ai;
                    }
                }
                return null;
            }
            return authTokens.isEmpty() ? null : authTokens.getFirst();
        }
    }

    @Nullable
    public WebAuthInfo getAuthInfo(@NotNull String providerId, @Nullable String configurationId) {
        synchronized (authTokens) {
            for (WebAuthInfo authInfo : authTokens) {
                if (authInfo.getAuthProvider().equals(providerId) &&
                    Objects.equals(authInfo.getAuthConfiguration(), configurationId)) {
                    return authInfo;
                }
            }
            return null;
        }
    }

    @Override
    public List<SMAuthInfo> getAuthInfos() {
        synchronized (authTokens) {
            return authTokens.stream().map(WebAuthInfo::getAuthInfo).toList();
        }
    }

    @NotNull
    public List<WebAuthInfo> getAllAuthInfo() {
        synchronized (authTokens) {
            return new ArrayList<>(authTokens);
        }
    }

    public void addAuthInfo(@NotNull WebAuthInfo authInfo) throws DBException {
        addAuthTokens(authInfo);
    }

    public void addAuthTokens(@NotNull WebAuthInfo... tokens) throws DBException {
        WebUser newUser = null;
        for (WebAuthInfo authInfo : tokens) {
            if (newUser != null && newUser != authInfo.getUser()) {
                throw new DBException("Different users specified in auth tokens: " + Arrays.toString(tokens));
            }
            newUser = authInfo.getUser();
        }
        if (application.isConfigurationMode() && this.userContext.getUser() == null && newUser != null) {
            //FIXME hotfix to avoid exception after external auth provider login in easy config
            userContext.setUser(newUser);
            refreshUserData();
        } else if (!CommonUtils.equalObjects(this.userContext.getUser(), newUser)) {
            throw new DBException("Can't authorize different users in the single session");
        }

        for (WebAuthInfo authInfo : tokens) {
            WebAuthInfo oldAuthInfo = getAuthInfo(authInfo.getAuthProvider(), authInfo.getAuthConfiguration());
            if (oldAuthInfo != null) {
                removeAuthInfo(oldAuthInfo);
            }
            getSessionContext().addSession(authInfo.getAuthSession());
        }
        synchronized (authTokens) {
            Collections.addAll(authTokens, tokens);
        }

        notifySessionAuthChange();
    }

    public void notifySessionAuthChange() {
        // Notify handlers about auth change
        sessionHandlers.forEach((id, handler) -> {
            try {
                handler.handleSessionAuth(this);
            } catch (Exception e) {
                log.error("Error calling session handler '" + id + "'", e);
            }
        });
    }

    private void removeAuthInfo(@NotNull WebAuthInfo oldAuthInfo) {
        oldAuthInfo.closeAuth();
        synchronized (authTokens) {
            authTokens.remove(oldAuthInfo);
        }
    }

    @NotNull
    public List<WebAuthInfo> removeAuthInfo(@Nullable String providerId) throws DBException {
        if (providerId == null) {
            return clearAuthTokens();
        }
        WebAuthInfo authInfo = getAuthInfo(providerId);
        List<WebAuthInfo> oldInfo;
        if (authInfo != null) {
            removeAuthInfo(authInfo);
            oldInfo = List.of(authInfo);
        } else {
            oldInfo = List.of();
        }
        if (authTokens.isEmpty()) {
            resetUserState();
        }
        return oldInfo;
    }

    @NotNull
    public List<WebAuthInfo> removeAuthInfo(
        @NotNull String providerId,
        @Nullable String configurationId
    ) throws DBException {
        WebAuthInfo authInfo = getAuthInfo(providerId, configurationId);
        if (authInfo == null) {
            return List.of();
        }
        removeAuthInfo(authInfo);
        if (authTokens.isEmpty()) {
            resetUserState();
        }
        return List.of(authInfo);
    }

    @Nullable
    public List<DBACredentialsProvider> getContextCredentialsProviders() {
        return getAdapters(DBACredentialsProvider.class);
    }

    // Auth credentials provider
    // Adds auth properties passed from web (by user)
    @Override
    public boolean provideAuthParameters(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBPDataSourceContainer dataSourceContainer,
        @NotNull DBPConnectionConfiguration configuration
    ) {
        return provideAuthParameters(
            monitor,
            dataSourceContainer,
            configuration,
            !Boolean.TRUE.equals(configuration.getRuntimeAttribute(RUNTIME_PARAM_INPUT_AUTH_ONLY))
        );
    }

    /**
     * Provides credentials from the connection configuration without credentials from the current session context.
     */
    public boolean provideInputAuthParameters(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBPDataSourceContainer dataSourceContainer,
        @NotNull DBPConnectionConfiguration configuration
    ) {
        configuration.setRuntimeAttribute(RUNTIME_PARAM_INPUT_AUTH_ONLY, true);
        configuration.removeRuntimeAttribute(RUNTIME_PARAM_AUTH_INFOS);
        return provideAuthParameters(monitor, dataSourceContainer, configuration, false);
    }

    private boolean provideAuthParameters(
        @NotNull DBRProgressMonitor monitor,
        @NotNull DBPDataSourceContainer dataSourceContainer,
        @NotNull DBPConnectionConfiguration configuration,
        boolean provideContextCredentials
    ) {
        try {
            // Properties from nested auth sessions
            if (provideContextCredentials) {
                for (DBACredentialsProvider contextCredentialsProvider : getContextCredentialsProviders()) {
                    contextCredentialsProvider.provideAuthParameters(monitor, dataSourceContainer, configuration);
                }
                configuration.setRuntimeAttribute(RUNTIME_PARAM_AUTH_INFOS, getAllAuthInfo());

                WebSessionProjectImpl project = getProjectById(dataSourceContainer.getProject().getId());
                if (project != null) {
                    WebConnectionInfo webConnectionInfo = project.findWebConnectionInfo(dataSourceContainer.getId());
                    if (webConnectionInfo != null) {
                        WebDataSourceUtils.saveCredentialsInDataSource(webConnectionInfo, dataSourceContainer, configuration);
                    }
                }
            }
            configuration.setRuntimeAttribute(RUNTIME_PARAM_CLIENT_ORIGIN, this.clientOrigin);

            // uncommented because we had the problem with non-native auth models
            // (for example, can't connect to DynamoDB if credentials are not saved)
            DBAAuthCredentials credentials = configuration.getAuthModel().loadCredentials(dataSourceContainer, configuration);
            WebDataSourceUtils.updateCredentialsFromProperties(this.progressMonitor, credentials, configuration.getAuthProperties());

            configuration.getAuthModel().provideCredentials(dataSourceContainer, configuration, credentials);
        } catch (DBException e) {
            addSessionError(e);
            log.error(e);
        }
        return true;
    }

    @NotNull
    @Override
    public String getAuthContextType() {
        return WEB_SESSION_AUTH_CONTEXT_TYPE;
    }

    // May be called to extract auth information from session
    @Override
    public <T> T getAdapter(@NotNull Class<T> adapter) {
        synchronized (authTokens) {
            for (WebAuthInfo authInfo : authTokens) {
                if (isAuthInfoInstanceOf(authInfo, adapter)) {
                    return adapter.cast(authInfo.getAuthSession());
                }
            }
        }
        return null;
    }

    @NotNull
    public <T> List<T> getAdapters(Class<T> adapter) {
        synchronized (authTokens) {
            return authTokens.stream()
                .filter(token -> isAuthInfoInstanceOf(token, adapter))
                .map(token -> adapter.cast(token.getAuthSession()))
                .collect(Collectors.toList());
        }
    }

    private <T> boolean isAuthInfoInstanceOf(WebAuthInfo authInfo, Class<T> adapter) {
        if (authInfo != null) {
            return adapter.isInstance(authInfo.getAuthSession());
        }
        return false;
    }

    ///////////////////////////////////////////////////////
    // Utils

    public Map<String, Object> getSessionParameters() {
        var parameters = new HashMap<String, Object>();
        parameters.put(SMConstants.SESSION_PARAM_LAST_REMOTE_ADDRESS, getLastRemoteAddr());
        parameters.put(SMConstants.SESSION_PARAM_LAST_REMOTE_USER_AGENT, getLastRemoteUserAgent());
        return parameters;
    }

    public void resetAuthToken() throws DBException {
        this.userContext.reset();
    }

    public boolean updateSMSession(SMAuthInfo smAuthInfo) throws DBException {
        boolean contextChanged = super.updateSMSession(smAuthInfo);
        if (contextChanged) {
            refreshUserData();
        }
        return contextChanged;
    }

    @Override
    public SMCredentials getActiveUserCredentials() {
        return userContext.getActiveUserCredentials();
    }

    @Override
    public void refreshSMSession() throws DBException {
        userContext.refreshSMSession();
    }

    @Nullable
    public WebSessionProjectImpl getProjectById(@Nullable String projectId) {
        return getWorkspace().getProjectById(projectId);
    }

    /**
     * Returns project info from session cache.
     *
     * @throws DBWebException if project with provided id is not found.
     */
    @NotNull
    public WebSessionProjectImpl getAccessibleProjectById(@Nullable String projectId) throws DBWebException {
        WebSessionProjectImpl project = null;
        if (projectId != null) {
            project = getWorkspace().getProjectById(projectId);
        }
        if (project == null) {
            throw new DBWebException("Project not found: " + projectId);
        }
        return project;
    }

    @NotNull
    public List<WebSessionProjectImpl> getAccessibleProjects() {
        return getWorkspace().getProjects();
    }

    /**
     * Adds project to session cache and navigator tree.
     */
    public void addSessionProject(@NotNull WebSessionProjectImpl project) {
        getWorkspace().addProject(project);
        navigatorModelLock.readLock().lock();
        try {
            if (navigatorModel != null) {
                navigatorModel.getRoot().addProject(project, false);
            }
        } finally {
            navigatorModelLock.readLock().unlock();
        }
    }

    /**
     * Removes project from session cache and navigator tree.
     */
    public void deleteSessionProject(@NotNull WebSessionProjectImpl project) {
        RMProject rmProject = project.getRMProject();
        log.info(String.format(
            "Project deleted: [ID=%s, Name=%s, Type=%s, Creator=%s]",
            rmProject.getId(), rmProject.getName(), rmProject.getType(), rmProject.getCreator()
        ));
        project.dispose();

        getWorkspace().removeProject(project);
        navigatorModelLock.readLock().lock();
        try {
            if (navigatorModel != null) {
                navigatorModel.getRoot().removeProject(project);
            }
        } finally {
            navigatorModelLock.readLock().unlock();
        }
    }

    @Override
    public void addSessionProject(@NotNull String projectId) throws DBException {
        super.addSessionProject(projectId);
        var rmProject = getRmController().getProject(projectId, false, false);
        if (rmProject == null) {
            log.error("RM project '" + projectId + "' not found");
            return;
        }
        createWebProject(rmProject);
    }

    @Override
    public void updateSessionProject(@NotNull String projectId, @NotNull RMProjectInfo rmProjectInfo) throws DBException {
        super.updateSessionProject(projectId, rmProjectInfo);
        var project = getProjectById(projectId);
        if (project == null) {
            return;
        }
        project.updateProjectInfo(rmProjectInfo.getName(), rmProjectInfo.getDescription());
    }

    @Override
    public void removeSessionProject(@NotNull String projectId) throws DBException {
        super.removeSessionProject(projectId);
        var project = getProjectById(projectId);
        if (project == null) {
            return;
        }
        deleteSessionProject(project);
    }

    @NotNull
    public WebSessionPreferenceStore getUserPreferenceStore() {
        return getUserContext().getPreferenceStore();
    }

    @Nullable
    public WebSessionGlobalProjectImpl getGlobalProject() {
        return globalProject;
    }

    public void handleTaskConfirmation(
        @NotNull String taskId,
        boolean confirmed,
        boolean skipConfirmations
    ) {
        String attributeName = getTaskConfirmationAttributeName(taskId);
        if (confirmed && skipConfirmations) {
            setAttribute(WebSQLConstants.SKIP_TASK_CONFIRMATIONS_ATTR, Boolean.TRUE);
        }

        CompletableFuture<Boolean> confirmationFuture = getAttribute(attributeName);
        if (confirmationFuture != null) {
            confirmationFuture.complete(confirmed);
            removeAttribute(attributeName);
        } else {
            log.error("Received unexpected confirmation event for taskId: " + taskId);
        }
    }

    public void handleTaskConfirmationWithParameters(@NotNull String taskId, @NotNull Map<String, Object> parameters) {
        String attributeName = getTaskConfirmationAttributeName(taskId);
        CompletableFuture<Map<String, Object>> confirmationFuture = getAttribute(attributeName);
        if (confirmationFuture != null) {
            confirmationFuture.complete(parameters);
            removeAttribute(attributeName);
        } else {
            log.error("Received unexpected confirmation event for taskId: " + taskId);
        }
    }

    public void handleActionCancelledEvent(@NotNull String actionId) {
        Object attributeValue = getAttribute(actionId);
        if (!(attributeValue instanceof CompletableFuture<?> future)) {
            log.info("Action to be cancelled not found, skipping: " + actionId);
            return;
        }
        future.completeExceptionally(new DBWebException("Action cancelled by user: " + actionId));
        removeAttribute(actionId);
    }

    @NotNull
    private String getTaskConfirmationAttributeName(@NotNull String taskId) {
        return WebSQLConstants.TASK_CONFIRMATION_ATTR_PREFIX + taskId;
    }

    private class SessionProgressMonitor extends BaseProgressMonitor {
        @Override
        public void beginTask(@NotNull String name, int totalWork) {
            addInfoMessage(name);
        }

        @Override
        public void subTask(@NotNull String name) {
            addInfoMessage(name);
        }
    }

    public boolean hasGlobalPermission(String permissionId) {
        return true;
    }

}
