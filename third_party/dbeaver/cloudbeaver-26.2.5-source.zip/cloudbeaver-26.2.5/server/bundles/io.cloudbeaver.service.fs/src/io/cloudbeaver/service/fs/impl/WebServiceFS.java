/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.service.fs.impl;

import io.cloudbeaver.DBWConstants;
import io.cloudbeaver.DBWebException;
import io.cloudbeaver.model.fs.WebFSUtils;
import io.cloudbeaver.model.session.WebSession;
import io.cloudbeaver.service.fs.DBWServiceFS;
import io.cloudbeaver.service.fs.model.FSFile;
import io.cloudbeaver.service.fs.model.FSFileSystem;
import org.jkiss.code.NotNull;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.model.navigator.fs.DBNFileSystem;
import org.jkiss.dbeaver.model.navigator.fs.DBNFileSystems;
import org.jkiss.dbeaver.model.navigator.fs.DBNPathBase;
import org.jkiss.dbeaver.registry.fs.FileSystemProviderRegistry;
import org.jkiss.dbeaver.runtime.DBWorkbench;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Web file system implementation
 */
public class WebServiceFS implements DBWServiceFS {

    private static final Pattern FORBIDDEN_FILENAME_PATTERN = Pattern.compile("[%#:;№$]");

    @NotNull
    @Override
    public FSFileSystem[] getAvailableFileSystems(@NotNull WebSession webSession, @NotNull String projectId) throws DBWebException {
        try {
            DBNFileSystems dbnFileSystems = webSession.getNavigatorModelOrThrow().getRoot().getExtraNode(DBNFileSystems.class);
            if (dbnFileSystems == null) {
                throw new DBWebException("File systems not found in navigator");
            }
            var fsRegistry = FileSystemProviderRegistry.getInstance();
            DBNFileSystem[] children = dbnFileSystems.getChildren(webSession.getProgressMonitor());
            if (children == null) {
                return new FSFileSystem[0];
            }
            return Arrays.stream(children)
                .map(fs -> new FSFileSystem(
                    WebFSUtils.makeUniqueFsId(fs.getFileSystem()),
                        fs.getNodeUri(),
                        fsRegistry.getProvider(fs.getFileSystem().getProviderId()).getRequiredAuth()
                    )
                )
                .toArray(FSFileSystem[]::new);
        } catch (Exception e) {
            throw new DBWebException("Failed to load file systems: " + e.getMessage(), e);
        }
    }

    @NotNull
    @Override
    public FSFileSystem getFileSystem(
        @NotNull WebSession webSession,
        @NotNull String projectId,
        @NotNull String nodePath
    ) throws DBWebException {
        try {
            var node = webSession.getNavigatorModelOrThrow().getNodeByPath(webSession.getProgressMonitor(), nodePath);
            if (!(node instanceof DBNFileSystem fs)) {
                throw new DBException(MessageFormat.format("Node ''{0}'' is not File System", nodePath));
            }
            var fsRegistry = FileSystemProviderRegistry.getInstance();
            return new FSFileSystem(
                WebFSUtils.makeUniqueFsId(fs.getFileSystem()),
                fs.getNodeUri(),
                fsRegistry.getProvider(fs.getFileSystem().getProviderId()).getRequiredAuth()
            );
        } catch (Exception e) {
            throw new DBWebException("Failed to get file system: " + e.getMessage(), e);
        }
    }

    @NotNull
    @Override
    public FSFile getFile(@NotNull WebSession webSession, @NotNull String nodePath)
        throws DBWebException {
        try {
            DBNPathBase node = WebFSUtils.getNodeByPath(webSession, nodePath);
            return new FSFile(node);
        } catch (Exception e) {
            throw new DBWebException("Failed to found file: " + e.getMessage(), e);
        }
    }

    @NotNull
    @Override
    public FSFile[] getFiles(@NotNull WebSession webSession, @NotNull String parentPath)
        throws DBWebException {
        try {
            DBNPathBase folderPath = WebFSUtils.getNodeByPath(webSession, parentPath);
            var children = folderPath.getChildren(webSession.getProgressMonitor());
            if (children == null) {
                return new FSFile[0];
            }
            return Arrays.stream(children)
                .filter(c -> c instanceof DBNPathBase)
                .map(c -> (DBNPathBase) c)
                .map(FSFile::new)
                .toArray(FSFile[]::new);
        } catch (Exception e) {
            throw new DBWebException("Failed to list files: " + e.getMessage(), e);
        }
    }

    @NotNull
    @Override
    public String readFileContent(@NotNull WebSession webSession, @NotNull String nodePath)
        throws DBWebException {
        try {
            Path filePath = WebFSUtils.getPathFromNode(webSession, nodePath);
            var data = Files.readAllBytes(filePath);
            return new String(data, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new DBWebException("Failed to read file content: " + e.getMessage(), e);
        }
    }

    @Override
    public FSFile writeFileContent(
        @NotNull WebSession webSession,
        @NotNull String nodePath,
        @NotNull String data,
        boolean forceOverwrite
    )
        throws DBWebException {
        validateEditPermissions(webSession);
        try {
            DBNPathBase node = WebFSUtils.getNodeByPath(webSession, nodePath);
            Path filePath = node.getPath();
            if (!forceOverwrite) {
                throw new DBException("Cannot overwrite exist file");
            }
            Files.writeString(filePath, data);
            return new FSFile(node);
        } catch (Exception e) {
            throw new DBWebException("Failed to write file content: " + e.getMessage(), e);
        }
    }

    @NotNull
    @Override
    public FSFile createFile(
        @NotNull WebSession webSession,
        @NotNull String parentPath,
        @NotNull String fileName
    ) throws DBWebException {
        validateEditPermissions(webSession);
        try {
            DBNPathBase parentNode = WebFSUtils.getNodeByPath(webSession, parentPath);
            if (!Files.isDirectory(parentNode.getPath())) {
                throw new DBException(MessageFormat.format("Node ''{0}'' is not a directory", parentPath));
            }
            Path filePath = WebFSUtils.resolveSafeChild(parentNode.getPath(), fileName);
            Files.createFile(filePath);
            parentNode.addChildResource(filePath);
            return new FSFile(parentNode.getChild(filePath));
        } catch (Exception e) {
            throw new DBWebException("Failed to create file: " + e.getMessage(), e);
        }
    }

    @Override
    public FSFile moveFile(
        @NotNull WebSession webSession,
        @NotNull String oldNodePath,
        @NotNull String parentNodePath
    ) throws DBWebException {
        validateEditPermissions(webSession);
        try {
            DBNPathBase oldNode = WebFSUtils.getNodeByPath(webSession, oldNodePath);
            DBNPathBase oldParentNode = (DBNPathBase) oldNode.getParentNode();
            String fileName = oldNode.getName();
            DBNPathBase parentNode = WebFSUtils.getNodeByPath(webSession, parentNodePath);
            Path parentPath = parentNode.getPath();
            if (!Files.isDirectory(parentPath)) {
                throw new DBException(MessageFormat.format("Node ''{0}'' is not a directory", parentPath));
            }
            Path to = Files.move(oldNode.getPath(), parentPath.resolve(fileName));
            // apply changes in navigator node
            oldParentNode.removeChildResource(oldNode.getPath());
            parentNode.addChildResource(to);
            return new FSFile(parentNode.getChild(to));
        } catch (NoSuchFileException e) {
            throw new DBWebException("File not found. Please refresh the catalog and check if file exists.");
        } catch (Exception e) {
            throw new DBWebException("Failed to move file: " + e.getMessage(), e);
        }
    }

    @Override
    public FSFile renameFile(
        @NotNull WebSession webSession,
        @NotNull String nodePath,
        @NotNull String newName
    ) throws DBWebException {
        validateEditPermissions(webSession);
        validateFilename(newName);
        try {
            DBNPathBase node = WebFSUtils.getNodeByPath(webSession, nodePath);
            node.rename(webSession.getProgressMonitor(), newName);
            return new FSFile(node);
        } catch (Exception e) {
            throw new DBWebException("Failed to move file: " + e.getMessage(), e);
        }
    }

    @Override
    public FSFile copyFile(
        @NotNull WebSession webSession,
        @NotNull String oldNodePath,
        @NotNull String parentNodePath
    ) throws DBWebException {
        validateEditPermissions(webSession);
        try {
            DBNPathBase oldNode = WebFSUtils.getNodeByPath(webSession, oldNodePath);
            String fileName = oldNode.getName();
            DBNPathBase parentNode = WebFSUtils.getNodeByPath(webSession, parentNodePath);
            Path parentPath = parentNode.getPath();
            if (!Files.isDirectory(parentPath)) {
                throw new DBException(MessageFormat.format("Node ''{0}'' is not a directory", parentPath));
            }
            Path to = Files.copy(oldNode.getPath(), parentPath.resolve(fileName));
            parentNode.addChildResource(to);
            return new FSFile(parentNode.getChild(to));
        } catch (Exception e) {
            throw new DBWebException("Failed to copy file: " + e.getMessage(), e);
        }
    }

    @NotNull
    @Override
    public FSFile createFolder(
        @NotNull WebSession webSession,
        @NotNull String parentPath,
        @NotNull String folderName
    ) throws DBWebException {
        validateEditPermissions(webSession);
        try {
            DBNPathBase parentNode = WebFSUtils.getNodeByPath(webSession, parentPath);
            if (!Files.isDirectory(parentNode.getPath())) {
                throw new DBException(MessageFormat.format("Node ''{0}'' is not a directory", parentPath));
            }
            Path folderPath = WebFSUtils.resolveSafeChild(parentNode.getPath(), folderName);
            Files.createDirectory(folderPath);
            parentNode.addChildResource(folderPath);
            return new FSFile(parentNode.getChild(folderPath));
        } catch (Exception e) {
            throw new DBWebException("Failed to create folder: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deleteFile(
        @NotNull WebSession webSession,
        @NotNull String nodePath
    ) throws DBWebException {
        validateEditPermissions(webSession);
        try {
            DBNPathBase node = WebFSUtils.getNodeByPath(webSession, nodePath);
            Path path = node.getPath();
            Files.delete(path);
            DBNPathBase parentNode = (DBNPathBase) node.getParentNode();
            parentNode.removeChildResource(path);
            return true;
        } catch (Exception e) {
            throw new DBWebException("Failed to create folder: " + e.getMessage(), e);
        }
    }

    private void validateFilename(@NotNull String filename) throws DBWebException {
        Matcher matcher = FORBIDDEN_FILENAME_PATTERN.matcher(filename);

        if (matcher.find()) {
            throw new DBWebException(String.format("File %s contains forbidden symbols", filename));
        }
    }
    
    private void validateEditPermissions(@NotNull WebSession webSession) throws DBWebException {
        if (DBWorkbench.isDistributed() && !webSession.hasPermission(DBWConstants.PERMISSION_FS_RESOURCE_EDIT)) {
            throw new DBWebException("Permission denied");
        }
    }
}
