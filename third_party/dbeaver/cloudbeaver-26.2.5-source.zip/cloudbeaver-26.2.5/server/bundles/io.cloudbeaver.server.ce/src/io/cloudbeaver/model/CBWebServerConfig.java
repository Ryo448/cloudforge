/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2025 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.model;

import io.cloudbeaver.model.config.PasswordPolicyConfiguration;
import io.cloudbeaver.server.CBApplication;
import org.jkiss.code.NotNull;
import org.jkiss.dbeaver.model.meta.Property;
import org.jkiss.utils.CommonUtils;

import java.util.List;

public class CBWebServerConfig extends WebServerConfig {
    private final CBApplication<?> cbApp;

    public CBWebServerConfig(@NotNull CBApplication<?> cbApp) {
        super(cbApp);
        this.cbApp = cbApp;
    }

    @Property
    public String getServerURL() {
        return ""; // backward compatibility
    }

    @Property
    public String getRootURI() {
        return CommonUtils.notEmpty(cbApp.getServerConfiguration().getRootURI());
    }

    @Deprecated
    @Property
    public String getHostName() {
        return getContainerId();
    }

    @Property
    public String getContainerId() {
        return CommonUtils.notEmpty(cbApp.getContainerId());
    }

    @Property
    public boolean isRedirectOnFederatedAuth() {
        return cbApp.getAppConfiguration().isRedirectOnFederatedAuth();
    }

    @Property
    public String getLocalHostAddress() {
        return cbApp.getLocalHostAddress();
    }

    @Property
    public long getSessionExpireTime() {
        return cbApp.getServerConfiguration().getMaxSessionIdleTime();
    }

    @Property
    public String[] getEnabledAuthProviders() {
        return cbApp.getAppConfiguration().getEnabledAuthProviders();
    }

    @Property
    public String getDefaultAuthRole() {
        return cbApp.getDefaultAuthRole();
    }


    @Property
    public String getDefaultUserTeam() {
        return cbApp.getAppConfiguration().getDefaultUserTeam();
    }

    @Property
    public PasswordPolicyConfiguration getPasswordPolicyConfiguration() {
        return cbApp.getServerConfiguration().getSecurityManagerConfiguration().getPasswordPolicyConfiguration();
    }

    @Property
    public boolean isForceHttps() {
        return cbApp.getServerConfiguration().isForceHttps();
    }

    @NotNull
    @Property
    public List<String> getSupportedHosts() {
        return cbApp.getServerConfiguration().getSupportedHosts();
    }

    @NotNull
    @Property
    public String getBindSessionToIp() {
        return cbApp.getServerConfiguration().getBindSessionToIp();
    }
}
