/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.service.auth.ldap;

import io.cloudbeaver.DBWUserIdentity;
import io.cloudbeaver.auth.SMAuthProviderAssigner;
import io.cloudbeaver.auth.SMAuthProviderExternal;
import io.cloudbeaver.auth.SMAutoAssign;
import io.cloudbeaver.auth.SMBruteForceProtected;
import io.cloudbeaver.auth.provider.local.LocalAuthProviderConstants;
import io.cloudbeaver.model.session.WebSession;
import io.cloudbeaver.model.user.WebUser;
import io.cloudbeaver.service.auth.ldap.ssl.LdapSslSetting;
import io.cloudbeaver.service.auth.ldap.ssl.LdapSslSocketFactory;
import org.jkiss.code.NotNull;
import org.jkiss.code.Nullable;
import org.jkiss.dbeaver.DBException;
import org.jkiss.dbeaver.Log;
import org.jkiss.dbeaver.model.DBPObject;
import org.jkiss.dbeaver.model.auth.SMSession;
import org.jkiss.dbeaver.model.data.json.JSONUtils;
import org.jkiss.dbeaver.model.runtime.DBRProgressMonitor;
import org.jkiss.dbeaver.model.security.SMAdminController;
import org.jkiss.dbeaver.model.security.SMAuthProviderCustomConfiguration;
import org.jkiss.dbeaver.model.security.SMController;
import org.jkiss.dbeaver.model.security.SMStandardMeta;
import org.jkiss.dbeaver.model.security.user.SMUser;
import org.jkiss.utils.CommonUtils;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.PartialResultException;
import javax.naming.directory.*;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

public class LdapAuthProvider implements SMAuthProviderExternal<SMSession>, SMBruteForceProtected, SMAuthProviderAssigner {
    private static final Log log = Log.getLog(LdapAuthProvider.class);
    public static final String LDAP_AUTH_PROVIDER_ID = "ldap";
    private static final int DEFAULT_TIME_LIMIT = 30_000;
    // Size of the user meta parameter value column
    private static final int MAX_PROFILE_VALUE_LENGTH = 1024;

    public LdapAuthProvider() {
    }

    @NotNull
    @Override
    public Map<String, Object> authExternalUser(
        @NotNull DBRProgressMonitor monitor,
        @Nullable SMAuthProviderCustomConfiguration providerConfig,
        @NotNull Map<String, Object> authParameters
    ) throws DBException {
        if (providerConfig == null) {
            throw new DBException("LDAP provider config is null");
        }
        String userName = JSONUtils.getString(authParameters, LdapConstants.CRED_USER_DN);
        if (CommonUtils.isEmpty(userName)) {
            throw new DBException("LDAP user dn is empty");
        }
        String password = JSONUtils.getString(authParameters, LdapConstants.CRED_PASSWORD);
        if (CommonUtils.isEmpty(password)) {
            throw new DBException("LDAP password is empty");
        }

        LdapSettings ldapSettings = new LdapSettings(providerConfig);
        Map<String, String> environment = creteAuthEnvironment(ldapSettings);

        Map<String, Object> userData = new HashMap<>();
        if (!LdapUtils.isFullDN(userName, ldapSettings.getBaseDN()) && CommonUtils.isNotEmpty(ldapSettings.getLoginAttribute())) {
            userData = validateAndLoginUserAccessByUsername(userName, password, ldapSettings);
        }
        if (CommonUtils.isEmpty(userData)) {
            String fullUserDN = buildFullUserDN(userName, ldapSettings);
            boolean validateAccessWithUserContext = false;
            if (CommonUtils.isNotEmpty(ldapSettings.getFilter())) {
                if (hasBindUserCredentials(ldapSettings)) {
                    validateUserAccessWithBindUser(fullUserDN, ldapSettings);
                } else {
                    validateAccessWithUserContext = true;
                }
            }
            userData = authenticateLdap(
                fullUserDN,
                password,
                ldapSettings,
                null,
                environment,
                validateAccessWithUserContext
            );
        }
        return userData;
    }

    @NotNull
    @Override
    public SMAutoAssign detectAutoAssignments(
        @NotNull DBRProgressMonitor monitor,
        @NotNull SMAuthProviderCustomConfiguration providerConfig,
        @NotNull Map<String, Object> authParameters
    ) throws DBException {
        LdapTeamAssignments teamAssignments = detectAutoAssignmentTeamResult(
            new LdapSettings(providerConfig),
            authParameters
        );
        SMAutoAssign smAutoAssign = new SMAutoAssign();
        smAutoAssign.setTeamAssignmentsAuthoritative(teamAssignments.authoritative());
        teamAssignments.teamIds().forEach(smAutoAssign::addExternalTeamId);
        return smAutoAssign;
    }

    @Override
    public void postAuthentication() {
        LdapSslSocketFactory.removeContextFactory();
    }

    @Nullable
    @Override
    public String getExternalTeamIdMetadataFieldName() {
        return LdapConstants.LDAP_META_GROUP_NAME;
    }

    /**
     * Find user and validate in ldap by uniq parameter from identityProviders
     *
     */
    private Map<String, Object> validateAndLoginUserAccessByUsername(
        @NotNull String login,
        @NotNull String password,
        @NotNull LdapSettings ldapSettings
    ) throws DBException {
        if (!hasBindUserCredentials(ldapSettings)) {
            return null;
        }
        Map<String, String> serviceUserContext = creteAuthEnvironment(ldapSettings);
        serviceUserContext.put(Context.SECURITY_PRINCIPAL, ldapSettings.getBindUserDN());
        serviceUserContext.put(Context.SECURITY_CREDENTIALS, ldapSettings.getBindUserPassword());
        DirContext serviceContext = null;

        try {
            serviceContext = initConnection(serviceUserContext);
            String userDN = findUserDN(serviceContext, ldapSettings, login);
            if (userDN == null) {
                return null;
            }
            return authenticateLdap(userDN, password, ldapSettings, login, creteAuthEnvironment(ldapSettings), false);
        } catch (Exception e) {
            throw new DBException("LDAP authentication failed: " + e.getMessage(), e);
        } finally {
            if (serviceContext != null) {
                try {
                    serviceContext.close();
                } catch (NamingException e) {
                    log.warn("Error closing LDAP service context", e);
                }
            }
        }
    }

    private static boolean hasBindUserCredentials(@NotNull LdapSettings ldapSettings) {
        return CommonUtils.isNotEmpty(ldapSettings.getBindUserDN())
            && CommonUtils.isNotEmpty(ldapSettings.getBindUserPassword());
    }

    /**
     * Validate LDAP user access by full user DN using the configured bind user.
     */
    private void validateUserAccessWithBindUser(
        @NotNull String fullUserDN,
        @NotNull LdapSettings ldapSettings
    ) throws DBException {
        var environment = creteAuthEnvironment(ldapSettings);
        environment.put(Context.SECURITY_PRINCIPAL, ldapSettings.getBindUserDN());
        environment.put(Context.SECURITY_CREDENTIALS, ldapSettings.getBindUserPassword());

        DirContext bindUserContext = null;
        try {
            bindUserContext = initConnection(environment);
            validateUserAccess(fullUserDN, ldapSettings, bindUserContext);
        } finally {
            if (bindUserContext != null) {
                try {
                    bindUserContext.close();
                } catch (NamingException e) {
                    log.warn("Error closing LDAP bind user context", e);
                }
            }
        }
    }

    private void validateUserAccess(
        @NotNull String fullUserDN,
        @NotNull LdapSettings ldapSettings,
        @NotNull DirContext validationContext
    ) throws DBException {
        NamingEnumeration<SearchResult> searchResult = null;
        try {
            SearchControls searchControls = createSearchControls();
            searchResult = validationContext.search(fullUserDN, ldapSettings.getFilter(), searchControls);
            if (!searchResult.hasMore()) {
                throw new DBException("Access denied");
            }
        } catch (DBException e) {
            throw e;
        } catch (Exception e) {
            throw new DBException("LDAP user access validation by filter failed: " + e.getMessage(), e);
        } finally {
            if (searchResult != null) {
                try {
                    searchResult.close();
                } catch (NamingException e) {
                    log.warn("Error closing LDAP user access validation results", e);
                }
            }
        }
    }

    protected String getAttributeValue(Attributes attributes, String attributeName) throws NamingException {
        Attribute attribute = attributes.get(attributeName);
        return attribute != null ? attribute.get().toString() : null;
    }

    @NotNull
    protected String getAttributeValueSafe(@NotNull Attributes attributes, @NotNull String attrName) {
        try {
            Attribute attr = attributes.get(attrName.toLowerCase());
            return attr != null ? (String) attr.get() : "";
        } catch (Exception e) {
            log.debug("Can't extract '" + attrName + "' from ldap attributes");
            return "";
        }
    }

    @NotNull
    public Map<String, String> creteAuthEnvironment(LdapSettings ldapSettings) throws DBException {
        Map<String, String> environment = new HashMap<>();
        environment.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");

        environment.put(Context.PROVIDER_URL, ldapSettings.getLdapProviderUrl());
        environment.put(Context.SECURITY_AUTHENTICATION, "simple");

        try {
            configureSsl(ldapSettings, environment);
        } catch (Exception e) {
            log.error("Can't establish ssl connection", e);
            throw new DBException("Can't establish ssl connection", e);
        }

        return environment;
    }

    private void configureSsl(LdapSettings ldapSettings, Map<String, String> environment) throws Exception {
        LdapSslSetting ldapSslSetting = ldapSettings.getLdapSslSetting();

        if (!ldapSslSetting.isEnable() || CommonUtils.isEmpty(ldapSslSetting.getSslCert())) {
            return;
        }

        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        byte[] decoded = Base64.getDecoder().decode(ldapSslSetting.getSslCert());
        ByteArrayInputStream certStream = new ByteArrayInputStream(decoded);
        Certificate cert = cf.generateCertificate(certStream);

        KeyStore ts = KeyStore.getInstance(KeyStore.getDefaultType());
        ts.load(null, null);
        ts.setCertificateEntry("trusted-root", cert);

        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(ts);
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, tmf.getTrustManagers(), new SecureRandom());

        LdapSslSocketFactory.setContextFactory(sslContext);
        environment.put("java.naming.ldap.factory.socket", LdapSslSocketFactory.class.getName());
    }

    protected String findUserDN(DirContext serviceContext, LdapSettings ldapSettings, String userIdentifier) throws DBException {

        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        searchControls.setReturningAttributes(new String[]{"distinguishedName"});
        NamingEnumeration<SearchResult> results = findByFilter(
            serviceContext,
            ldapSettings,
            buildSearchFilter(ldapSettings),
            new Object[]{userIdentifier},
            searchControls
        );

        try {
            if (results.hasMore()) {
                return results.next().getNameInNamespace();
            }
        } catch (NamingException e) {
            throw new DBException("Error finding user DN: " + e.getMessage(), e);
        } finally {
            try {
                results.close();
            } catch (NamingException e) {
                log.warn("Error closing LDAP user search results", e);
            }
        }
        return null;
    }

    public NamingEnumeration<SearchResult> findByFilter(
        @NotNull DirContext serviceContext,
        @NotNull LdapSettings ldapSettings,
        @NotNull String searchFilter,
        @NotNull SearchControls searchControls
    ) throws DBException {
        return findByFilter(serviceContext, ldapSettings, searchFilter, null, searchControls);
    }

    public NamingEnumeration<SearchResult> findByFilter(
        @NotNull DirContext serviceContext,
        @NotNull LdapSettings ldapSettings,
        @NotNull String searchFilter,
        @Nullable Object[] filterArgs,
        @NotNull SearchControls searchControls
    ) throws DBException {
        try {
            String baseDN = getBaseDN(serviceContext, ldapSettings);
            return filterArgs == null
                ? serviceContext.search(baseDN, searchFilter, searchControls)
                : serviceContext.search(baseDN, searchFilter, filterArgs, searchControls);
        } catch (Exception e) {
            throw new DBException("Error finding user DN: " + e.getMessage(), e);
        }
    }

    private String getBaseDN(DirContext serviceContext, LdapSettings ldapSettings) throws DBException {
        if (CommonUtils.isEmpty(ldapSettings.getBaseDN())) {
            return getRootDN(serviceContext);
        }
        return ldapSettings.getBaseDN();
    }

    private String buildSearchFilter(LdapSettings ldapSettings) {
        String userFilter = String.format("(%s={0})", ldapSettings.getLoginAttribute());
        if (CommonUtils.isNotEmpty(ldapSettings.getFilter())) {
            return String.format("(&%s%s)", userFilter, ldapSettings.getFilter());
        }
        return userFilter;
    }

    private String getRootDN(DirContext adminContext) throws DBException {
        try {
            Attributes attributes = adminContext.getAttributes("", new String[]{"namingContexts"});
            Attribute namingContexts = attributes.get("namingContexts");
            if (namingContexts != null && namingContexts.size() > 0) {
                return (String) namingContexts.get(0);
            }
            throw new DBException("Root DN not found in namingContexts");
        } catch (Exception e) {
            throw new DBException("Error retrieving root DN: " + e.getMessage(), e);
        }
    }

    @NotNull
    private String findUserNameFromDN(@NotNull String fullUserDN, @NotNull LdapSettings ldapSettings)
    throws DBException {
        try {
            LdapName ldapDN = new LdapName(fullUserDN);
            for (Rdn rdn : ldapDN.getRdns()) {
                if (rdn.getType().equalsIgnoreCase(ldapSettings.getUserIdentifierAttr())) {
                    Object v = rdn.getValue();
                    if (v instanceof byte[]) {
                        return new String((byte[]) v, StandardCharsets.UTF_8);
                    }
                    return String.valueOf(v);
                }
            }
            throw new DBException("Failed to determine userId from user DN: " + fullUserDN);
        } catch (Exception e) {
            throw new DBException("Invalid user DN: " + fullUserDN, e);
        }
    }

    @NotNull
    @Override
    public DBWUserIdentity getUserIdentity(
        @NotNull DBRProgressMonitor monitor,
        @Nullable SMAuthProviderCustomConfiguration customConfiguration,
        @NotNull Map<String, Object> authParameters
    ) throws DBException {
        String userName = JSONUtils.getString(authParameters, LocalAuthProviderConstants.CRED_USER);
        if (CommonUtils.isEmpty(userName)) {
            throw new DBException("LDAP user name is empty");
        }
        Map<?, ?> profile = authParameters.get(SMStandardMeta.KEY_META_PARAMS) instanceof Map<?, ?> meta ? meta : Map.of();
        String firstName = profile.get(SMStandardMeta.META_FIRST_NAME) instanceof String first
            ? first : JSONUtils.getString(authParameters, SMStandardMeta.META_FIRST_NAME);
        String lastName = profile.get(SMStandardMeta.META_LAST_NAME) instanceof String last
            ? last : JSONUtils.getString(authParameters, SMStandardMeta.META_LAST_NAME);
        String displayName = Stream.of(firstName, lastName).filter(CommonUtils::isNotEmpty).collect(Collectors.joining(" "));
        if (CommonUtils.isEmpty(displayName)) {
            displayName = JSONUtils.getString(authParameters, LocalAuthProviderConstants.CRED_DISPLAY_NAME);
        }
        if (CommonUtils.isEmpty(displayName)) {
            displayName = userName;
        }
        // Main LDAP login has already filled the stored user profile. Do not expose directory metadata as an
        // identity overlay: child authentication skips local validation and must not override that profile.
        return new DBWUserIdentity(userName, displayName);
    }

    @Nullable
    @Override
    public DBPObject getUserDetails(
        @NotNull DBRProgressMonitor monitor,
        @NotNull WebSession webSession,
        @NotNull SMSession session,
        @NotNull WebUser user,
        boolean selfIdentity
    ) throws DBException {
        return null;
    }

    @NotNull
    @Override
    public String validateLocalAuth(
        @NotNull DBRProgressMonitor monitor,
        @NotNull SMController securityController,
        @NotNull SMAuthProviderCustomConfiguration providerConfig,
        @NotNull Map<String, Object> userCredentials,
        @Nullable String activeUserId
    ) throws DBException {
        String userId = JSONUtils.getString(userCredentials, LdapConstants.CRED_USERNAME);
        String oldUsername = JSONUtils.getString(userCredentials, LdapConstants.CRED_USER_DN);
        if (CommonUtils.isNotEmpty(oldUsername)) {
            oldUsername = findUserNameFromDN(oldUsername, new LdapSettings(providerConfig));
            Map<String, Object> oldUserLDAP = securityController.getUserCredentials(oldUsername, LDAP_AUTH_PROVIDER_ID);
            userCredentials.putAll(oldUserLDAP);
            if (userCredentials.get("user").equals(oldUsername)) {
                userId = oldUsername;
            }
        }
        if (CommonUtils.isEmpty(userId)) {
            throw new DBException("LDAP user id not found");
        }
        // LDAP user IDs are case-insensitive. For linked accounts use the local ID resolved by the controller,
        // which may differ from the LDAP login. Fill missing values before loading the user into the web session.
        String localUserId = activeUserId == null ? userId.toLowerCase() : activeUserId;
        fillMissingUserProfile(securityController, localUserId, userCredentials);
        return activeUserId == null ? userId : activeUserId;
    }

    private void fillMissingUserProfile(
        @NotNull SMController securityController,
        @NotNull String userId,
        @NotNull Map<String, Object> userCredentials
    ) {
        if (!(userCredentials.get(SMStandardMeta.KEY_META_PARAMS) instanceof Map<?, ?> provided)) {
            return;
        }
        Map<String, String> profile = new LinkedHashMap<>();
        for (String name : List.of(SMStandardMeta.META_FIRST_NAME, SMStandardMeta.META_LAST_NAME)) {
            if (provided.get(name) instanceof String value && CommonUtils.isNotEmpty(value)) {
                profile.put(name, value);
            }
        }
        // The security controller provisions new users after this hook using these nonempty LDAP values.
        userCredentials.put(SMStandardMeta.KEY_META_PARAMS, profile);
        if (provided.isEmpty() || !(securityController instanceof SMAdminController adminController)) {
            return;
        }
        try {
            SMUser user = adminController.getUserById(userId);
            if (user == null) {
                return;
            }
            Map<String, String> completedProfile = new LinkedHashMap<>(user.getMetaParameters());
            for (Map.Entry<String, String> entry : profile.entrySet()) {
                if (CommonUtils.isEmpty(completedProfile.get(entry.getKey()))) {
                    completedProfile.put(entry.getKey(), entry.getValue());
                }
            }
            // Use the same effective values for this session's identity, including manually entered names.
            userCredentials.put(SMStandardMeta.KEY_META_PARAMS, completedProfile);
            if (!completedProfile.equals(user.getMetaParameters())) {
                adminController.setSubjectMetas(userId, completedProfile);
            }
        } catch (DBException e) {
            log.warn("Cannot fill missing LDAP profile values of user '" + userId + "'", e);
        }
    }

    @Override
    public SMSession openSession(
        @NotNull DBRProgressMonitor monitor,
        @NotNull SMSession mainSession,
        @Nullable SMAuthProviderCustomConfiguration customConfiguration,
        @NotNull Map<String, Object> userCredentials
    ) throws DBException {
        return new LdapSession(mainSession, mainSession.getSessionSpace(), userCredentials);
    }

    @Override
    public void closeSession(@NotNull SMSession mainSession, SMSession session) throws DBException {

    }

    @Override
    public void refreshSession(
        @NotNull DBRProgressMonitor monitor,
        @NotNull SMSession mainSession,
        SMSession session
    ) throws DBException {

    }

    @Override
    public Object getInputUsername(@NotNull Map<String, Object> cred) {
        return cred.get(LdapConstants.CRED_USER_DN);
    }

    private String buildFullUserDN(String userName, LdapSettings ldapSettings) {
        String fullUserDN = userName;

        if (!CommonUtils.startsWithIgnoreCase(fullUserDN, ldapSettings.getUserIdentifierAttr())) {
            fullUserDN = String.join("=", ldapSettings.getUserIdentifierAttr(), userName);
        }
        if (CommonUtils.isNotEmpty(ldapSettings.getBaseDN()) && !CommonUtils.endsWithIgnoreCase(fullUserDN, ldapSettings.getBaseDN())) {
            fullUserDN = String.join(",", fullUserDN, ldapSettings.getBaseDN());
        }

        return fullUserDN;
    }

    private SearchControls createSearchControls() {
        SearchControls searchControls = new SearchControls();
        // Access validation and profile reads must only examine the authenticating user's entry.
        searchControls.setSearchScope(SearchControls.OBJECT_SCOPE);
        searchControls.setTimeLimit(DEFAULT_TIME_LIMIT);
        searchControls.setReturningAttributes(new String[]{"*", "+"});
        return searchControls;
    }

    private Map<String, Object> authenticateLdap(
        @NotNull String userDN,
        @NotNull String password,
        @NotNull LdapSettings ldapSettings,
        @Nullable String login,
        @NotNull Map<String, String> environment,
        boolean validateAccess
    ) throws DBException {
        Map<String, Object> userData = new HashMap<>();
        environment.put(Context.SECURITY_PRINCIPAL, userDN);
        environment.put(Context.SECURITY_CREDENTIALS, password);
        DirContext userContext = null;
        try {
            userContext = initConnection(environment);
            if (validateAccess) {
                validateUserAccess(userDN, ldapSettings, userContext);
            }
            SearchControls searchControls = createSearchControls();
            String userId = "";
            var searchResult = userContext.search(userDN, "objectClass=*", searchControls);
            if (searchResult.hasMore()) {
                SearchResult result = searchResult.next();
                Attributes attributes = result.getAttributes();
                userId = getAttributeValue(attributes, "objectGUID");
                if (userId == null) {
                    userId = getAttributeValue(attributes, "entryUUID");
                }
                userData.put(
                    LdapConstants.LDAP_META_GROUP_NAME,
                    getAttributeValueSafe(
                        attributes,
                        ldapSettings.getProviderConfiguration().getParameter(LdapConstants.LDAP_META_GROUP_NAME)
                    )
                );
                collectUserProfile(ldapSettings, attributes, userData);
                doCustomModifyUserDataAfterAuthentication(ldapSettings, attributes, userData);
            }
            userData.putIfAbsent(LdapConstants.CRED_USERNAME, CommonUtils.isNotEmpty(login) ? login : userId);
            userData.put(LdapConstants.CRED_USER_DN, userDN);
            userData.put(LdapConstants.CRED_PASSWORD, password);
            userData.put(LdapConstants.CRED_DISPLAY_NAME, CommonUtils.isNotEmpty(login) ? login : findUserNameFromDN(userDN, ldapSettings));
            userData.put(LdapConstants.CRED_SESSION_ID, UUID.randomUUID());

            return userData;
        } catch (Exception e) {
            throw new DBException("LDAP authentication failed: " + e.getMessage(), e);
        } finally {
            if (userContext != null) {
                try {
                    userContext.close();
                } catch (NamingException e) {
                    log.warn("Error closing LDAP user context", e);
                }
            }
        }
    }

    /**
     * Reads the configured first and last names for the user profile and session identity.
     */
    private void collectUserProfile(
        @NotNull LdapSettings ldapSettings,
        @NotNull Attributes attributes,
        @NotNull Map<String, Object> userData
    ) {
        Map<String, String> profile = new LinkedHashMap<>();
        if (CommonUtils.isNotEmpty(ldapSettings.getFirstNameField())) {
            profile.put(SMStandardMeta.META_FIRST_NAME, readProfileAttribute(attributes, ldapSettings.getFirstNameField()));
        }
        if (CommonUtils.isNotEmpty(ldapSettings.getLastNameField())) {
            profile.put(SMStandardMeta.META_LAST_NAME, readProfileAttribute(attributes, ldapSettings.getLastNameField()));
        }
        String firstName = profile.get(SMStandardMeta.META_FIRST_NAME);
        if (CommonUtils.isNotEmpty(firstName)) {
            userData.put(SMStandardMeta.META_FIRST_NAME, firstName);
        }
        String lastName = profile.get(SMStandardMeta.META_LAST_NAME);
        if (CommonUtils.isNotEmpty(lastName)) {
            userData.put(SMStandardMeta.META_LAST_NAME, lastName);
        }
        if (!profile.isEmpty()) {
            userData.put(SMStandardMeta.KEY_META_PARAMS, profile);
        }
    }

    @NotNull
    private String readProfileAttribute(@NotNull Attributes attributes, @NotNull String attributeName) {
        if (CommonUtils.isEmpty(attributeName)) {
            return "";
        }
        String value = getAttributeValueSafe(attributes, attributeName).trim();
        return value.length() > MAX_PROFILE_VALUE_LENGTH ? value.substring(0, MAX_PROFILE_VALUE_LENGTH) : value;
    }

    protected void doCustomModifyUserDataAfterAuthentication(
        @NotNull LdapSettings ldapSettings,
        @NotNull Attributes attributes,
        @NotNull Map<String, Object> userData
    ) {
    }

    @NotNull
    protected List<String> detectAutoAssignmentTeam(
        @NotNull LdapSettings ldapSettings,
        @NotNull Map<String, Object> authParameters
    ) throws DBException {
        return detectAutoAssignmentTeamResult(ldapSettings, authParameters).teamIds();
    }

    @NotNull
    protected LdapTeamAssignments detectAutoAssignmentTeamResult(
        @NotNull LdapSettings ldapSettings,
        @NotNull Map<String, Object> authParameters
    ) throws DBException {
        String userName = JSONUtils.getString(authParameters, LdapConstants.CRED_USERNAME);
        if (CommonUtils.isEmpty(userName)) {
            throw new DBException("LDAP user name is empty");
        }

        String fullDN = JSONUtils.getString(authParameters, LdapConstants.CRED_USER_DN);
        String userDN;
        if (!CommonUtils.isEmpty(fullDN)) {
            userDN = fullDN;
        } else {
            userDN = getUserDN(ldapSettings, JSONUtils.getString(authParameters, LdapConstants.CRED_DISPLAY_NAME));
        }
        if (userDN == null) {
            return new LdapTeamAssignments(Collections.emptyList(), false);
        }

        List<String> result = new ArrayList<>();
        result.add(userDN);
        LdapTeamAssignments groupAssignments = resolveGroupsForMember(userDN, ldapSettings, authParameters);
        result.addAll(groupAssignments.teamIds());
        return new LdapTeamAssignments(result, groupAssignments.authoritative());
    }

    @Nullable
    private String getUserDN(@NotNull LdapSettings ldapSettings, @Nullable String displayName) {
        DirContext context;
        try {
            context = initConnection(creteAuthEnvironment(ldapSettings));
            return findUserDN(context, ldapSettings, displayName);
        } catch (Exception e) {
            log.error("User not found", e);
            return null;
        }
    }

    @NotNull
    protected List<String> getGroupForMember(
        @NotNull String fullDN,
        @NotNull LdapSettings ldapSettings,
        @NotNull Map<String, Object> authParameters
    ) {
        return resolveGroupsForMember(fullDN, ldapSettings, authParameters).teamIds();
    }

    @NotNull
    protected LdapTeamAssignments resolveGroupsForMember(
        @NotNull String fullDN,
        @NotNull LdapSettings ldapSettings,
        @NotNull Map<String, Object> authParameters
    ) {
        DirContext context = null;
        Set<String> result = new LinkedHashSet<>();
        boolean authoritative = true;
        try {
            Map<String, String> environment = creteAuthEnvironment(ldapSettings);
            if (CommonUtils.isEmpty(ldapSettings.getBindUserDN())) {
                environment.put(Context.SECURITY_PRINCIPAL, String.valueOf(authParameters.get(LdapConstants.CRED_USER_DN)));
                environment.put(Context.SECURITY_CREDENTIALS, String.valueOf(authParameters.get(LdapConstants.CRED_PASSWORD)));
            } else {
                environment.put(Context.SECURITY_PRINCIPAL, ldapSettings.getBindUserDN());
                environment.put(Context.SECURITY_CREDENTIALS, ldapSettings.getBindUserPassword());
            }
            //it's a hack. Otherwise password will be written to database
            authParameters.remove(LdapConstants.CRED_PASSWORD);

            String referralHandlingMode = ldapSettings.getReferralHandlingMode();
            environment.put(Context.REFERRAL, referralHandlingMode);
            if ("follow".equalsIgnoreCase(referralHandlingMode)) {
                environment.put("java.naming.ldap.referral.limit", "5");
            }

            context = initConnection(environment);
            // Run both lookups independently: a failure in one must not discard the groups
            // already collected by the other.
            try {
                LdapTeamAssignments groupsByMemberOfAttribute = findGroupsByMemberOfAttributeResult(fullDN, context);
                log.debug("Found " + groupsByMemberOfAttribute.teamIds().size() + " groups by memberOf attribute");
                result.addAll(groupsByMemberOfAttribute.teamIds());
                authoritative &= groupsByMemberOfAttribute.authoritative();
            } catch (Exception e) {
                log.error("Failed to fetch groups by memberOf attribute. " + e.getMessage());
                authoritative = false;
            }
            try {
                LdapTeamAssignments groupsByMemberAttribute = findGroupsByMemberAttributeResult(
                    fullDN,
                    ldapSettings,
                    context
                );
                log.debug("Found " + groupsByMemberAttribute.teamIds().size() + " groups by member attribute");
                result.addAll(groupsByMemberAttribute.teamIds());
                authoritative &= groupsByMemberAttribute.authoritative();
            } catch (Exception e) {
                log.error("Failed to fetch groups by member attribute. " + e.getMessage());
                authoritative = false;
            }
        } catch (Exception e) {
            log.error("Group not found. " + e.getMessage());
            authoritative = false;
        } finally {
            try {
                if (context != null) {
                    context.close();
                }
            } catch (Exception e) {
                log.error("Close resource of ldap group search failed", e);
            }
        }
        log.debug("Resolved " + result.size() + " external group id(s) for member '" + fullDN + "': " + result);
        return new LdapTeamAssignments(new ArrayList<>(result), authoritative);
    }

    protected record LdapTeamAssignments(@NotNull List<String> teamIds, boolean authoritative) {
    }

    @NotNull
    protected LdapTeamAssignments createTeamAssignments(
        @NotNull List<String> teamIds,
        boolean authoritative
    ) {
        return new LdapTeamAssignments(teamIds, authoritative);
    }

    @NotNull
    protected List<String> findGroupsByMemberOfAttribute(
        @NotNull String fullDN,
        @NotNull DirContext context
    ) throws NamingException {
        return findGroupsByMemberOfAttributeResult(fullDN, context).teamIds();
    }

    @NotNull
    private LdapTeamAssignments findGroupsByMemberOfAttributeResult(
        @NotNull String fullDN,
        @NotNull DirContext context
    ) throws NamingException {
        List<String> result = new ArrayList<>();
        boolean authoritative = true;
        SearchControls memberOfSearch = new SearchControls();
        memberOfSearch.setSearchScope(SearchControls.OBJECT_SCOPE);
        memberOfSearch.setTimeLimit(DEFAULT_TIME_LIMIT);
        memberOfSearch.setReturningAttributes(new String[] {"*", "+"});
        NamingEnumeration<SearchResult> userRecord = context.search(fullDN, "(objectClass=*)", memberOfSearch);
        try {
            if (userRecord.hasMore()) {
                SearchResult userResult = userRecord.next();
                Attributes userAttributes = userResult.getAttributes();
                Attribute memberOfAttr = userAttributes.get("memberOf");
                if (memberOfAttr != null) {
                    NamingEnumeration<?> groups = memberOfAttr.getAll();
                    while (groups.hasMore()) {
                        String groupDN = String.valueOf(groups.next());
                        result.add(groupDN);
                    }
                }
            }
        } catch (PartialResultException e) {
            log.debug("Ignoring LDAP continuation references while reading memberOf for '" + fullDN + "'");
            authoritative = false;
        } finally {
            if (userRecord != null) {
                userRecord.close();
            }
        }

        return new LdapTeamAssignments(result, authoritative);
    }

    @NotNull
    protected List<String> findGroupsByMemberAttribute(
        @NotNull String fullDN,
        @NotNull LdapSettings ldapSettings,
        @NotNull DirContext context
    ) throws NamingException {
        return findGroupsByMemberAttributeResult(fullDN, ldapSettings, context).teamIds();
    }

    @NotNull
    private LdapTeamAssignments findGroupsByMemberAttributeResult(
        @NotNull String fullDN,
        @NotNull LdapSettings ldapSettings,
        @NotNull DirContext context
    ) throws NamingException {
        List<String> result = new ArrayList<>();
        boolean authoritative = true;
        String searchFilter = "(member={0})";
        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        NamingEnumeration<SearchResult> searchResults = context.search(
            ldapSettings.getBaseDN(),
            searchFilter,
            new Object[] {fullDN},
            searchControls
        );
        try {
            while (searchResults.hasMore()) {
                try {
                    SearchResult next = searchResults.next();
                    //add full dn
                    result.add(next.getNameInNamespace());
                    //add relative dn to base dn
                    result.add(next.getName());
                } catch (Exception e) {
                    log.error("Failed fetch user group. " + e.getMessage());
                    authoritative = false;
                }
            }
        } catch (PartialResultException e) {
            log.debug("Ignoring LDAP continuation references during member group search for '" + fullDN + "'");
            authoritative = false;
        } finally {
            if (searchResults != null) {
                searchResults.close();
            }
        }
        return new LdapTeamAssignments(result, authoritative);
    }

    @NotNull
    public DirContext initConnection(@NotNull Map<String, String> environment) throws DBException {
        //this hack is needed for correct LDAPS working. JNDI uses ContextClassLoader instead of OSGI loader
        ClassLoader previous = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
        try {
            return new InitialDirContext(new Hashtable<>(environment));
        } catch (Exception e) {
            throw new DBException("Can't establish LDAP connection", e);
        } finally {
            Thread.currentThread().setContextClassLoader(previous);
        }
    }
}
