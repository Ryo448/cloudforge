/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.cloudbeaver.service.auth.ldap;

import io.cloudbeaver.auth.provider.fa.AbstractSessionExternal;
import org.jkiss.code.NotNull;
import org.jkiss.dbeaver.model.auth.SMAuthSpace;
import org.jkiss.dbeaver.model.auth.SMSession;
import org.jkiss.dbeaver.model.data.json.JSONUtils;

import java.util.Map;

public class LdapSession extends AbstractSessionExternal {
    protected LdapSession(
        @NotNull SMSession parentSession,
        @NotNull SMAuthSpace space,
        @NotNull Map<String, Object> authParameters
    ) {
        super(parentSession, space, authParameters);
    }

    @NotNull
    @Override
    public String getSessionId() {
        return JSONUtils.getString(authParameters, LdapConstants.CRED_SESSION_ID, "sessionNotFound");
    }
}
